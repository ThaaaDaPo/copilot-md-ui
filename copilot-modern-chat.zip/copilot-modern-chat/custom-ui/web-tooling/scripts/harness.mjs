// Loads the real web/index.html into a local Chrome/Edge (via puppeteer-core) and plays the role of the Java side:
// it installs window.__copilotChatPost, answers the "ready" handshake with an init message and lets tests push
// protocol messages. Used by browser-test.mjs and screenshots.mjs.
import { existsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import puppeteer from 'puppeteer-core';

const here = dirname(fileURLToPath(import.meta.url));
export const WEB_ROOT = resolve(here, '..', '..', 'custom.copilot.webchat', 'web');
export const PAGE_URL = pathToFileURL(join(WEB_ROOT, 'index.html')).href;

const CANDIDATES = [
  process.env.CHROME_PATH,
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
  '/usr/bin/chromium-browser',
].filter(Boolean);

export function findBrowser() {
  const found = CANDIDATES.find((p) => existsSync(p));
  if (!found) {
    throw new Error('No Chrome/Edge found. Set CHROME_PATH.');
  }
  return found;
}

export const LIGHT_THEME = {
  dark: false, background: '#ffffff', foreground: '#1f1f1f', fontFamily: '.AppleSystemUIFont', fontSize: 13,
  codeFontFamily: 'Menlo', codeFontSize: 12, platform: 'mac',
};

export const DARK_THEME = {
  dark: true, background: '#1e1f22', foreground: '#cccccc', fontFamily: '.AppleSystemUIFont', fontSize: 13,
  codeFontFamily: 'Menlo', codeFontSize: 12, platform: 'mac',
};

export const LABELS = {
  copy: 'Copy', copyCode: 'Copy code', copied: 'Copied', insert: 'Insert into editor', thinking: 'Thinking...',
  compacting: 'Compacting conversation...', showDiagram: 'Show diagram', showSource: 'Show source',
};

/**
 * @param {{theme?: object, width?: number, height?: number, features?: object}} options
 */
export async function openChat(options = {}) {
  const browser = await puppeteer.launch({
    executablePath: findBrowser(),
    headless: true,
    args: ['--no-first-run', '--no-default-browser-check', '--disable-extensions'],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: options.width ?? 720, height: options.height ?? 1000, deviceScaleFactor: 2 });

  const problems = [];
  page.on('console', (msg) => {
    if (msg.type() === 'error' || msg.type() === 'warning') {
      problems.push(`${msg.type()}: ${msg.text()}`);
    }
  });
  page.on('pageerror', (err) => problems.push('pageerror: ' + err.message));

  const posted = [];
  await page.exposeFunction('__harnessReceive', (json) => {
    posted.push(JSON.parse(json));
  });
  // Same contract as the Java BrowserFunction: one string argument with {type, payload}.
  await page.evaluateOnNewDocument(() => {
    window.__copilotChatPost = (json) => {
      window.__harnessReceive(json);
    };
    document.addEventListener('securitypolicyviolation', (e) => {
      console.error('CSP violation: ' + e.violatedDirective + ' ' + e.blockedURI);
    });
  });

  await page.goto(PAGE_URL, { waitUntil: 'load' });
  await waitFor(() => posted.some((m) => m.type === 'ready'), 'ready handshake');

  const chat = {
    browser,
    page,
    posted,
    problems,
    async send(messages) {
      await page.evaluate((batch) => window.CopilotChat.receive(batch), messages);
    },
    async settle(ms = 150) {
      await new Promise((r) => setTimeout(r, ms));
      await page.evaluate(() => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r))));
    },
    async close() {
      await browser.close();
    },
  };
  await chat.send([{
    type: 'init',
    protocol: 1,
    theme: options.theme ?? LIGHT_THEME,
    features: options.features ?? { mermaid: true, math: true },
    labels: LABELS,
  }]);
  return chat;
}

export async function waitFor(predicate, what, timeoutMs = 10000) {
  const start = Date.now();
  while (!(await predicate())) {
    if (Date.now() - start > timeoutMs) {
      throw new Error('Timed out waiting for ' + what);
    }
    await new Promise((r) => setTimeout(r, 25));
  }
}
