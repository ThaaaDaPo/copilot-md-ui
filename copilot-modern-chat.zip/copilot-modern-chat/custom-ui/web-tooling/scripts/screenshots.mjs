// Renders the demo conversation in light and dark theme and writes PNG screenshots for visual review.
//   node scripts/screenshots.mjs [outDir]
import { mkdirSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { DARK_THEME, LIGHT_THEME, openChat, waitFor } from './harness.mjs';
import { richConversation, warningAndErrors } from '../fixtures/scenarios.mjs';

const outDir = resolve(process.argv[2] || 'screenshots');
mkdirSync(outDir, { recursive: true });

for (const [name, theme] of [['light', LIGHT_THEME], ['dark', DARK_THEME]]) {
  const chat = await openChat({ theme, height: 1400 });
  await chat.send(richConversation());
  await chat.send(warningAndErrors());
  await chat.settle(300);
  // Diagrams render lazily when scrolled into view; walk through the page once.
  await chat.page.evaluate(async () => {
    const s = document.getElementById('scroller');
    for (let y = 0; y < s.scrollHeight; y += 600) {
      s.scrollTop = y;
      await new Promise((r) => setTimeout(r, 120));
    }
  });
  await waitFor(() => chat.page.evaluate(() =>
    document.querySelectorAll('.mermaid-block[data-state="pending"]').length === 0), 'diagrams', 20000);
  await chat.settle(200);
  const height = await chat.page.evaluate(() => document.getElementById('scroller').scrollHeight);
  // Expand the viewport to the full conversation so a single screenshot shows everything.
  await chat.page.setViewport({ width: 720, height: Math.min(height + 40, 16000), deviceScaleFactor: 1 });
  // Let the document grow with the content so the full-page screenshot captures everything from the top.
  await chat.page.addStyleTag({ content: 'html,body{height:auto!important;overflow:visible!important}'
    + '#scroller{position:static!important;overflow:visible!important}.turn{content-visibility:visible!important}' });
  await chat.page.evaluate(() => {
    window.CopilotChat.chat.state.stick = false;
  });
  await chat.settle(300);
  const file = join(outDir, `chat-${name}.png`);
  await chat.page.screenshot({ path: file, fullPage: true });
  console.log('wrote', file);
  const total = await chat.page.evaluate(() => document.documentElement.scrollHeight);
  for (let y = 0, i = 0; y < total; y += 1200, i++) {
    await chat.page.screenshot({
      path: join(outDir, `chat-${name}-${i}.png`),
      clip: { x: 0, y, width: 720, height: Math.min(1200, total - y) },
      captureBeyondViewport: true,
    });
  }
  if (chat.problems.length) {
    console.log('problems:', chat.problems);
  }
  await chat.close();
}
