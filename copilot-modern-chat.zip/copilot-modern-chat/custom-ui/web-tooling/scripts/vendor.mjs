// Copies the pinned third-party libraries from node_modules into the plug-in's web/vendor folder.
// The plug-in ships the copied files, so the Maven/Tycho build never needs Node.js or network access.
// Run after changing a version in package.json:  npm install && npm run vendor
import { cpSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, '..');
const modules = join(root, 'node_modules');
const target = join(root, '..', 'custom.copilot.webchat', 'web', 'vendor');

const EXTRA_HIGHLIGHT_LANGUAGES = [
  'cmake', 'dockerfile', 'dos', 'gradle', 'groovy', 'http', 'latex', 'pgsql', 'powershell',
  'properties', 'protobuf', 'scala',
];

const libraries = [
  {
    name: 'markdown-it',
    files: [['dist/markdown-it.min.js', 'markdown-it.min.js']],
    license: 'LICENSE',
  },
  {
    name: 'dompurify',
    files: [['dist/purify.min.js', 'purify.min.js']],
    license: 'LICENSE',
  },
  {
    name: '@highlightjs/cdn-assets',
    dir: 'highlight',
    files: [
      ['highlight.min.js', 'highlight.min.js'],
      ...EXTRA_HIGHLIGHT_LANGUAGES.map((l) => [`languages/${l}.min.js`, `languages/${l}.min.js`]),
    ],
    license: 'LICENSE',
  },
  {
    name: 'mermaid',
    files: [['dist/mermaid.min.js', 'mermaid.min.js']],
    license: 'LICENSE',
  },
  {
    name: 'katex',
    files: [['dist/katex.min.js', 'katex.min.js'], ['dist/katex.min.css', 'katex.min.css'], ['dist/fonts', 'fonts']],
    license: 'LICENSE',
  },
];

rmSync(target, { recursive: true, force: true });
mkdirSync(target, { recursive: true });

const notices = ['# Third-party libraries', '',
  'The files in this folder are unmodified copies produced by `custom-ui/web-tooling/scripts/vendor.mjs`.', ''];

for (const lib of libraries) {
  const src = join(modules, lib.name);
  const pkg = JSON.parse(readFileSync(join(src, 'package.json'), 'utf8'));
  const out = join(target, lib.dir ?? lib.name);
  for (const [from, to] of lib.files) {
    const fromPath = join(src, from);
    if (!existsSync(fromPath)) {
      throw new Error(`Missing ${fromPath}`);
    }
    const toPath = join(out, to);
    mkdirSync(dirname(toPath), { recursive: true });
    cpSync(fromPath, toPath, { recursive: true });
  }
  if (lib.name === 'katex') {
    inlineKatexFonts(out);
  }
  cpSync(join(src, lib.license), join(out, 'LICENSE'));
  notices.push(`- **${pkg.name}** ${pkg.version} (${pkg.license}) – ${pkg.homepage ?? ''}`);
}

writeFileSync(join(target, 'THIRD-PARTY-NOTICES.md'), notices.join('\n') + '\n');
console.log(`Vendored ${libraries.length} libraries into ${target}`);

// Embedded browsers treat file:// pages as opaque origins and block @font-face requests to sibling files, so the
// woff2 fonts are inlined as data URIs (all supported engines read woff2) and the legacy formats are dropped.
function inlineKatexFonts(dir) {
  const cssPath = join(dir, 'katex.min.css');
  const fontsDir = join(dir, 'fonts');
  let css = readFileSync(cssPath, 'utf8');
  css = css.replace(/src:url\(fonts\/([^)]+)\.woff2\) format\("woff2"\)[^;}]*/g, (_, name) => {
    const data = readFileSync(join(fontsDir, `${name}.woff2`)).toString('base64');
    return `src:url(data:font/woff2;base64,${data}) format("woff2")`;
  });
  if (css.includes('url(fonts/')) {
    throw new Error('Unexpected KaTeX font reference left in katex.min.css');
  }
  writeFileSync(cssPath, css);
  rmSync(fontsDir, { recursive: true, force: true });
  if (readdirSync(dir).includes('fonts')) {
    throw new Error('Could not remove KaTeX fonts folder');
  }
}
