// Runs the chat page in a real Chromium engine (Chrome / Edge, i.e. the engine of WebView2 on Windows) and checks
// what jsdom cannot: CSP, Mermaid rendering, sanitizing of diagram output and rendering performance.
//   npm run test:browser
import assert from 'node:assert/strict';
import { DARK_THEME, openChat, waitFor } from './harness.mjs';
import { RICH_ANSWER, richConversation } from '../fixtures/scenarios.mjs';

const results = [];

async function check(name, fn) {
  const started = Date.now();
  try {
    const detail = await fn();
    results.push({ name, ok: true, ms: Date.now() - started, detail });
  } catch (e) {
    results.push({ name, ok: false, ms: Date.now() - started, detail: e.message });
  }
}

async function renderAllDiagrams(chat) {
  await chat.page.evaluate(async () => {
    const s = document.getElementById('scroller');
    for (let y = 0; y <= s.scrollHeight; y += 500) {
      s.scrollTop = y;
      await new Promise((r) => setTimeout(r, 60));
    }
  });
  await waitFor(() => chat.page.evaluate(() =>
    document.querySelectorAll('.mermaid-block[data-state="pending"]').length === 0), 'diagrams', 30000);
}

await check('rich conversation renders without CSP violations or console errors', async () => {
  const chat = await openChat();
  try {
    await chat.send(richConversation());
    await chat.settle(300);
    await renderAllDiagrams(chat);
    const summary = await chat.page.evaluate(() => ({
      rendered: document.querySelectorAll('.mermaid-block[data-state="rendered"] .mermaid-block__diagram > svg').length,
      errors: document.querySelectorAll('.mermaid-block[data-state="error"]').length,
      tables: document.querySelectorAll('.md table').length,
      katex: document.querySelectorAll('.katex').length,
      highlighted: document.querySelectorAll('.code-block .hljs').length,
      xss: typeof window.__xss,
    }));
    assert.equal(summary.rendered, 5, 'flowchart, sequence, class, state and ER diagram');
    assert.equal(summary.errors, 1, 'the invalid diagram');
    assert.equal(summary.tables, 1);
    assert.ok(summary.katex >= 2);
    assert.ok(summary.highlighted >= 3);
    assert.equal(summary.xss, 'undefined');
    assert.deepEqual(chat.problems, []);
    return summary;
  } finally {
    await chat.close();
  }
});

await check('dark theme renders diagrams with the dark Mermaid theme', async () => {
  const chat = await openChat({ theme: DARK_THEME });
  try {
    await chat.send(richConversation());
    await renderAllDiagrams(chat);
    const theme = await chat.page.evaluate(() => document.documentElement.dataset.theme);
    assert.equal(theme, 'dark');
    assert.deepEqual(chat.problems, []);
  } finally {
    await chat.close();
  }
});

await check('Mermaid cannot execute script or add click handlers', async () => {
  const chat = await openChat();
  try {
    const diagram = [
      '```mermaid',
      'flowchart LR',
      '  A["<img src=x onerror=window.__mx=1>"] --> B["<script>window.__mx=2</script>"]',
      '  click A call window.__mxCall()',
      '  click B "javascript:window.__mx=3"',
      '```',
    ].join('\n');
    await chat.send([
      { type: 'turn.create', turnId: 'c', role: 'copilot', name: 'Copilot' },
      { type: 'md.append', turnId: 'c', text: diagram },
      { type: 'md.flush', turnId: 'c' },
    ]);
    await renderAllDiagrams(chat);
    await chat.page.evaluate(() => {
      for (const node of document.querySelectorAll('.mermaid-block__diagram *')) {
        node.dispatchEvent(new MouseEvent('click', { bubbles: true }));
      }
    });
    const state = await chat.page.evaluate(() => ({
      mx: typeof window.__mx,
      scripts: document.querySelectorAll('.mermaid-block script').length,
      handlers: document.querySelectorAll('.mermaid-block [onclick], .mermaid-block [onerror]').length,
      links: document.querySelectorAll('.mermaid-block a[href^="javascript"]').length,
    }));
    assert.deepEqual(state, { mx: 'undefined', scripts: 0, handlers: 0, links: 0 });
    return state;
  } finally {
    await chat.close();
  }
});

await check('streaming a long answer token by token keeps finished blocks stable', async () => {
  const chat = await openChat();
  try {
    await chat.send([{ type: 'turn.create', turnId: 'c', role: 'copilot', name: 'Copilot' }]);
    const text = RICH_ANSWER.repeat(3);
    const tokens = text.match(/.{1,6}/gs);
    const started = Date.now();
    // Java coalesces deltas per UI cycle; send small batches like a fast token stream.
    for (let i = 0; i < tokens.length; i += 8) {
      await chat.send(tokens.slice(i, i + 8).map((t) => ({ type: 'md.append', turnId: 'c', text: t })));
      if (i === 800) {
        await chat.settle(100);
        await chat.page.evaluate(() => {
          window.__firstHeading = document.querySelector('.turn--copilot h2');
          window.__firstCode = document.querySelector('.turn--copilot .code-block');
        });
      }
    }
    await chat.send([{ type: 'md.flush', turnId: 'c' }]);
    await chat.settle(300);
    const elapsed = Date.now() - started;
    const result = await chat.page.evaluate(() => ({
      captured: !!window.__firstHeading && !!window.__firstCode,
      sameHeading: window.__firstHeading === document.querySelector('.turn--copilot h2'),
      sameCode: window.__firstCode === document.querySelector('.turn--copilot .code-block'),
      headings: document.querySelectorAll('.turn--copilot h2').length,
      tables: document.querySelectorAll('.turn--copilot table').length,
    }));
    assert.ok(result.captured, 'blocks were rendered while streaming');
    assert.ok(result.sameHeading, 'the first heading node survived the stream');
    assert.ok(result.sameCode, 'the first code block survived the stream');
    assert.equal(result.headings, 3);
    assert.equal(result.tables, 3);
    return { tokens: tokens.length, elapsedMs: elapsed, ...result };
  } finally {
    await chat.close();
  }
});

await check('a restored history of 150 turns renders quickly', async () => {
  const chat = await openChat();
  try {
    const messages = [];
    for (let i = 0; i < 75; i++) {
      messages.push({ type: 'turn.create', turnId: 'u' + i, role: 'user', name: 'me' },
        { type: 'md.append', turnId: 'u' + i, text: 'Question ' + i },
        { type: 'md.flush', turnId: 'u' + i },
        { type: 'turn.create', turnId: 'c' + i, role: 'copilot', name: 'Copilot' },
        { type: 'md.append', turnId: 'c' + i, text: RICH_ANSWER.replace(/```mermaid[\s\S]*?```/g, '') },
        { type: 'tool.status', turnId: 'c' + i, toolId: 'x' + i, status: 'completed', message: 'Read file' },
        { type: 'md.flush', turnId: 'c' + i });
    }
    const started = Date.now();
    await chat.send(messages);
    await chat.settle(50);
    const elapsed = Date.now() - started;
    const turns = await chat.page.evaluate(() => document.querySelectorAll('.turn').length);
    assert.equal(turns, 150);
    assert.ok(elapsed < 15000, 'took ' + elapsed + ' ms');
    return { elapsedMs: elapsed };
  } finally {
    await chat.close();
  }
});

await check('a 1000-row table stays in a scrollable wrapper', async () => {
  const chat = await openChat({ width: 420 });
  try {
    const rows = Array.from({ length: 1000 }, (_, i) => `| ${i} | ${'cell '.repeat(12)} | ${'x'.repeat(60)} |`);
    await chat.send([
      { type: 'turn.create', turnId: 'c', role: 'copilot', name: 'Copilot' },
      { type: 'md.append', turnId: 'c', text: ['| # | Text | Long |', '|---|---|---|', ...rows].join('\n') },
      { type: 'md.flush', turnId: 'c' },
    ]);
    await chat.settle(200);
    const layout = await chat.page.evaluate(() => {
      const wrap = document.querySelector('.table-wrap');
      return { rows: wrap.querySelectorAll('tbody tr').length, scrolls: wrap.scrollWidth > wrap.clientWidth,
        pageOverflow: document.getElementById('scroller').scrollWidth > document.getElementById('scroller').clientWidth };
    });
    assert.equal(layout.rows, 1000);
    assert.equal(layout.pageOverflow, false, 'the page itself never scrolls horizontally');
    return layout;
  } finally {
    await chat.close();
  }
});

let failed = 0;
for (const r of results) {
  console.log(`${r.ok ? 'ok  ' : 'FAIL'} ${r.name} (${r.ms} ms)${r.detail ? ' ' + JSON.stringify(r.detail) : ''}`);
  if (!r.ok) {
    failed++;
  }
}
console.log(`${results.length - failed}/${results.length} passed`);
process.exit(failed ? 1 : 0);
