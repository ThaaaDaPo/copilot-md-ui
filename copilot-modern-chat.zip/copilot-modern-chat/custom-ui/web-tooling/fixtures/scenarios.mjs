// Protocol message sequences that mirror what the Java side sends for typical conversations.

export const RICH_ANSWER = `## Analysis of \`FlightService\`

The class has **three** responsibilities and one *subtle* ~~bug~~ issue. See [FlightService.java](file:///workspace/demo/src/FlightService.java#L42) and the [ABAP docs](https://help.sap.com/doc/abapdocu_latest_index_htm/latest/en-US/index.htm).

> Note: the cache is not invalidated when the carrier changes.

1. Load flights
2. Compute the price
   - with discounts
   - with taxes
3. Persist bookings

- [x] Reproduce the problem
- [ ] Write a regression test

| Carrier | Connection | From | To | Distance (km) | Comment |
|:--------|-----------:|------|----|--------------:|---------|
| LH | 0400 | Frankfurt | New York | 6,162 | A very long comment that should wrap nicely inside the table cell instead of stretching the table forever and ever |
| AA | 0017 | New York | San Francisco | 4,152 | |
| SQ | 0002 | Singapore | San Francisco | 13,593 | Longest non-stop connection in the sample data |

\`\`\`java
public final class FlightService {
    private final Map<String, Flight> cache = new ConcurrentHashMap<>();

    public Optional<Flight> find(String carrier, int connection) {
        return Optional.ofNullable(cache.get(carrier + connection)); // TODO invalidate
    }
}
\`\`\`

\`\`\`abap
CLASS zcl_flight_service DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    METHODS get_flights IMPORTING iv_carrid TYPE s_carr_id RETURNING VALUE(rt_flights) TYPE ty_flights.
ENDCLASS.

CLASS zcl_flight_service IMPLEMENTATION.
  METHOD get_flights.
    " Select all connections of the carrier
    SELECT carrid, connid, cityfrom, cityto
      FROM spfli
      WHERE carrid = @iv_carrid
      INTO CORRESPONDING FIELDS OF TABLE @rt_flights.
    IF sy-subrc <> 0.
      RAISE EXCEPTION NEW zcx_no_flights( carrid = iv_carrid ).
    ENDIF.
    LOOP AT rt_flights ASSIGNING FIELD-SYMBOL(<ls_flight>).
      <ls_flight>-label = |{ <ls_flight>-cityfrom } → { <ls_flight>-cityto }|.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.
\`\`\`

\`\`\`json
{"carrier":"LH","connections":[{"id":"0400","from":"FRA","to":"JFK"},{"id":"0401","from":"JFK","to":"FRA"}],"active":true}
\`\`\`

\`\`\`mermaid
flowchart LR
    A[Request] --> B{Cached?}
    B -- yes --> C[Return cached flight]
    B -- no --> D[(Database)]
    D --> E[Update cache]
    E --> C
\`\`\`

\`\`\`mermaid
sequenceDiagram
    participant U as User
    participant S as FlightService
    participant DB as Database
    U->>S: find("LH", 400)
    S->>DB: SELECT ...
    DB-->>S: Flight
    S-->>U: Optional<Flight>
\`\`\`

\`\`\`mermaid
classDiagram
    class FlightService {
      -Map cache
      +find(carrier, connection) Optional
    }
    class Flight {
      +String carrier
      +int connection
    }
    FlightService --> Flight
\`\`\`

\`\`\`mermaid
stateDiagram-v2
    [*] --> Draft
    Draft --> Booked: confirm
    Booked --> Cancelled: cancel
    Booked --> [*]
\`\`\`

\`\`\`mermaid
erDiagram
    CARRIER ||--o{ CONNECTION : operates
    CONNECTION ||--o{ FLIGHT : schedules
    FLIGHT ||--o{ BOOKING : has
\`\`\`

\`\`\`mermaid
flowchart TD
    this is not -> valid mermaid ((((
\`\`\`

The average load factor is $\\bar{x} = \\frac{1}{n}\\sum_{i=1}^{n} x_i$ and prices cost $5 or $10 (no math).

$$
P(\\text{delay}) = 1 - e^{-\\lambda t}
$$

---

Done. Raw HTML stays text: <img src=x onerror="window.__xss=1"> <script>window.__xss=2</script> and [a bad link](javascript:window.__xss=3).
`;

/** A complete agent-mode conversation as the Java side would send it. */
export function richConversation() {
  const user = 'turn-user-1';
  const copilot = 'turn-copilot-1';
  const sub = 'turn-copilot-1/sub/call-9';
  return [
    { type: 'turn.create', turnId: user, role: 'user', name: 'octocat' },
    { type: 'md.append', turnId: user, text: 'Why is FlightService returning stale data?\nPlease also draw the flow.' },
    { type: 'md.flush', turnId: user },
    { type: 'scroll.pin', turnId: user },
    { type: 'turn.create', turnId: copilot, role: 'copilot', name: 'GitHub Copilot' },
    { type: 'thinking.append', turnId: copilot, blockId: 't1', text: '**Inspecting the cache**\nThe cache key is built from carrier and connection, but invalidation never happens when bookings change.\n\n**Checking callers**\nThree callers rely on fresh data.' },
    { type: 'thinking.state', turnId: copilot, blockId: 't1', state: 'sealed' },
    { type: 'thinking.state', turnId: copilot, blockId: 't1', state: 'completed', title: 'Inspected cache invalidation' },
    { type: 'tool.status', turnId: copilot, toolId: 'call-1', status: 'completed', message: 'Read [FlightService.java](file:///workspace/demo/src/FlightService.java), lines 1 to 120', toolName: 'read_file' },
    { type: 'tool.status', turnId: copilot, toolId: 'call-2', status: 'completed', message: 'Searched for `cache.put` in workspace, 3 results', toolName: 'grep_search' },
    { type: 'tool.status', turnId: copilot, toolId: 'call-3', status: 'error', message: 'get_errors: Workspace not indexed yet', toolName: 'get_errors' },
    { type: 'turn.create', turnId: sub, role: 'subagent', name: 'Explore callers of FlightService', parentId: copilot },
    { type: 'md.append', turnId: sub, text: 'Found **3** callers: `BookingController`, `PriceJob`, `ReportExport`.' },
    { type: 'tool.status', turnId: sub, toolId: 'call-9a', status: 'completed', message: 'Listed directory `src/`', toolName: 'list_dir' },
    { type: 'subagent.state', turnId: sub, state: 'completed' },
    { type: 'md.append', turnId: copilot, text: RICH_ANSWER },
    { type: 'confirm.show', turnId: copilot, confirmId: 'c1', title: 'Run command in terminal?', message: 'Copilot wants to run the following command:', command: 'mvn -q test -Dtest=FlightServiceTest', commandKind: 'shell', explanation: 'Runs the regression test for the cache.', primary: { id: '0', label: 'Allow' }, alternatives: [{ id: '1', label: 'Allow in this Session' }, { id: '2', label: 'Always Allow' }], dismiss: { id: '3', label: 'Skip' } },
    { type: 'md.flush', turnId: copilot },
    { type: 'modelInfo', turnId: copilot, text: 'GPT-5 - Medium' },
  ];
}

export function warningAndErrors() {
  const user = 'turn-user-2';
  const copilot = 'turn-copilot-2';
  return [
    { type: 'turn.create', turnId: user, role: 'user', name: 'octocat' },
    { type: 'md.append', turnId: user, text: 'Refactor the booking module' },
    { type: 'md.flush', turnId: user },
    { type: 'turn.create', turnId: copilot, role: 'copilot', name: 'GitHub Copilot' },
    { type: 'tool.status', turnId: copilot, toolId: 'x1', status: 'running', message: 'Editing `BookingService.java`', toolName: 'edit_file' },
    { type: 'compacting', turnId: copilot, visible: true, label: 'Compacting conversation...' },
    { type: 'warn.show', turnId: copilot, message: 'You have reached your monthly limit of **premium requests**.', actions: [{ id: 'a1', label: 'Enable Additional Usage', tooltip: 'Opens GitHub settings', primary: true }, { id: 'a2', label: 'Upgrade Plan', primary: false }] },
    { type: 'agentMessage.show', turnId: copilot, title: 'Copilot coding agent started a pull request', description: 'Refactor booking module to use the new repository pattern and add tests...', actions: [{ id: 'a3', label: 'Open in Browser', primary: true }, { id: 'a4', label: 'Open Job List', primary: false }] },
    { type: 'error.show', message: 'Request failed: connection reset (Request ID: 1234)' },
  ];
}
