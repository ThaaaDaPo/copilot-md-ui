import assert from 'node:assert/strict';
import { after, before, describe, test } from 'node:test';
import { loadPage } from './helpers.mjs';

describe('syntax highlighting', () => {
  let page;
  let hljs;
  before(async () => {
    page = await loadPage();
    hljs = page.window.hljs;
  });
  after(() => page.close());

  /** Returns the texts highlighted with the given scope. */
  function tokens(code, language, scope) {
    const container = page.document.createElement('div');
    container.innerHTML = hljs.highlight(code, { language }).value;
    return Array.from(container.querySelectorAll(`.hljs-${scope}`)).map((n) => n.textContent);
  }

  test('ABAP statements, comments and literals', () => {
    const code = [
      '* full line comment',
      'DATA lv_count TYPE i VALUE 0. " trailing comment',
      "WRITE 'It''s'.",
      'lv_text = |Name: { lv_name }|.',
      'SELECT * FROM spfli INTO TABLE @DATA(lt_data) WHERE carrid = @lv_carrid.',
      'LOOP AT lt_data ASSIGNING FIELD-SYMBOL(<ls_row>). ENDLOOP.',
      'lo_obj = zcl_factory=>create( ). lo_obj->run( ).',
      'IF sy-subrc <> 0. ENDIF. ##NEEDED',
    ].join('\n');
    const keywords = tokens(code, 'abap', 'keyword').map((k) => k.toUpperCase());
    for (const k of ['DATA', 'TYPE', 'VALUE', 'WRITE', 'SELECT', 'FROM', 'INTO', 'TABLE', 'WHERE', 'LOOP', 'AT',
      'ASSIGNING', 'FIELD-SYMBOL', 'ENDLOOP', 'IF', 'ENDIF']) {
      assert.ok(keywords.includes(k), k);
    }
    const comments = tokens(code, 'abap', 'comment');
    assert.ok(comments.includes('* full line comment'));
    assert.ok(comments.some((c) => c.startsWith('" trailing')));
    const strings = tokens(code, 'abap', 'string');
    assert.ok(strings.includes("'It''s'"));
    assert.ok(strings.some((s) => s.startsWith('|Name:')));
    assert.ok(tokens(code, 'abap', 'variable').includes('<ls_row>'));
    assert.ok(tokens(code, 'abap', 'variable').includes('@lv_carrid'));
    assert.ok(tokens(code, 'abap', 'built_in').includes('sy-subrc'));
    assert.ok(tokens(code, 'abap', 'meta').includes('##NEEDED'));
    assert.ok(tokens(code, 'abap', 'title class_').length === 0 || true);
    const container = page.document.createElement('div');
    container.innerHTML = hljs.highlight(code, { language: 'abap' }).value;
    assert.equal(container.querySelector('.hljs-title.class_').textContent, 'zcl_factory');
    assert.deepEqual(Array.from(container.querySelectorAll('.hljs-title.function_')).map((n) => n.textContent),
      ['create', 'run']);
  });

  test('a structure component is not a comment or keyword', () => {
    const container = page.document.createElement('div');
    container.innerHTML = hljs.highlight('ls_data-carrid = 1.', { language: 'abap' }).value;
    assert.equal(container.querySelector('.hljs-comment'), null);
    assert.equal(container.querySelector('.hljs-keyword'), null);
  });

  test('ABAP CDS', () => {
    const code = "@AbapCatalog.sqlViewName: 'ZV'\ndefine view entity ZI_A as select from spfli { key carrid } // c";
    assert.ok(tokens(code, 'cds', 'meta').includes('@AbapCatalog.sqlViewName'));
    assert.ok(tokens(code, 'cds', 'keyword').includes('define'));
    assert.ok(tokens(code, 'cds', 'comment').includes('// c'));
  });

  test('aliases resolve to languages', () => {
    const resolve = page.CC.code.resolveLanguage;
    const nameOf = (alias) => {
      const key = resolve(alias);
      return key ? hljs.getLanguage(key).name : null;
    };
    assert.equal(nameOf('abap'), 'ABAP');
    assert.equal(nameOf('ABAP'), 'ABAP');
    assert.equal(nameOf('acds'), 'ABAP CDS');
    assert.equal(nameOf('sh'), 'Bash');
    assert.equal(nameOf('zsh'), 'Bash');
    assert.equal(nameOf('ts'), 'TypeScript');
    assert.equal(nameOf('yml'), 'YAML');
    assert.equal(nameOf('pwsh'), 'PowerShell');
    assert.equal(nameOf('plsql'), 'SQL');
    assert.equal(nameOf('nonexistent'), null);
  });
});
