import assert from 'node:assert/strict';
import { after, before, describe, test } from 'node:test';
import { loadPage, renderMarkdown } from './helpers.mjs';

describe('markdown rendering', () => {
  let page;
  before(async () => {
    page = await loadPage();
  });
  after(() => page.close());

  test('renders the common markdown elements', () => {
    const md = renderMarkdown(page, [
      '# Title', '## Sub', '**bold** *italic* ~~gone~~ `code`', '', '- a', '- b', '', '1. one', '2. two', '',
      '> quote', '', '---', '', '[link](https://example.com)',
    ].join('\n'));
    assert.equal(md.querySelector('h1').textContent, 'Title');
    assert.ok(md.querySelector('h2'));
    assert.ok(md.querySelector('strong'));
    assert.ok(md.querySelector('em'));
    assert.ok(md.querySelector('s'));
    assert.equal(md.querySelector('p code').textContent, 'code');
    assert.equal(md.querySelectorAll('ul li').length, 2);
    assert.equal(md.querySelectorAll('ol li').length, 2);
    assert.ok(md.querySelector('blockquote'));
    assert.ok(md.querySelector('hr'));
    assert.equal(md.querySelector('a').getAttribute('href'), 'https://example.com');
    assert.equal(md.querySelector('a').getAttribute('rel'), 'noopener noreferrer');
  });

  test('tables become real tables inside a horizontally scrollable wrapper', () => {
    const rows = Array.from({ length: 200 }, (_, i) => `| ${i} | ${'long text '.repeat(20)} | ${i * 2} |`);
    const md = renderMarkdown(page, ['| # | Text | Value |', '|---|:---|---:|', ...rows].join('\n'));
    const wrap = md.querySelector('.table-wrap');
    assert.ok(wrap);
    assert.equal(wrap.querySelectorAll('tbody tr').length, 200);
    assert.equal(wrap.querySelectorAll('thead th').length, 3);
    assert.match(wrap.querySelector('td:last-child').getAttribute('style'), /right/);
  });

  test('raw HTML from the model is shown as text', () => {
    const md = renderMarkdown(page, 'x <img src=x onerror="alert(1)"> <script>alert(2)</script> <b>b</b>');
    assert.equal(md.querySelector('img'), null);
    assert.equal(md.querySelector('script'), null);
    assert.equal(md.querySelector('b'), null);
    assert.match(md.textContent, /<img src=x onerror="alert\(1\)">/);
  });

  test('dangerous link schemes are not linked', () => {
    for (const href of ['javascript:alert(1)', 'JAVASCRIPT:alert(1)', 'vbscript:x', 'data:text/html,<script>']) {
      const md = renderMarkdown(page, `[click](${href})`);
      const a = md.querySelector('a');
      assert.ok(!a || !a.getAttribute('href') || !/^(javascript|vbscript|data):/i.test(a.getAttribute('href')),
        href);
    }
  });

  test('file links are marked and kept clickable', () => {
    const md = renderMarkdown(page, '[Foo.java](file:///w/src/Foo.java#L3) and [Bar](src/Bar.java)');
    const links = md.querySelectorAll('a.file-link');
    assert.equal(links.length, 2);
    assert.equal(links[0].getAttribute('href'), 'file:///w/src/Foo.java#L3');
  });

  test('file names are not turned into web links', () => {
    const md = renderMarkdown(page, 'See README.md, setup.py and https://github.com');
    const links = md.querySelectorAll('a');
    assert.equal(links.length, 1);
    assert.equal(links[0].getAttribute('href'), 'https://github.com');
  });

  test('images are shown as links and never loaded', () => {
    const md = renderMarkdown(page, '![diagram](https://tracker.example/pixel.png)');
    assert.equal(md.querySelector('img'), null);
    assert.equal(md.querySelector('a.img-link').getAttribute('href'), 'https://tracker.example/pixel.png');
  });

  test('task lists render check boxes', () => {
    const md = renderMarkdown(page, '- [x] done\n- [ ] open\n- normal');
    assert.equal(md.querySelectorAll('.task-item').length, 2);
    assert.equal(md.querySelectorAll('.task-box.is-checked').length, 1);
    assert.match(md.querySelectorAll('li')[0].textContent, /^done/);
  });

  test('code blocks get a header with language, copy and insert', () => {
    const md = renderMarkdown(page, '```java\nclass A {}\n```');
    const block = md.querySelector('.code-block');
    assert.equal(block.getAttribute('data-lang'), 'java');
    assert.equal(block.querySelector('.code-block__lang').textContent, 'java');
    assert.ok(block.querySelector('[data-action="copy"]'));
    assert.ok(block.querySelector('[data-action="insert"]'));
    assert.equal(block.querySelector('pre code').textContent, 'class A {}\n');
  });

  test('an unfinished fence is rendered as streaming code, not as a diagram', () => {
    const streaming = renderMarkdown(page, 'text\n```mermaid\nflowchart LR\n  A --> B', false);
    assert.ok(streaming.querySelector('.code-block.is-streaming'));
    assert.equal(streaming.querySelector('.mermaid-block'), null);
    const closed = renderMarkdown(page, 'text\n```mermaid\nflowchart LR\n  A --> B\n```', false);
    assert.ok(closed.querySelector('.mermaid-block'));
    assert.equal(closed.querySelector('.mermaid-block__source code').textContent, 'flowchart LR\n  A --> B\n');
  });

  test('mermaid can be disabled', async () => {
    const disabled = await loadPage({ features: { mermaid: false, math: true } });
    const md = renderMarkdown(disabled, '```mermaid\nflowchart LR\n  A --> B\n```');
    assert.equal(md.querySelector('.mermaid-block'), null);
    assert.ok(md.querySelector('.code-block'));
    disabled.close();
  });

  test('math is rendered with KaTeX, prices are not math', () => {
    const md = renderMarkdown(page, 'Inline $a^2+b^2$ and \\(x\\) but $5 and $10 stay.\n\n$$\n\\frac{1}{2}\n$$');
    assert.equal(md.querySelectorAll('.katex').length, 3);
    assert.ok(md.querySelector('.math-block .katex-display'));
    assert.match(md.textContent, /\$5 and \$10 stay/);
  });

  test('math inside code is left alone', () => {
    const md = renderMarkdown(page, '`$x$` and\n\n```sh\necho $HOME $PATH\n```');
    assert.equal(md.querySelectorAll('.katex').length, 0);
  });

  test('KaTeX cannot be used to inject links or HTML', () => {
    const md = renderMarkdown(page, '$\\href{javascript:alert(1)}{x}$ $\\htmlId{a}{b}$');
    assert.equal(md.querySelector('a[href^="javascript"]'), null);
    assert.equal(md.querySelector('#a'), null);
  });
});
