import assert from 'node:assert/strict';
import { afterEach, beforeEach, describe, test } from 'node:test';
import { loadPage } from './helpers.mjs';

describe('chat page', () => {
  let page;
  beforeEach(async () => {
    page = await loadPage();
  });
  afterEach(() => page.close());

  const $ = (selector) => page.document.querySelector(selector);
  const $$ = (selector) => page.document.querySelectorAll(selector);

  test('announces itself to Java', () => {
    const ready = page.posted.find((m) => m.type === 'ready');
    assert.ok(ready);
    assert.equal(ready.payload.protocol, 1);
    assert.ok(ready.payload.instanceId);
  });

  test('renders user and copilot turns from streamed messages', async () => {
    page.send([
      { type: 'turn.create', turnId: 'u', role: 'user', name: 'octocat' },
      { type: 'md.append', turnId: 'u', text: 'Hi **there**' },
      { type: 'md.flush', turnId: 'u' },
      { type: 'turn.create', turnId: 'c', role: 'copilot', name: 'GitHub Copilot' },
    ]);
    for (const piece of ['# Ans', 'wer\n\n| a | b |\n|---', '|---|\n| 1 | 2 |\n']) {
      page.send([{ type: 'md.append', turnId: 'c', text: piece }]);
    }
    page.send([{ type: 'md.flush', turnId: 'c' }]);
    await page.settle();

    assert.equal($$('.turn').length, 2);
    // User text is plain text, like in the classic view.
    assert.equal($('.user-text').textContent, 'Hi **there**');
    assert.equal($('.turn--copilot h1').textContent, 'Answer');
    assert.equal($$('.turn--copilot table td').length, 2);
  });

  test('streaming keeps already rendered blocks untouched', async () => {
    page.send([{ type: 'turn.create', turnId: 'c', role: 'copilot', name: 'Copilot' },
      { type: 'md.append', turnId: 'c', text: 'First paragraph.\n\n```java\nclass A {}\n```\n\nSecond' }]);
    await page.settle();
    const firstParagraph = $('.turn--copilot .md p');
    const codeBlock = $('.turn--copilot .code-block');
    page.send([{ type: 'md.append', turnId: 'c', text: ' paragraph grows' }]);
    await page.settle();
    assert.equal($('.turn--copilot .md p'), firstParagraph, 'same node');
    assert.equal($('.turn--copilot .code-block'), codeBlock, 'same node');
    assert.match($$('.turn--copilot .md p')[1].textContent, /Second paragraph grows/);
  });

  test('tool calls split the text into segments and update in place', async () => {
    page.send([
      { type: 'turn.create', turnId: 'c', role: 'copilot', name: 'Copilot' },
      { type: 'md.append', turnId: 'c', text: 'Before' },
      { type: 'tool.status', turnId: 'c', toolId: 't1', status: 'running', message: 'Reading `A.java`' },
      { type: 'md.append', turnId: 'c', text: 'After' },
      { type: 'tool.status', turnId: 'c', toolId: 't1', status: 'completed', message: 'Read `A.java`' },
    ]);
    await page.settle();
    const body = $('.turn--copilot .turn__body');
    const kinds = Array.from(body.children).map((n) => n.className.split(' ')[0]);
    assert.deepEqual(kinds, ['md', 'tool', 'md']);
    assert.ok($('.tool.tool--completed'));
    assert.equal($('.tool code').textContent, 'A.java');
  });

  test('sub-agents get a nested block', async () => {
    page.send([
      { type: 'turn.create', turnId: 'c', role: 'copilot', name: 'Copilot' },
      { type: 'turn.create', turnId: 's', role: 'subagent', name: 'Explore', parentId: 'c' },
      { type: 'md.append', turnId: 's', text: 'nested' },
      { type: 'subagent.state', turnId: 's', state: 'completed' },
    ]);
    await page.settle();
    assert.equal($('.subagent .subagent__title').textContent, 'Explore');
    assert.ok($('.subagent.is-completed'));
    assert.equal($('.subagent .md').textContent.trim(), 'nested');
  });

  test('thinking blocks stream, collapse when sealed and show the title', async () => {
    page.send([
      { type: 'turn.create', turnId: 'c', role: 'copilot', name: 'Copilot' },
      { type: 'thinking.append', turnId: 'c', blockId: 'b1', text: '**Plan**\nstep 1' },
    ]);
    await page.settle();
    assert.ok($('.thinking.is-streaming'));
    page.send([{ type: 'thinking.state', turnId: 'c', blockId: 'b1', state: 'completed', title: 'Planned' }]);
    assert.ok($('.thinking.is-completed.is-collapsed'));
    assert.equal($('.thinking__title').textContent, 'Planned');
    $('.thinking__header').click();
    assert.ok(!$('.thinking').classList.contains('is-collapsed'));
  });

  test('confirmation buttons answer with the chosen action', () => {
    page.send([
      { type: 'turn.create', turnId: 'c', role: 'copilot', name: 'Copilot' },
      { type: 'confirm.show', turnId: 'c', confirmId: 'k', title: 'Run?', command: 'ls', primary: { id: '0', label: 'Allow' },
        alternatives: [{ id: '1', label: 'Allow in Session' }], dismiss: { id: '2', label: 'Skip' } },
    ]);
    assert.equal($('.confirm__command').textContent, 'ls');
    $('.split-button__arrow').click();
    assert.equal($('.split-button__menu').hidden, false);
    $('.menu-item').click();
    const answer = page.posted.find((m) => m.type === 'confirm');
    assert.deepEqual(answer.payload, { confirmId: 'k', choice: '1' });
    // Buttons are disabled until Java closes the confirmation.
    assert.ok($('.confirm.is-pending'));
    page.send([{ type: 'confirm.close', turnId: 'c', confirmId: 'k', cancelMessage: 'ls' }]);
    assert.equal($('.confirm'), null);
    assert.equal($('.tool--cancelled .tool__message').textContent, 'ls');
  });

  test('links and code buttons are forwarded to Java', async () => {
    page.send([
      { type: 'turn.create', turnId: 'c', role: 'copilot', name: 'Copilot' },
      { type: 'md.append', turnId: 'c', text: '[Foo](file:///Foo.java)\n\n```java\nint a;\n```\n\n```py\nb = 1\n```' },
      { type: 'md.flush', turnId: 'c' },
    ]);
    await page.settle();
    $('a.file-link').click();
    $$('.code-block [data-action="copy"]')[1].click();
    $('.code-block [data-action="insert"]').click();
    const types = page.posted.map((m) => m.type);
    assert.ok(types.includes('openLink'));
    const copy = page.posted.find((m) => m.type === 'copyCode');
    assert.deepEqual(copy.payload, { turnId: 'c', blockIndex: 2, code: 'b = 1\n' });
    assert.equal(page.posted.find((m) => m.type === 'insertCode').payload.code, 'int a;\n');
  });

  test('warnings and agent cards trigger only registered actions', () => {
    page.send([
      { type: 'turn.create', turnId: 'c', role: 'copilot', name: 'Copilot' },
      { type: 'warn.show', turnId: 'c', message: 'Limit **reached**', actions: [{ id: 'a1', label: 'Upgrade', primary: true }] },
    ]);
    assert.equal($('.notice--warning strong').textContent, 'reached');
    $('.notice--warning .btn').click();
    assert.deepEqual(page.posted.find((m) => m.type === 'action').payload, { id: 'a1' });
  });

  test('a failing message does not stop the rest of the batch', async () => {
    page.send([
      { type: 'md.append', turnId: 'missing', text: 'lost' },
      { type: 'no.such.type' },
      { type: 'turn.create', turnId: 'c', role: 'copilot', name: 'Copilot' },
      { type: 'md.append', turnId: 'c', text: 'still works' },
    ]);
    await page.settle();
    assert.equal($('.turn--copilot .md').textContent.trim(), 'still works');
    assert.ok(page.posted.some((m) => m.type === 'log' && /Unknown message type/.test(m.payload.message)));
  });

  test('the error banner stays below the newest turn', () => {
    page.send([
      { type: 'turn.create', turnId: 'c', role: 'copilot', name: 'Copilot' },
      { type: 'error.show', message: 'boom' },
      { type: 'turn.create', turnId: 'u2', role: 'user', name: 'me' },
    ]);
    const children = Array.from($('#conversation').children);
    assert.ok(children.at(-1).classList.contains('notice--error'));
    page.send([{ type: 'error.show', message: 'again' }]);
    assert.equal($$('.notice--error').length, 1);
  });

  test('reload shortcuts are blocked', () => {
    for (const init of [{ key: 'F5' }, { key: 'r', ctrlKey: true }, { key: 'r', metaKey: true }]) {
      const event = new page.window.KeyboardEvent('keydown', { ...init, cancelable: true, bubbles: true });
      page.document.dispatchEvent(event);
      assert.ok(event.defaultPrevented, JSON.stringify(init));
    }
  });
});
