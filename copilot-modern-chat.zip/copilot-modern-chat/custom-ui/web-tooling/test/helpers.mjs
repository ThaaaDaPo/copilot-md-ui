// Loads web/index.html with all its scripts into a jsdom window. The page talks to a fake Java side that records
// every posted message.
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { JSDOM } from 'jsdom';
import { WEB_ROOT } from '../scripts/harness.mjs';

const indexHtml = readFileSync(join(WEB_ROOT, 'index.html'), 'utf8');
const scriptSources = [...indexHtml.matchAll(/<script src="([^"]+)"><\/script>/g)].map((m) => m[1]);
const bodyHtml = indexHtml.replace(/<script[^>]*><\/script>/g, '');

export async function loadPage({ features = { mermaid: true, math: true } } = {}) {
  const dom = new JSDOM(bodyHtml, {
    url: pathToFileURL(join(WEB_ROOT, 'index.html')).href,
    runScripts: 'outside-only',
    pretendToBeVisual: true,
  });
  const window = dom.window;
  const posted = [];
  window.__copilotChatPost = (json) => posted.push(JSON.parse(json));
  for (const src of scriptSources) {
    window.eval(readFileSync(join(WEB_ROOT, src), 'utf8'));
  }
  // Like Java: initialize only after the page announced itself.
  for (let i = 0; i < 200 && !posted.some((m) => m.type === 'ready'); i++) {
    await new Promise((resolve) => window.setTimeout(resolve, 10));
  }
  if (!posted.some((m) => m.type === 'ready')) {
    throw new Error('page did not announce itself');
  }
  const CC = window.CopilotChat;
  CC.receive([{ type: 'init', protocol: 1, theme: { dark: false, background: '#ffffff', foreground: '#1f1f1f' },
    features, labels: {} }]);
  return {
    window,
    document: window.document,
    CC,
    posted,
    send: (messages) => CC.receive(messages),
    /** Waits until pending renders (rAF and the streaming throttle) ran. */
    settle: (ms = 120) => new Promise((resolve) => window.setTimeout(resolve, ms)),
    close: () => window.close(),
  };
}

/** Renders markdown with the page's renderer and returns a detached container with the result. */
export function renderMarkdown(page, src, final = true) {
  const container = page.document.createElement('div');
  container.innerHTML = page.CC.markdown.render(src, { final });
  return container;
}
