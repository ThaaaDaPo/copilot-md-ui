package custom.copilot.webchat.actions;

import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.texteditor.IDocumentProvider;
import org.eclipse.ui.texteditor.ITextEditor;

import com.microsoft.copilot.eclipse.core.lsp.CopilotLanguageServerConnection;
import com.microsoft.copilot.eclipse.core.lsp.protocol.ConversationCodeCopyParams;
import com.microsoft.copilot.eclipse.ui.utils.SwtUtils;

import custom.copilot.webchat.WebChatPlugin;

/**
 * Copy and insert actions of code blocks, equivalent to the buttons of the classic {@code SourceViewerComposite}.
 */
public final class CodeActions {

  private CodeActions() {
  }

  /**
   * Copy code to the clipboard and report the copy to the language server (same telemetry as the classic view).
   *
   * @param control any control of the view (for the display)
   * @param ls the language server connection, may be {@code null}
   * @param turnId the turn id of the code block's turn
   * @param codeBlockIndex the 1-based index of the code block in its turn
   * @param code the code
   */
  public static void copy(Control control, CopilotLanguageServerConnection ls, String turnId, int codeBlockIndex,
      String code) {
    if (StringUtils.isEmpty(code)) {
      return;
    }
    SwtUtils.copyToClipboard(control, code);
    if (ls != null && StringUtils.isNotBlank(turnId)) {
      ls.codeCopy(new ConversationCodeCopyParams(turnId, codeBlockIndex, ConversationCodeCopyParams.COPY_SOURCE_TOOLBAR,
          code.length(), code.length(), code));
    }
  }

  /**
   * Insert code at the caret of the active text editor, replacing the selection.
   *
   * @param control any control of the view (for dialogs)
   * @param code the code
   */
  public static void insert(Control control, String code) {
    if (StringUtils.isEmpty(code)) {
      return;
    }
    IEditorPart editor = SwtUtils.getActiveEditorPart();
    if (editor == null) {
      MessageDialog.openError(control.getShell(), "Cannot Insert", "No active editor found.");
      return;
    }
    ITextEditor textEditor = editor instanceof ITextEditor text ? text : editor.getAdapter(ITextEditor.class);
    if (textEditor == null) {
      MessageDialog.openError(control.getShell(), "Cannot Insert", "The active editor doesn't support text insertion.");
      return;
    }
    IDocumentProvider provider = textEditor.getDocumentProvider();
    IDocument document = Optional.ofNullable(provider).map(p -> p.getDocument(textEditor.getEditorInput()))
        .orElse(null);
    if (document == null) {
      MessageDialog.openError(control.getShell(), "Cannot Insert",
          "Failed to get the document from the active editor.");
      return;
    }
    ISelection selection = textEditor.getSelectionProvider().getSelection();
    if (!(selection instanceof ITextSelection textSelection)) {
      return;
    }
    try {
      int offset = textSelection.getOffset();
      document.replace(offset, textSelection.getLength(), code);
      textEditor.selectAndReveal(offset + code.length(), 0);
    } catch (BadLocationException e) {
      WebChatPlugin.logError("Failed to insert code into editor", e);
      MessageDialog.openError(control.getShell(), "Insert Failed",
          "An error occurred while inserting the code: " + e.getMessage());
    }
  }
}
