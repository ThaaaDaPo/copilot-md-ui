package custom.copilot.webchat.preferences;

import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
import org.eclipse.jface.preference.IPreferenceStore;

import custom.copilot.webchat.WebChatPlugin;

/**
 * Preference keys and defaults.
 */
public class WebChatPreferences extends AbstractPreferenceInitializer {

  /** Use the web chat instead of the classic chat content. */
  public static final String ENABLED = "enabled";
  /** Render Mermaid code blocks as diagrams. */
  public static final String MERMAID = "mermaid";
  /** Render TeX math with KaTeX. */
  public static final String MATH = "math";

  @Override
  public void initializeDefaultPreferences() {
    IPreferenceStore store = WebChatPlugin.getDefault().getPreferenceStore();
    store.setDefault(ENABLED, true);
    store.setDefault(MERMAID, true);
    store.setDefault(MATH, true);
  }

  /** Read a boolean preference; defaults to {@code true} when the plug-in is not active. */
  public static boolean get(String key) {
    WebChatPlugin plugin = WebChatPlugin.getDefault();
    return plugin == null || plugin.getPreferenceStore().getBoolean(key);
  }
}
