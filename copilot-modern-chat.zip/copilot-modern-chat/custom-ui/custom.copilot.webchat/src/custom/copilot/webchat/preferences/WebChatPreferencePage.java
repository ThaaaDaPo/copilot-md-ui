package custom.copilot.webchat.preferences;

import org.eclipse.jface.preference.BooleanFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import custom.copilot.webchat.Messages;
import custom.copilot.webchat.WebChatPlugin;

/**
 * Preference page "GitHub Copilot > Chat View".
 */
public class WebChatPreferencePage extends FieldEditorPreferencePage implements IWorkbenchPreferencePage {

  /** Create the page. */
  public WebChatPreferencePage() {
    super(GRID);
    setPreferenceStore(WebChatPlugin.getDefault().getPreferenceStore());
    setDescription(Messages.preferences_description);
  }

  @Override
  protected void createFieldEditors() {
    addField(new BooleanFieldEditor(WebChatPreferences.ENABLED, Messages.preferences_enabled, getFieldEditorParent()));
    addField(new BooleanFieldEditor(WebChatPreferences.MERMAID, Messages.preferences_mermaid, getFieldEditorParent()));
    addField(new BooleanFieldEditor(WebChatPreferences.MATH, Messages.preferences_math, getFieldEditorParent()));
    Label hint = new Label(getFieldEditorParent(), SWT.WRAP);
    hint.setText(Messages.preferences_restartHint);
    GridData data = new GridData(SWT.FILL, SWT.TOP, true, false, 2, 1);
    data.widthHint = 300;
    data.verticalIndent = 8;
    hint.setLayoutData(data);
  }

  @Override
  public void init(IWorkbench workbench) {
    // nothing to initialize
  }
}
