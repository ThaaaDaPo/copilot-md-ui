package custom.copilot.webchat;

import org.eclipse.osgi.util.NLS;

/**
 * Translatable texts of the web chat.
 */
public final class Messages extends NLS {
  private static final String BUNDLE_NAME = "custom.copilot.webchat.messages"; //$NON-NLS-1$

  public static String web_copy;
  public static String web_copyCode;
  public static String web_copied;
  public static String web_insert;
  public static String web_plainText;
  public static String web_mermaid;
  public static String web_showDiagram;
  public static String web_showSource;
  public static String web_diagram;
  public static String web_renderingDiagram;
  public static String web_diagramError;
  public static String web_diagramTooLarge;
  public static String web_showAllLines;
  public static String web_showLess;
  public static String web_subagent;
  public static String web_moreOptions;
  public static String web_copyResponse;
  public static String web_scrollToBottom;
  public static String web_conversation;
  public static String web_responding;
  public static String web_responseComplete;
  public static String menu_copy;
  public static String menu_selectAll;
  public static String preferences_description;
  public static String preferences_enabled;
  public static String preferences_mermaid;
  public static String preferences_math;
  public static String preferences_restartHint;

  static {
    NLS.initializeMessages(BUNDLE_NAME, Messages.class);
  }

  private Messages() {
  }
}
