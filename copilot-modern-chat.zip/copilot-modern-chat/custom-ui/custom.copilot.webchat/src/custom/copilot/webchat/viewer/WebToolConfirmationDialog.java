package custom.copilot.webchat.viewer;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.swt.widgets.Composite;

import com.microsoft.copilot.eclipse.core.chat.ConfirmationAction;
import com.microsoft.copilot.eclipse.core.chat.ConfirmationContent;
import com.microsoft.copilot.eclipse.core.lsp.protocol.LanguageModelToolConfirmationResult;
import com.microsoft.copilot.eclipse.core.lsp.protocol.LanguageModelToolConfirmationResult.ToolConfirmationResult;
import com.microsoft.copilot.eclipse.ui.chat.InvokeToolConfirmationDialog;
import com.microsoft.copilot.eclipse.ui.chat.Messages;

import custom.copilot.webchat.bridge.Protocol;

/**
 * Tool confirmation rendered in the page.
 *
 * <p>Extends the classic dialog so that every caller keeps working unchanged: {@code AgentToolService} reads
 * {@link #getSelectedAction()} to remember "allow for this session / always" decisions, and
 * {@code BaseTurnWidget#cancelToolConfirmation()} calls {@link #cancelConfirmation()}. The inherited SWT content is
 * created inside the hidden widget tree and never shown.
 */
public class WebToolConfirmationDialog extends InvokeToolConfirmationDialog {

  private static final String EXPLANATION_KEY = "explanation";
  private static final String COMMAND_KEY = "command";
  private static final String ACTION_KEY = "action";
  /** Choice id of the dismiss button when the content has no dismiss action. */
  static final String DEFAULT_DISMISS = "-1";

  private final TurnPresenter presenter;
  private final List<ConfirmationAction> actions;
  private final String confirmationId;
  private final String cancelMessage;
  private ConfirmationAction selectedAction;
  private boolean closed;

  /**
   * Create the confirmation and show it in the page.
   *
   * @param hiddenParent the (hidden) turn widget
   * @param content the confirmation content
   * @param input the tool input
   * @param presenter the presenter of the turn
   */
  public WebToolConfirmationDialog(Composite hiddenParent, ConfirmationContent content, Object input,
      TurnPresenter presenter) {
    super(hiddenParent, content, input);
    this.presenter = presenter;
    this.actions = content.getActions() != null ? content.getActions() : List.of();
    String command = commandOf(input);
    this.cancelMessage = command;
    this.confirmationId = presenter.surface().registerConfirmation(this);
    show(content, input, command);
  }

  @SuppressWarnings("unchecked")
  private static String commandOf(Object input) {
    if (!(input instanceof Map<?, ?> map)) {
      return null;
    }
    Map<String, Object> inputMap = (Map<String, Object>) map;
    if (inputMap.containsKey(ACTION_KEY)) {
      return new GsonBuilder().setPrettyPrinting().create().toJson(inputMap);
    }
    Object command = inputMap.get(COMMAND_KEY);
    return command instanceof String text ? text : null;
  }

  private void show(ConfirmationContent content, Object input, String command) {
    JsonObject msg = new JsonObject();
    msg.addProperty("turnId", presenter.domId());
    msg.addProperty("confirmId", confirmationId);
    msg.addProperty("title", StringUtils.defaultString(content.getTitle()));
    if (content.getMessage() != null) {
      msg.addProperty("message", content.getMessage());
    }
    if (command != null) {
      msg.addProperty("command", command);
      msg.addProperty("commandKind", input instanceof Map<?, ?> map && map.containsKey(ACTION_KEY) ? "json" : "shell");
    }
    if (input instanceof Map<?, ?> map && map.get(EXPLANATION_KEY) instanceof String explanation) {
      msg.addProperty("explanation", explanation);
    }

    // Same button layout as the classic dialog: the primary accept action, other accept actions in its drop-down,
    // and the dismiss action. Without a primary action the classic dialog shows no buttons.
    int primary = -1;
    int dismiss = -1;
    JsonArray alternatives = new JsonArray();
    for (int i = 0; i < actions.size(); i++) {
      ConfirmationAction action = actions.get(i);
      if (!action.isAccept()) {
        dismiss = i;
      } else if (action.isPrimary()) {
        primary = i;
      }
    }
    for (int i = 0; i < actions.size(); i++) {
      ConfirmationAction action = actions.get(i);
      if (action.isAccept() && i != primary && !action.isPrimary()) {
        alternatives.add(choice(String.valueOf(i), action.getLabel()));
      }
    }
    if (primary >= 0) {
      msg.add("primary", choice(String.valueOf(primary), actions.get(primary).getLabel()));
      msg.add("alternatives", alternatives);
      msg.add("dismiss", dismiss >= 0 ? choice(String.valueOf(dismiss), actions.get(dismiss).getLabel())
          : choice(DEFAULT_DISMISS, Messages.confirmation_action_skip));
    }
    presenter.surface().post(Protocol.OUT_CONFIRM_SHOW, msg);
  }

  private static JsonObject choice(String id, String label) {
    JsonObject choice = new JsonObject();
    choice.addProperty("id", id);
    choice.addProperty("label", StringUtils.defaultString(label));
    return choice;
  }

  /** The id of this confirmation in the page. */
  public String getConfirmationId() {
    return confirmationId;
  }

  @Override
  public ConfirmationAction getSelectedAction() {
    return selectedAction;
  }

  /**
   * Handles the user's choice from the page.
   *
   * @param choiceId the id of the chosen button
   * @return {@code false} if the id does not belong to this confirmation
   */
  public boolean choose(String choiceId) {
    if (closed || choiceId == null) {
      return false;
    }
    if (DEFAULT_DISMISS.equals(choiceId)) {
      selectedAction = null;
      cancelConfirmation();
      return true;
    }
    int index;
    try {
      index = Integer.parseInt(choiceId);
    } catch (NumberFormatException e) {
      return false;
    }
    if (index < 0 || index >= actions.size()) {
      return false;
    }
    ConfirmationAction action = actions.get(index);
    selectedAction = action;
    if (action.isAccept()) {
      CompletableFuture<LanguageModelToolConfirmationResult> future = getConfirmationFuture();
      if (!future.isDone()) {
        future.complete(new LanguageModelToolConfirmationResult(ToolConfirmationResult.ACCEPT));
      }
      close(null);
    } else {
      cancelConfirmation();
    }
    return true;
  }

  @Override
  public void cancelConfirmation() {
    CompletableFuture<LanguageModelToolConfirmationResult> future = getConfirmationFuture();
    if (future != null && !future.isDone()) {
      future.complete(new LanguageModelToolConfirmationResult(ToolConfirmationResult.DISMISS));
      close(StringUtils.isNotEmpty(cancelMessage) ? cancelMessage : null);
    }
  }

  private void close(String leftCancelMessage) {
    if (closed) {
      return;
    }
    closed = true;
    JsonObject msg = new JsonObject();
    msg.addProperty("turnId", presenter.domId());
    msg.addProperty("confirmId", confirmationId);
    if (leftCancelMessage != null) {
      msg.addProperty("cancelMessage", leftCancelMessage);
    }
    presenter.surface().post(Protocol.OUT_CONFIRM_CLOSE, msg);
    presenter.onConfirmationClosed(leftCancelMessage != null);
    presenter.surface().unregisterConfirmation(confirmationId);
    presenter.surface().uiExecutor().execute(() -> {
      if (!isDisposed()) {
        dispose();
      }
    });
  }
}
