package custom.copilot.webchat.viewer;

import java.io.ByteArrayOutputStream;
import java.util.Base64;

import com.google.gson.JsonObject;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.ImageLoader;
import org.eclipse.swt.widgets.Control;

import com.microsoft.copilot.eclipse.ui.utils.UiUtils;

/**
 * Converts the look of the Eclipse chat view (theme colors, chat font, editor font) into the theme message of the
 * page, and SWT images into data URIs.
 */
final class ThemeSupport {

  private static final boolean MAC = "cocoa".equals(SWT.getPlatform());

  private ThemeSupport() {
  }

  /**
   * Build the theme description for the page.
   *
   * @param control the control whose (CSS styled) colors are used
   */
  static JsonObject theme(Control control) {
    JsonObject theme = new JsonObject();
    theme.addProperty("dark", UiUtils.isDarkTheme());
    theme.addProperty("background", hex(control.getBackground()));
    theme.addProperty("foreground", hex(control.getForeground()));
    Font chatFont = UiUtils.getChatFont();
    FontData ui = first(chatFont != null ? chatFont : control.getFont());
    if (ui != null) {
      theme.addProperty("fontFamily", ui.getName());
      theme.addProperty("fontSize", toCssPixels(ui.getHeight()));
    }
    FontData code = first(JFaceResources.getTextFont());
    if (code != null) {
      theme.addProperty("codeFontFamily", code.getName());
      theme.addProperty("codeFontSize", toCssPixels(code.getHeight()));
    }
    theme.addProperty("platform", MAC ? "mac" : "win32".equals(SWT.getPlatform()) ? "win" : "linux");
    return theme;
  }

  /** SWT font sizes are points; CSS pixels are 1/96 inch except on macOS where 1pt renders as 1px. */
  static double toCssPixels(int points) {
    double px = MAC ? points : points * 96.0 / 72.0;
    return Math.round(px * 10) / 10.0;
  }

  static String hex(Color color) {
    if (color == null || color.isDisposed()) {
      return null;
    }
    return String.format("#%02x%02x%02x", color.getRed(), color.getGreen(), color.getBlue());
  }

  private static FontData first(Font font) {
    if (font == null || font.isDisposed()) {
      return null;
    }
    FontData[] data = font.getFontData();
    return data.length > 0 ? data[0] : null;
  }

  /** Encode an image as PNG data URI (at 2x for HiDPI screens); {@code null} on failure. */
  static String dataUri(Image image) {
    if (image == null || image.isDisposed()) {
      return null;
    }
    try {
      ImageData data = image.getImageData(200);
      ImageLoader loader = new ImageLoader();
      loader.data = new ImageData[] { data };
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      loader.save(out, SWT.IMAGE_PNG);
      return "data:image/png;base64," + Base64.getEncoder().encodeToString(out.toByteArray());
    } catch (RuntimeException e) {
      return null;
    }
  }
}
