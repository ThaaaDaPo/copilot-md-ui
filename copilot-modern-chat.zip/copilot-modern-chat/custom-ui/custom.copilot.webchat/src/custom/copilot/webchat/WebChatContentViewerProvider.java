package custom.copilot.webchat;

import java.io.File;
import java.io.IOException;
import java.net.URL;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Platform;
import org.eclipse.swt.SWTError;
import org.eclipse.swt.widgets.Composite;
import org.osgi.framework.Bundle;

import com.microsoft.copilot.eclipse.ui.chat.ChatContentViewer;
import com.microsoft.copilot.eclipse.ui.chat.IChatContentViewerProvider;
import com.microsoft.copilot.eclipse.ui.chat.services.ChatServiceManager;

import custom.copilot.webchat.preferences.WebChatPreferences;
import custom.copilot.webchat.viewer.WebChatContentViewer;

/**
 * Contributes the web chat to the chat view. Declines (so the classic view is used) when the web chat is disabled
 * in the preferences, when the page cannot be located, or when no suitable browser engine is available.
 */
public class WebChatContentViewerProvider implements IChatContentViewerProvider {

  /** Once the browser failed to start, the classic viewer is used for the rest of the session. */
  private static volatile boolean browserUnavailable;
  private static String pageUrl;

  @Override
  public ChatContentViewer createChatContentViewer(Composite parent, int style, ChatServiceManager serviceManager) {
    if (browserUnavailable || !WebChatPreferences.get(WebChatPreferences.ENABLED)) {
      return null;
    }
    String url = pageUrl();
    if (url == null) {
      return null;
    }
    try {
      return new WebChatContentViewer(parent, style, serviceManager, url);
    } catch (SWTError | LinkageError e) {
      browserUnavailable = true;
      WebChatPlugin.logError("The embedded browser is not available, using the classic chat view", e);
      return null;
    }
  }

  /** The {@code file:} URL of web/index.html; bundled resources are extracted when the plug-in is a jar. */
  public static synchronized String pageUrl() {
    if (pageUrl == null) {
      try {
        Bundle bundle = Platform.getBundle(WebChatPlugin.PLUGIN_ID);
        URL entry = bundle != null ? bundle.getEntry("web/") : null;
        if (entry == null) {
          WebChatPlugin.logError("web/ folder missing in " + WebChatPlugin.PLUGIN_ID, null);
          return null;
        }
        File dir = new File(FileLocator.toFileURL(entry).getPath());
        File index = new File(dir, "index.html");
        if (!index.isFile()) {
          WebChatPlugin.logError("Chat page not found: " + index, null);
          return null;
        }
        pageUrl = index.toURI().toString();
      } catch (IOException e) {
        WebChatPlugin.logError("Failed to locate the chat page", e);
        return null;
      }
    }
    return pageUrl;
  }
}
