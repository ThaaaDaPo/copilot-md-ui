package custom.copilot.webchat.viewer;

import java.util.concurrent.Executor;

import com.google.gson.JsonObject;
import org.eclipse.swt.graphics.Image;

import com.microsoft.copilot.eclipse.ui.chat.BaseTurnWidget;
import com.microsoft.copilot.eclipse.ui.chat.services.ChatServiceManager;

/**
 * What the turn presenters need from the web chat viewer. Implemented by {@link WebChatContentViewer}; tests use a
 * recording fake.
 */
public interface ChatSurface {

  /** Send a message to the page (thread safe). */
  void post(String type, JsonObject fields);

  /** Register a turn widget and return the id that identifies it in the page. */
  String registerTurn(BaseTurnWidget widget);

  /**
   * Register an action the page may trigger by its id. The page cannot run anything that was not registered here.
   *
   * @return the opaque action id
   */
  String registerAction(Runnable action);

  /** Register a pending confirmation and return its id. */
  String registerConfirmation(WebToolConfirmationDialog dialog);

  /** Forget a confirmation once it was answered or cancelled. */
  void unregisterConfirmation(String confirmationId);

  /** Return the page id of an avatar image, sending the image to the page on first use; {@code null} if none. */
  String avatarId(Image image);

  /** The chat services. */
  ChatServiceManager serviceManager();

  /** Executes tasks asynchronously on the UI thread (no-op once the viewer is disposed). */
  Executor uiExecutor();

  /** Report a problem. */
  void logError(String message, Throwable cause);
}
