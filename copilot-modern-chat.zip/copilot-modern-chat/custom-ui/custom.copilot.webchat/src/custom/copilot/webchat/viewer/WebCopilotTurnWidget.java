package custom.copilot.webchat.viewer;

import java.util.concurrent.CompletableFuture;

import org.apache.commons.lang3.StringUtils;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;

import com.microsoft.copilot.eclipse.core.AuthStatusManager;
import com.microsoft.copilot.eclipse.core.CopilotCore;
import com.microsoft.copilot.eclipse.core.chat.ConfirmationContent;
import com.microsoft.copilot.eclipse.core.lsp.protocol.AgentToolCall;
import com.microsoft.copilot.eclipse.core.lsp.protocol.LanguageModelToolConfirmationResult;
import com.microsoft.copilot.eclipse.core.lsp.protocol.Thinking;
import com.microsoft.copilot.eclipse.core.lsp.protocol.codingagent.CodingAgentMessageRequestParams;
import com.microsoft.copilot.eclipse.core.persistence.ConversationDataFactory;
import com.microsoft.copilot.eclipse.core.persistence.CopilotTurnData;
import com.microsoft.copilot.eclipse.core.persistence.CopilotTurnData.ThinkingBlockData;
import com.microsoft.copilot.eclipse.ui.chat.CopilotTurnWidget;
import com.microsoft.copilot.eclipse.ui.chat.ThinkingTurnWidget;
import com.microsoft.copilot.eclipse.ui.i18n.Messages;
import com.microsoft.copilot.eclipse.ui.utils.ModelUtils;

/**
 * A Copilot turn rendered in the web chat. Keeps the API of {@link CopilotTurnWidget} for the chat view and the
 * services; the inherited SWT content lives in the hidden widget tree.
 */
public class WebCopilotTurnWidget extends CopilotTurnWidget {

  private final TurnPresenter presenter;

  /**
   * Create the turn.
   *
   * @param parent the hidden parent composite
   * @param surface the viewer
   * @param turnId the turn id
   */
  public WebCopilotTurnWidget(Composite parent, ChatSurface surface, String turnId) {
    super(parent, SWT.NONE, surface.serviceManager(), turnId);
    this.presenter = new TurnPresenter(surface, this, TurnPresenter.Role.COPILOT, Messages.chat_turnWidget_copilot,
        surface.avatarId(icon), null, this::cancelToolConfirmation, WebSubagentTurnWidget::create);
  }

  /** The presenter of this turn. */
  public TurnPresenter presenter() {
    return presenter;
  }

  private TurnPresenter active() {
    WebSubagentTurnWidget subagent = presenter.currentSubagent();
    return subagent != null ? subagent.presenter() : presenter;
  }

  @Override
  protected void createTextBlock() {
    // Text is rendered by the page.
  }

  @Override
  protected void createFooter() {
    // Rendered by the page.
  }

  @Override
  public void appendMessage(String message) {
    presenter.appendMessage(message);
  }

  @Override
  public void flushMessageBuffer() {
    if (presenter != null) {
      presenter.flush();
    }
  }

  @Override
  public void appendToolCallStatus(AgentToolCall toolCall) {
    presenter.appendToolCallStatus(toolCall);
  }

  @Override
  public void restoreSubagentContent(String toolCallId, CopilotTurnData copilotTurn,
      ConversationDataFactory dataFactory) {
    presenter.restoreSubagentContent(toolCallId, copilotTurn, dataFactory);
  }

  @Override
  public ThinkingTurnWidget getActiveTurnWidget() {
    WebSubagentTurnWidget subagent = presenter != null ? presenter.currentSubagent() : null;
    return subagent != null ? subagent : this;
  }

  @Override
  public CompletableFuture<LanguageModelToolConfirmationResult> requestToolExecutionConfirmation(
      ConfirmationContent content, Object input) {
    presenter.reset();
    this.confirmDialog = new WebToolConfirmationDialog(this, content, input, presenter);
    return this.confirmDialog.getConfirmationFuture();
  }

  @Override
  protected Composite createWarnDialog(String message, int code, String modelProviderName) {
    presenter.showWarning(message, code, modelProviderName);
    return null;
  }

  @Override
  protected void createAgentMessageWidget(CodingAgentMessageRequestParams params) {
    presenter.showAgentMessage(params);
  }

  // Thinking: routed to the active turn (this one or the running sub-agent), like ThinkingTurnWidget.

  @Override
  public void setConversationContext(String conversationId, String persistTurnId) {
    presenter.thinking().setConversationContext(conversationId, persistTurnId);
    TurnPresenter active = active();
    if (active != presenter) {
      active.thinking().setConversationContext(conversationId, persistTurnId);
    }
  }

  @Override
  public void appendThinking(Thinking thinking) {
    if (thinking == null || StringUtils.isEmpty(thinking.text()) || isDisposed()) {
      return;
    }
    active().thinking().append(thinking.text());
  }

  @Override
  public void sealThinking() {
    if (!isDisposed()) {
      active().thinking().seal();
    }
  }

  @Override
  public String getActiveThinkingBlockId() {
    return presenter == null ? null : active().thinking().activeBlockId();
  }

  @Override
  public void restoreThinkingBlock(ThinkingBlockData data) {
    presenter.thinking().restore(data);
  }

  @Override
  protected void onChatMessageCancelled() {
    if (presenter == null) {
      return;
    }
    presenter.surface().uiExecutor().execute(() -> {
      if (!isDisposed()) {
        presenter.onChatMessageCancelled();
        TurnPresenter active = active();
        if (active != presenter) {
          active.thinking().cancel();
        }
      }
    });
  }

  @Override
  public void renderModelInfo(String modelName, double billingMultiplier, String reasoningEffort) {
    if (StringUtils.isBlank(modelName)) {
      return;
    }
    String formattedEffort = ModelUtils.formatReasoningEffortLevel(reasoningEffort);
    String modelWithEffort = StringUtils.isNotBlank(formattedEffort) ? modelName + " - " + formattedEffort
        : modelName;
    // With token-based billing the multiplier is no longer meaningful; same rule as the classic footer.
    AuthStatusManager auth = serviceManager != null && serviceManager.getAuthStatusManager() != null
        ? serviceManager.getAuthStatusManager() : CopilotCore.getPlugin().getAuthStatusManager();
    boolean tbbEnabled = auth.getQuotaStatus() != null && auth.getQuotaStatus().tokenBasedBillingEnabled();
    String text = tbbEnabled ? modelWithEffort
        : String.format("%s - %s", modelWithEffort, ModelUtils.formatBillingMultiplier(billingMultiplier));
    presenter.showModelInfo(text);
  }

  @Override
  public void showCompactingStatus() {
    presenter.flush();
    presenter.showCompacting(true, Messages.chat_compacting_conversation);
  }

  @Override
  public void hideCompactingStatus() {
    presenter.showCompacting(false, null);
  }

  @Override
  public void requestLayout() {
    // Nothing to lay out: the widget is not visible.
  }

  @Override
  public boolean setFocus() {
    return false;
  }

  @Override
  public void dispose() {
    if (presenter != null) {
      presenter.dispose();
    }
    super.dispose();
  }

  /** For tests: the (hidden) inherited children. */
  Control[] hiddenChildren() {
    return getChildren();
  }
}
