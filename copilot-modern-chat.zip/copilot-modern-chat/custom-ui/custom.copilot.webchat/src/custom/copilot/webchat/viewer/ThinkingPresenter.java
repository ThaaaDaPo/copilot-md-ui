package custom.copilot.webchat.viewer;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.google.gson.JsonObject;
import org.apache.commons.lang3.StringUtils;

import com.microsoft.copilot.eclipse.core.CopilotCore;
import com.microsoft.copilot.eclipse.core.lsp.CopilotLanguageServerConnection;
import com.microsoft.copilot.eclipse.core.lsp.protocol.GenerateThinkingTitleParams;
import com.microsoft.copilot.eclipse.core.persistence.ConversationPersistenceManager;
import com.microsoft.copilot.eclipse.core.persistence.CopilotTurnData.ThinkingBlockData;

import custom.copilot.webchat.bridge.Protocol;

/**
 * Thinking blocks of one turn. Mirrors the state machine of the classic {@code ThinkingTurnWidget} /
 * {@code ThinkingBlock} (streaming, sealed, completed, cancelled), including title generation through the language
 * server and persistence of titles and cancellations, and renders the blocks in the page.
 */
public class ThinkingPresenter {

  /** Same title syntax as the classic thinking block: a standalone {@code **Title**} line. */
  private static final Pattern TITLE_PATTERN = Pattern.compile("(?:^|\\n)\\*\\*([^*\\r\\n]+?)\\*\\*(?=\\r?\\n|$)");

  enum State {
    STREAMING, SEALED, COMPLETED, CANCELLED
  }

  /** One thinking block. */
  static final class Block {
    final String id;
    final StringBuilder text = new StringBuilder();
    State state = State.STREAMING;

    Block(String id) {
      this.id = id;
    }

    boolean isAcceptingThinkStream() {
      return state == State.STREAMING;
    }

    boolean isFinalized() {
      return state == State.COMPLETED || state == State.CANCELLED;
    }
  }

  private final ChatSurface surface;
  private final TurnPresenter turn;
  private Block current;
  private String conversationId;
  private String persistTurnId;
  private boolean disposed;

  ThinkingPresenter(ChatSurface surface, TurnPresenter turn) {
    this.surface = surface;
    this.turn = turn;
  }

  void setConversationContext(String conversationId, String persistTurnId) {
    this.conversationId = conversationId;
    this.persistTurnId = persistTurnId;
  }

  /** Append a thinking stream fragment (whitespace-only fragments are kept, they can carry markdown boundaries). */
  void append(String text) {
    if (disposed || StringUtils.isEmpty(text)) {
      return;
    }
    if (current == null || !current.isAcceptingThinkStream()) {
      current = new Block(UUID.randomUUID().toString());
      turn.onChildAdded();
    }
    current.text.append(text);
    JsonObject msg = new JsonObject();
    msg.addProperty("turnId", turn.domId());
    msg.addProperty("blockId", current.id);
    msg.addProperty("text", text);
    surface.post(Protocol.OUT_THINKING_APPEND, msg);
  }

  /** Seal the current block and fetch its title asynchronously. */
  void seal() {
    if (disposed || persistTurnId == null) {
      return;
    }
    Block target = current;
    if (target == null || !target.isAcceptingThinkStream()) {
      return;
    }
    String content = target.text.toString();
    if (StringUtils.isBlank(content)) {
      return;
    }
    target.state = State.SEALED;
    postState(target, "sealed", null);
    CopilotLanguageServerConnection ls = languageServer();
    if (ls == null) {
      complete(target, null);
      return;
    }
    String[] titles = extractTitles(content);
    // The server rejects null entries inside extractedTitles, so exactly one of the two fields is sent.
    boolean hasTitles = titles.length > 0;
    GenerateThinkingTitleParams params = new GenerateThinkingTitleParams(hasTitles ? null : content,
        hasTitles ? titles : null);
    String titleConversationId = conversationId;
    String titleTurnId = persistTurnId;
    try {
      ls.generateThinkingTitle(params).thenAccept(response -> surface.uiExecutor().execute(() -> {
        if (disposed || target.isFinalized()) {
          return;
        }
        String title = response != null ? response.title() : null;
        if (StringUtils.isNotBlank(title)) {
          persistTitle(titleConversationId, titleTurnId, target.id, title);
        }
        complete(target, StringUtils.isNotBlank(title) ? title : null);
      })).exceptionally(ex -> {
        surface.uiExecutor().execute(() -> {
          if (!disposed && !target.isFinalized()) {
            complete(target, null);
          }
        });
        return null;
      });
    } catch (RuntimeException e) {
      surface.logError("Failed to request a thinking title", e);
      complete(target, null);
    }
  }

  private void complete(Block block, String title) {
    if (block.isFinalized()) {
      return;
    }
    block.state = State.COMPLETED;
    postState(block, "completed", title);
  }

  /** Called when the user cancels the request. */
  void cancel() {
    Block block = current;
    if (disposed || block == null || block.isFinalized()) {
      return;
    }
    if (block.state == State.SEALED) {
      // Thinking itself finished; only the title request was in flight.
      complete(block, null);
      return;
    }
    block.state = State.CANCELLED;
    postState(block, "cancelled", null);
    if (persistTurnId != null && conversationId != null && persistence() != null) {
      persistence().cancelThinkingBlock(conversationId, persistTurnId, block.id);
    }
  }

  /** Restore a finished block from persisted data. */
  void restore(ThinkingBlockData data) {
    if (disposed || data == null || StringUtils.isBlank(data.getContent())) {
      return;
    }
    Block block = new Block(StringUtils.isNotBlank(data.getId()) ? data.getId() : UUID.randomUUID().toString());
    block.text.append(data.getContent());
    block.state = data.isCancelled() ? State.CANCELLED : State.COMPLETED;
    turn.onChildAdded();
    JsonObject msg = new JsonObject();
    msg.addProperty("turnId", turn.domId());
    msg.addProperty("blockId", block.id);
    msg.addProperty("text", data.getContent());
    if (!data.isCancelled() && StringUtils.isNotBlank(data.getTitle())) {
      msg.addProperty("title", data.getTitle());
    }
    msg.addProperty("cancelled", data.isCancelled());
    surface.post(Protocol.OUT_THINKING_RESTORE, msg);
  }

  /** The id of the current block (shared with persistence), or {@code null}. */
  String activeBlockId() {
    return current != null ? current.id : null;
  }

  void dispose() {
    disposed = true;
  }

  private void postState(Block block, String state, String title) {
    JsonObject msg = new JsonObject();
    msg.addProperty("turnId", turn.domId());
    msg.addProperty("blockId", block.id);
    msg.addProperty("state", state);
    if (title != null) {
      msg.addProperty("title", title);
    }
    surface.post(Protocol.OUT_THINKING_STATE, msg);
  }

  private void persistTitle(String convId, String turnId, String blockId, String title) {
    ConversationPersistenceManager persistence = persistence();
    if (convId == null || persistence == null) {
      return;
    }
    persistence.updateThinkingBlockTitle(convId, turnId, blockId, title);
  }

  private ConversationPersistenceManager persistence() {
    return surface.serviceManager() != null ? surface.serviceManager().getPersistenceManager() : null;
  }

  /** Resolves the language server; replaceable in tests. */
  static Supplier<CopilotLanguageServerConnection> languageServerSupplier = () -> {
    CopilotCore core = CopilotCore.getPlugin();
    return core != null ? core.getCopilotLanguageServer() : null;
  };

  CopilotLanguageServerConnection languageServer() {
    return languageServerSupplier.get();
  }

  /** Non-blank {@code **Title**} lines of the thinking text, in order. */
  static String[] extractTitles(String content) {
    List<String> titles = new ArrayList<>();
    Matcher matcher = TITLE_PATTERN.matcher(content);
    while (matcher.find()) {
      String title = matcher.group(1).trim();
      if (!title.isEmpty()) {
        titles.add(title);
      }
    }
    return titles.toArray(String[]::new);
  }

  /** For tests. */
  Block currentBlock() {
    return current;
  }
}
