package custom.copilot.webchat.bridge;

import java.util.Set;

/**
 * Message catalogue of the Java &lt;-&gt; web channel. The web side (web/js/chat.js) registers a handler for every
 * outbound type; the inbound types are the only messages Java accepts from the page.
 *
 * <p>Outbound messages are JSON objects {@code {"type": ..., ...fields}} delivered in batches to
 * {@code window.CopilotChat.receive([...])}. Inbound messages are JSON strings {@code {"type": ..., "payload": {...}}}
 * passed to the {@code __copilotChatPost} browser function.
 */
public final class Protocol {

  /** Incremented on incompatible changes; the page reports its version in {@link #IN_READY}. */
  public static final int VERSION = 1;

  /** Name of the browser function installed by Java. */
  public static final String JAVA_FUNCTION = "__copilotChatPost";

  // Java -> web
  public static final String OUT_INIT = "init";
  public static final String OUT_THEME = "theme";
  public static final String OUT_AVATAR = "avatar";
  public static final String OUT_TURN_CREATE = "turn.create";
  public static final String OUT_MD_APPEND = "md.append";
  public static final String OUT_MD_FLUSH = "md.flush";
  public static final String OUT_SEGMENT_END = "segment.end";
  public static final String OUT_TOOL_STATUS = "tool.status";
  public static final String OUT_TURN_CANCEL_RUNNING = "turn.cancelRunning";
  public static final String OUT_SUBAGENT_STATE = "subagent.state";
  public static final String OUT_THINKING_APPEND = "thinking.append";
  public static final String OUT_THINKING_STATE = "thinking.state";
  public static final String OUT_THINKING_RESTORE = "thinking.restore";
  public static final String OUT_CONFIRM_SHOW = "confirm.show";
  public static final String OUT_CONFIRM_CLOSE = "confirm.close";
  public static final String OUT_WARN_SHOW = "warn.show";
  public static final String OUT_AGENT_MESSAGE_SHOW = "agentMessage.show";
  public static final String OUT_MODEL_INFO = "modelInfo";
  public static final String OUT_COMPACTING = "compacting";
  public static final String OUT_ERROR_SHOW = "error.show";
  public static final String OUT_SCROLL_PIN = "scroll.pin";
  public static final String OUT_SCROLL_FOLLOW = "scroll.follow";

  // web -> Java
  public static final String IN_READY = "ready";
  public static final String IN_LOG = "log";
  public static final String IN_OPEN_LINK = "openLink";
  public static final String IN_COPY_CODE = "copyCode";
  public static final String IN_COPY_TEXT = "copyText";
  public static final String IN_INSERT_CODE = "insertCode";
  public static final String IN_ACTION = "action";
  public static final String IN_CONFIRM = "confirm";

  /** All message types the page may send. Anything else is rejected. */
  public static final Set<String> INBOUND_TYPES = Set.of(IN_READY, IN_LOG, IN_OPEN_LINK, IN_COPY_CODE, IN_COPY_TEXT,
      IN_INSERT_CODE, IN_ACTION, IN_CONFIRM);

  private Protocol() {
  }
}
