package custom.copilot.webchat.viewer;

import java.util.concurrent.CompletableFuture;

import org.apache.commons.lang3.StringUtils;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;

import com.microsoft.copilot.eclipse.core.chat.ConfirmationContent;
import com.microsoft.copilot.eclipse.core.lsp.protocol.AgentToolCall;
import com.microsoft.copilot.eclipse.core.lsp.protocol.LanguageModelToolConfirmationResult;
import com.microsoft.copilot.eclipse.core.lsp.protocol.Thinking;
import com.microsoft.copilot.eclipse.core.lsp.protocol.codingagent.CodingAgentMessageRequestParams;
import com.microsoft.copilot.eclipse.core.persistence.CopilotTurnData.ThinkingBlockData;
import com.microsoft.copilot.eclipse.ui.chat.SubagentTurnWidget;
import com.microsoft.copilot.eclipse.ui.chat.ThinkingTurnWidget;

/**
 * The content of a sub-agent ({@code run_subagent}) block, rendered as a nested, collapsible section of the parent
 * turn. Keeps the API of {@link SubagentTurnWidget} (tool confirmations requested while the sub-agent runs are
 * shown inside the block).
 */
public class WebSubagentTurnWidget extends SubagentTurnWidget {

  private final TurnPresenter presenter;

  private WebSubagentTurnWidget(Composite parent, ChatSurface surface, TurnPresenter parentPresenter, String toolCallId,
      AgentToolCall toolCall) {
    super(parent, SWT.NONE, surface.serviceManager(), toolCallId, toolCall);
    this.presenter = new TurnPresenter(surface, this, TurnPresenter.Role.SUBAGENT, roleName(toolCall),
        surface.avatarId(icon), parentPresenter, this::cancelToolConfirmation, null);
  }

  /**
   * Create the sub-agent block inside the given parent turn.
   *
   * @param parent the presenter of the parent turn
   * @param toolCallId the id of the tool call
   * @param toolCall the {@code run_subagent} tool call, or {@code null} when restoring legacy data
   * @return the widget
   */
  static WebSubagentTurnWidget create(TurnPresenter parent, String toolCallId, AgentToolCall toolCall) {
    return new WebSubagentTurnWidget(parent.widget(), parent.surface(), parent, toolCallId, toolCall);
  }

  /** Same naming rule as the classic sub-agent widget. */
  static String roleName(AgentToolCall toolCall) {
    if (toolCall != null) {
      if (StringUtils.isNotEmpty(toolCall.getProgressMessage())) {
        return toolCall.getProgressMessage();
      }
      if (StringUtils.isNotEmpty(toolCall.getName())) {
        return toolCall.getName();
      }
    }
    return "Subagent";
  }

  /** The presenter of this block. */
  public TurnPresenter presenter() {
    return presenter;
  }

  @Override
  protected void createTextBlock() {
    // Text is rendered by the page.
  }

  @Override
  public void appendMessage(String message) {
    presenter.appendMessage(message);
  }

  @Override
  public void flushMessageBuffer() {
    if (presenter != null) {
      presenter.flush();
    }
  }

  @Override
  public void appendToolCallStatus(AgentToolCall toolCall) {
    presenter.appendToolCallStatus(toolCall);
  }

  @Override
  public ThinkingTurnWidget getActiveTurnWidget() {
    return this;
  }

  @Override
  public CompletableFuture<LanguageModelToolConfirmationResult> requestToolExecutionConfirmation(
      ConfirmationContent content, Object input) {
    presenter.reset();
    this.confirmDialog = new WebToolConfirmationDialog(this, content, input, presenter);
    return this.confirmDialog.getConfirmationFuture();
  }

  @Override
  protected Composite createWarnDialog(String message, int code, String modelProviderName) {
    presenter.showWarning(message, code, modelProviderName);
    return null;
  }

  @Override
  protected void createAgentMessageWidget(CodingAgentMessageRequestParams params) {
    presenter.showAgentMessage(params);
  }

  @Override
  public void setConversationContext(String conversationId, String persistTurnId) {
    presenter.thinking().setConversationContext(conversationId, persistTurnId);
  }

  @Override
  public void appendThinking(Thinking thinking) {
    if (thinking != null && StringUtils.isNotEmpty(thinking.text()) && !isDisposed()) {
      presenter.thinking().append(thinking.text());
    }
  }

  @Override
  public void sealThinking() {
    if (!isDisposed()) {
      presenter.thinking().seal();
    }
  }

  @Override
  public String getActiveThinkingBlockId() {
    return presenter == null ? null : presenter.thinking().activeBlockId();
  }

  @Override
  public void restoreThinkingBlock(ThinkingBlockData data) {
    presenter.thinking().restore(data);
  }

  @Override
  protected void onChatMessageCancelled() {
    if (presenter == null) {
      return;
    }
    // The parent turn cancels the active thinking block; status lines of this block are cancelled here.
    presenter.surface().uiExecutor().execute(() -> {
      if (!isDisposed()) {
        presenter.onChatMessageCancelled();
      }
    });
  }

  @Override
  public void requestLayout() {
    // Nothing to lay out: the widget is not visible.
  }

  @Override
  public boolean setFocus() {
    return false;
  }

  @Override
  public void dispose() {
    if (presenter != null) {
      presenter.dispose();
    }
    super.dispose();
  }
}
