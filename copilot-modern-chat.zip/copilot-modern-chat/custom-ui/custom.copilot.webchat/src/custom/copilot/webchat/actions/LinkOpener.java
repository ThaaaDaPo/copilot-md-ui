package custom.copilot.webchat.actions;

import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.lsp4e.LSPEclipseUtils;
import org.eclipse.lsp4j.Location;
import org.eclipse.lsp4j.Position;
import org.eclipse.lsp4j.Range;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.ide.IDE;

import com.microsoft.copilot.eclipse.core.utils.FileUtils;
import com.microsoft.copilot.eclipse.ui.utils.UiUtils;

import custom.copilot.webchat.WebChatPlugin;

/**
 * Opens links clicked in chat messages. Follows the classic chat view ({@code FileAnnotationHyperlinkDetector}):
 * web links open in the external browser, file links and workspace paths open in an editor (folders are revealed).
 * Additionally a {@code #L12} / {@code #L12-L20} fragment moves the caret to that line.
 */
public final class LinkOpener {

  /** Schemes that are never opened. */
  private static final Pattern BLOCKED = Pattern.compile("^\\s*(javascript|vbscript|data|blob|about|jar):",
      Pattern.CASE_INSENSITIVE);
  private static final Pattern WEB = Pattern.compile("^\\s*(https?|mailto):", Pattern.CASE_INSENSITIVE);
  private static final Pattern LINE_FRAGMENT = Pattern.compile("#L(\\d+)(?:-L?(\\d+))?$");

  private LinkOpener() {
  }

  /** Classifies a link target. */
  enum Kind {
    BLOCKED, WEB, FILE
  }

  static Kind classify(String href) {
    if (StringUtils.isBlank(href) || BLOCKED.matcher(href).find()) {
      return Kind.BLOCKED;
    }
    return WEB.matcher(href).find() ? Kind.WEB : Kind.FILE;
  }

  /** Zero-based line of a {@code #L<n>} fragment, or -1. */
  static int lineOf(String href) {
    Matcher matcher = LINE_FRAGMENT.matcher(href);
    if (!matcher.find()) {
      return -1;
    }
    try {
      return Math.max(0, Integer.parseInt(matcher.group(1)) - 1);
    } catch (NumberFormatException e) {
      return -1;
    }
  }

  /**
   * Open the link.
   *
   * @param href the link target as written in the message
   */
  public static void open(String href) {
    String target = StringUtils.trimToEmpty(href);
    switch (classify(target)) {
      case BLOCKED -> {
        return;
      }
      case WEB -> {
        UiUtils.openLink(target);
        return;
      }
      default -> openFile(target);
    }
  }

  private static void openFile(String target) {
    int line = lineOf(target);
    String withoutFragment = line >= 0 ? target.substring(0, target.lastIndexOf('#')) : target;
    String uri;
    try {
      uri = FileUtils.normalizeToUri(withoutFragment);
      if (uri == null) {
        uri = LSPEclipseUtils.toUri(withoutFragment).toString();
      }
    } catch (RuntimeException e) {
      WebChatPlugin.logWarning("Cannot resolve link " + target, e);
      return;
    }

    if (uri.toLowerCase(Locale.ROOT).startsWith(LSPEclipseUtils.FILE_URI)) {
      IResource resource = LSPEclipseUtils.findResourceFor(uri);
      if (resource != null) {
        if (resource.getType() == IResource.FILE) {
          Location location = new Location();
          location.setUri(uri);
          if (line >= 0) {
            location.setRange(new Range(new Position(line, 0), new Position(line, 0)));
          }
          LSPEclipseUtils.openInEditor(location);
          return;
        }
        if (resource.getType() == IResource.FOLDER || resource.getType() == IResource.PROJECT) {
          UiUtils.revealInExplorer(resource);
          return;
        }
      }
      Path localPath = FileUtils.getLocalFilePath(uri);
      if (localPath != null && Files.isRegularFile(localPath, LinkOption.NOFOLLOW_LINKS)) {
        UiUtils.openLocalFileInEditor(localPath);
      }
      return;
    }

    // Workspace-relative path such as /Project/src/Foo.java
    IFile file = ResourcesPlugin.getWorkspace().getRoot().getFile(new org.eclipse.core.runtime.Path(withoutFragment));
    if (file.exists()) {
      IWorkbenchPage page = UiUtils.getActivePage();
      if (page != null) {
        try {
          IDE.openEditor(page, file);
        } catch (PartInitException e) {
          WebChatPlugin.logWarning("Failed to open file: " + withoutFragment, e);
        }
      }
    }
  }
}
