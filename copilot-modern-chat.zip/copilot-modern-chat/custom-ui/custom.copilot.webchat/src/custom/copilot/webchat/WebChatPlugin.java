package custom.copilot.webchat;

import org.eclipse.core.runtime.ILog;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

/**
 * Activator of the web chat plug-in.
 */
public class WebChatPlugin extends AbstractUIPlugin {

  /** The bundle symbolic name. */
  public static final String PLUGIN_ID = "custom.copilot.webchat";

  private static WebChatPlugin plugin;

  @Override
  public void start(BundleContext context) throws Exception {
    super.start(context);
    plugin = this;
  }

  @Override
  public void stop(BundleContext context) throws Exception {
    plugin = null;
    super.stop(context);
  }

  /** The shared instance, or {@code null} when the bundle is not active. */
  public static WebChatPlugin getDefault() {
    return plugin;
  }

  /** Log an error. */
  public static void logError(String message, Throwable cause) {
    log(IStatus.ERROR, message, cause);
  }

  /** Log a warning. */
  public static void logWarning(String message, Throwable cause) {
    log(IStatus.WARNING, message, cause);
  }

  private static void log(int severity, String message, Throwable cause) {
    WebChatPlugin instance = plugin;
    if (instance == null) {
      System.err.println(message); //NOSONAR fallback when the bundle is not active (unit tests)
      return;
    }
    ILog.of(instance.getBundle()).log(new Status(severity, PLUGIN_ID, message, cause));
  }
}
