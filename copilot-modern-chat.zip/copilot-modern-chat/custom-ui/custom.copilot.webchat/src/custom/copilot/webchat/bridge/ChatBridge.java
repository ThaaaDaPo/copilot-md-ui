package custom.copilot.webchat.bridge;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;

/**
 * Typed, batched message channel between Java and the chat page.
 *
 * <ul>
 * <li>Outbound messages are recorded in a log. The log is the complete state of the page: when the page (re)loads
 * and reports {@link Protocol#IN_READY}, the whole log is replayed, so nothing is lost if the page loads late or is
 * reloaded.</li>
 * <li>Messages posted in a burst (streaming) are coalesced into one script execution per UI cycle, and consecutive
 * text deltas of the same turn are merged before they are sent.</li>
 * <li>Inbound messages are parsed defensively: unknown types, malformed JSON and oversized payloads are rejected;
 * handlers receive only well-formed objects.</li>
 * </ul>
 *
 * <p>The bridge is independent of SWT so it can be unit tested; {@link ScriptRunner} and the UI executor are supplied
 * by the viewer.
 */
public class ChatBridge {

  /** Executes a script in the page. */
  @FunctionalInterface
  public interface ScriptRunner {
    /**
     * Run the script.
     *
     * @param script the JavaScript source
     * @return {@code false} if the script could not be executed
     */
    boolean execute(String script);
  }

  /** Maximum size of a message accepted from the page. */
  public static final int MAX_INBOUND_CHARS = 2_000_000;

  /** Upper bound for one script execution; larger replays are split. */
  static final int MAX_BATCH_CHARS = 512 * 1024;

  private static final Gson GSON = new Gson();

  private final ScriptRunner runner;
  private final Executor uiExecutor;
  private final Supplier<JsonObject> initMessage;
  private final BiConsumer<String, Throwable> errorLogger;
  private final Map<String, Consumer<JsonObject>> handlers = new HashMap<>();

  private final Object lock = new Object();
  private final List<JsonObject> log = new ArrayList<>();
  private int sent;
  private boolean ready;
  private String pageInstanceId;
  private boolean disposed;
  private final AtomicBoolean flushScheduled = new AtomicBoolean();

  /**
   * Create the bridge.
   *
   * @param runner executes scripts in the page (UI thread)
   * @param uiExecutor runs tasks asynchronously on the UI thread
   * @param initMessage creates the {@link Protocol#OUT_INIT} message sent before every replay
   * @param errorLogger receives problems (message, optional cause)
   */
  public ChatBridge(ScriptRunner runner, Executor uiExecutor, Supplier<JsonObject> initMessage,
      BiConsumer<String, Throwable> errorLogger) {
    this.runner = Objects.requireNonNull(runner);
    this.uiExecutor = Objects.requireNonNull(uiExecutor);
    this.initMessage = Objects.requireNonNull(initMessage);
    this.errorLogger = Objects.requireNonNull(errorLogger);
  }

  /**
   * Register the handler for an inbound message type.
   *
   * @param type one of {@link Protocol#INBOUND_TYPES}
   * @param handler receives the payload object; called on the UI thread
   */
  public void on(String type, Consumer<JsonObject> handler) {
    if (!Protocol.INBOUND_TYPES.contains(type) || Protocol.IN_READY.equals(type)) {
      throw new IllegalArgumentException("Not a handled inbound type: " + type);
    }
    handlers.put(type, handler);
  }

  /**
   * Post a message to the page. Thread safe.
   *
   * @param type the message type
   * @param fields the message fields (ownership passes to the bridge)
   */
  public void post(String type, JsonObject fields) {
    JsonObject message = fields == null ? new JsonObject() : fields;
    message.addProperty("type", type);
    synchronized (lock) {
      if (disposed) {
        return;
      }
      if (!mergeIntoLast(message)) {
        log.add(message);
      }
    }
    scheduleFlush();
  }

  /** Post a message without fields. */
  public void post(String type) {
    post(type, new JsonObject());
  }

  /**
   * Merges a text delta into the previous unsent message when both target the same text stream.
   */
  private boolean mergeIntoLast(JsonObject message) {
    String type = message.get("type").getAsString();
    if (!Protocol.OUT_MD_APPEND.equals(type) && !Protocol.OUT_THINKING_APPEND.equals(type)) {
      return false;
    }
    int last = log.size() - 1;
    if (last < sent) {
      return false;
    }
    JsonObject previous = log.get(last);
    if (!type.equals(stringOf(previous, "type")) || !Objects.equals(stringOf(previous, "turnId"),
        stringOf(message, "turnId")) || !Objects.equals(stringOf(previous, "blockId"), stringOf(message, "blockId"))) {
      return false;
    }
    previous.addProperty("text", stringOf(previous, "text") + stringOf(message, "text"));
    return true;
  }

  private void scheduleFlush() {
    if (flushScheduled.compareAndSet(false, true)) {
      uiExecutor.execute(() -> {
        flushScheduled.set(false);
        flush();
      });
    }
  }

  /** Send all pending messages to the page. Must be called on the UI thread. */
  public void flush() {
    List<String> scripts;
    synchronized (lock) {
      if (!ready || disposed || sent >= log.size()) {
        return;
      }
      scripts = buildScripts(log.subList(sent, log.size()));
      sent = log.size();
    }
    for (String script : scripts) {
      if (!runner.execute(script)) {
        errorLogger.accept("Failed to deliver messages to the chat page", null);
      }
    }
  }

  private static List<String> buildScripts(List<JsonObject> messages) {
    List<String> scripts = new ArrayList<>();
    JsonArray batch = new JsonArray();
    int size = 0;
    for (JsonObject message : messages) {
      String json = GSON.toJson(message);
      if (size > 0 && size + json.length() > MAX_BATCH_CHARS) {
        scripts.add(toScript(batch));
        batch = new JsonArray();
        size = 0;
      }
      batch.add(message);
      size += json.length();
    }
    if (size > 0) {
      scripts.add(toScript(batch));
    }
    return scripts;
  }

  private static String toScript(JsonArray batch) {
    // Gson escapes <, >, &, = and U+2028/U+2029, so the JSON text is a safe JavaScript literal.
    return "window.CopilotChat&&window.CopilotChat.receive(" + GSON.toJson(batch) + ");";
  }

  /** Called when the browser starts loading a page; messages are held back until the new page is ready. */
  public void pageLoading() {
    synchronized (lock) {
      ready = false;
    }
  }

  /**
   * Entry point for messages from the page (called by the browser function on the UI thread).
   *
   * @param json the raw message
   */
  public void receive(Object json) {
    if (!(json instanceof String text)) {
      errorLogger.accept("Rejected non-string message from chat page", null);
      return;
    }
    if (text.length() > MAX_INBOUND_CHARS) {
      errorLogger.accept("Rejected oversized message from chat page (" + text.length() + " chars)", null);
      return;
    }
    JsonObject envelope;
    try {
      JsonElement element = JsonParser.parseString(text);
      if (!element.isJsonObject()) {
        errorLogger.accept("Rejected malformed message from chat page", null);
        return;
      }
      envelope = element.getAsJsonObject();
    } catch (JsonParseException e) {
      errorLogger.accept("Rejected malformed message from chat page", e);
      return;
    }
    String type = stringOf(envelope, "type");
    JsonElement payloadElement = envelope.get("payload");
    JsonObject payload = payloadElement != null && payloadElement.isJsonObject() ? payloadElement.getAsJsonObject()
        : new JsonObject();
    if (type == null || !Protocol.INBOUND_TYPES.contains(type)) {
      errorLogger.accept("Rejected unknown message type from chat page: " + abbreviate(type), null);
      return;
    }
    if (Protocol.IN_READY.equals(type)) {
      onReady(payload);
      return;
    }
    Consumer<JsonObject> handler = handlers.get(type);
    if (handler == null) {
      return;
    }
    try {
      handler.accept(payload);
    } catch (RuntimeException e) {
      errorLogger.accept("Failed to handle '" + type + "' from chat page", e);
    }
  }

  private void onReady(JsonObject payload) {
    String instanceId = stringOf(payload, "instanceId");
    JsonElement protocol = payload.get("protocol");
    if (protocol == null || !protocol.isJsonPrimitive() || !protocol.getAsJsonPrimitive().isNumber()
        || protocol.getAsInt() != Protocol.VERSION) {
      errorLogger.accept("Chat page reports protocol " + protocol + ", expected " + Protocol.VERSION, null);
    }
    synchronized (lock) {
      if (disposed) {
        return;
      }
      if (ready && Objects.equals(instanceId, pageInstanceId)) {
        return;
      }
      // A new page instance has no state: replay everything.
      pageInstanceId = instanceId;
      ready = true;
      sent = 0;
    }
    JsonObject init = initMessage.get();
    init.addProperty("type", Protocol.OUT_INIT);
    init.addProperty("protocol", Protocol.VERSION);
    JsonArray batch = new JsonArray();
    batch.add(init);
    if (!runner.execute(toScript(batch))) {
      errorLogger.accept("Failed to initialize the chat page", null);
    }
    flush();
  }

  /** Whether the page reported ready and receives messages. */
  public boolean isReady() {
    synchronized (lock) {
      return ready;
    }
  }

  /** Number of messages in the replay log (after merging). */
  public int logSize() {
    synchronized (lock) {
      return log.size();
    }
  }

  /** Copy of the replay log, for tests and diagnostics. */
  public List<JsonObject> snapshot() {
    synchronized (lock) {
      List<JsonObject> copy = new ArrayList<>(log.size());
      for (JsonObject message : log) {
        copy.add(message.deepCopy());
      }
      return copy;
    }
  }

  /** Stop sending; pending messages are discarded. */
  public void dispose() {
    synchronized (lock) {
      disposed = true;
      log.clear();
      sent = 0;
    }
  }

  /**
   * Returns a string member, or {@code null} when missing or not a string.
   *
   * @param object the JSON object
   * @param key the member name
   * @return the value or {@code null}
   */
  public static String stringOf(JsonObject object, String key) {
    JsonElement element = object == null ? null : object.get(key);
    if (element == null || !element.isJsonPrimitive() || !element.getAsJsonPrimitive().isString()) {
      return null;
    }
    return element.getAsString();
  }

  /**
   * Returns a string member limited to {@code maxLength} characters, or {@code null} when missing, not a string or
   * too long.
   *
   * @param object the JSON object
   * @param key the member name
   * @param maxLength the maximum accepted length
   * @return the value or {@code null}
   */
  public static String boundedString(JsonObject object, String key, int maxLength) {
    String value = stringOf(object, key);
    return value != null && value.length() <= maxLength ? value : null;
  }

  private static String abbreviate(String value) {
    if (value == null) {
      return "null";
    }
    return value.length() > 60 ? value.substring(0, 60) + "..." : value;
  }
}
