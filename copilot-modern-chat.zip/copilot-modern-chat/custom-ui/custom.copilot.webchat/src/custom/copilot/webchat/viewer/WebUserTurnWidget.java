package custom.copilot.webchat.viewer;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;

import com.microsoft.copilot.eclipse.core.chat.ConfirmationContent;
import com.microsoft.copilot.eclipse.core.lsp.protocol.AgentToolCall;
import com.microsoft.copilot.eclipse.core.lsp.protocol.LanguageModelToolConfirmationResult;
import com.microsoft.copilot.eclipse.core.lsp.protocol.codingagent.CodingAgentMessageRequestParams;
import com.microsoft.copilot.eclipse.ui.chat.UserTurnWidget;
import com.microsoft.copilot.eclipse.ui.i18n.Messages;

/**
 * A user turn rendered in the web chat. The message is shown as plain text, like in the classic view.
 */
public class WebUserTurnWidget extends UserTurnWidget {

  private final TurnPresenter presenter;

  /**
   * Create the turn.
   *
   * @param parent the hidden parent composite
   * @param surface the viewer
   * @param turnId the turn id
   */
  public WebUserTurnWidget(Composite parent, ChatSurface surface, String turnId) {
    super(parent, SWT.NONE, surface.serviceManager(), turnId);
    String name = Optional.ofNullable(serviceManager.getAuthStatusManager())
        .map(manager -> manager.getUserName()).filter(s -> !s.isEmpty()).orElse(Messages.chat_turnWidget_user);
    this.presenter = new TurnPresenter(surface, this, TurnPresenter.Role.USER, name, surface.avatarId(icon), null,
        this::cancelToolConfirmation, null);
  }

  /** The presenter of this turn. */
  public TurnPresenter presenter() {
    return presenter;
  }

  @Override
  protected void createTextBlock() {
    // Text is rendered by the page.
  }

  @Override
  public void appendMessage(String message) {
    presenter.appendMessage(message);
  }

  @Override
  public void flushMessageBuffer() {
    if (presenter != null) {
      presenter.flush();
    }
  }

  @Override
  public void appendToolCallStatus(AgentToolCall toolCall) {
    presenter.appendToolCallStatus(toolCall);
  }

  @Override
  public CompletableFuture<LanguageModelToolConfirmationResult> requestToolExecutionConfirmation(
      ConfirmationContent content, Object input) {
    presenter.reset();
    this.confirmDialog = new WebToolConfirmationDialog(this, content, input, presenter);
    return this.confirmDialog.getConfirmationFuture();
  }

  @Override
  protected Composite createWarnDialog(String message, int code, String modelProviderName) {
    presenter.showWarning(message, code, modelProviderName);
    return null;
  }

  @Override
  protected void createAgentMessageWidget(CodingAgentMessageRequestParams params) {
    presenter.showAgentMessage(params);
  }

  @Override
  public void requestLayout() {
    // Nothing to lay out: the widget is not visible.
  }

  @Override
  public boolean setFocus() {
    return false;
  }

  @Override
  public void dispose() {
    if (presenter != null) {
      presenter.dispose();
    }
    super.dispose();
  }
}
