package custom.copilot.webchat.viewer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.osgi.util.NLS;

import com.microsoft.copilot.eclipse.core.Constants;
import com.microsoft.copilot.eclipse.core.CopilotCore;
import com.microsoft.copilot.eclipse.core.lsp.protocol.AgentToolCall;
import com.microsoft.copilot.eclipse.core.lsp.protocol.codingagent.CodingAgentMessageRequestParams;
import com.microsoft.copilot.eclipse.core.lsp.protocol.quota.CheckQuotaResult;
import com.microsoft.copilot.eclipse.core.lsp.protocol.quota.CopilotPlan;
import com.microsoft.copilot.eclipse.core.persistence.ConversationDataFactory;
import com.microsoft.copilot.eclipse.core.persistence.CopilotTurnData;
import com.microsoft.copilot.eclipse.core.persistence.CopilotTurnData.EditAgentRoundData;
import com.microsoft.copilot.eclipse.core.persistence.CopilotTurnData.ReplyData;
import com.microsoft.copilot.eclipse.core.persistence.CopilotTurnData.ToolCallData;
import com.microsoft.copilot.eclipse.ui.chat.BaseTurnWidget;
import com.microsoft.copilot.eclipse.ui.chat.Messages;
import com.microsoft.copilot.eclipse.ui.chat.QuotaActions;
import com.microsoft.copilot.eclipse.ui.chat.QuotaActions.QuotaAction;
import com.microsoft.copilot.eclipse.ui.utils.UiUtils;

import custom.copilot.webchat.bridge.Protocol;

/**
 * Presentation logic of one turn in the web chat. The turn widgets ({@link WebCopilotTurnWidget},
 * {@link WebUserTurnWidget}, {@link WebSubagentTurnWidget}) keep the public API of the classic widgets and delegate
 * here; this class reproduces the behaviour of the classic {@code BaseTurnWidget} (segmenting text around tool calls,
 * sub-agent routing, tool status rules, warnings, agent messages) and turns it into protocol messages.
 */
public class TurnPresenter {

  /** Role of a turn in the page. */
  public enum Role {
    USER("user"), COPILOT("copilot"), SUBAGENT("subagent");

    final String wire;

    Role(String wire) {
      this.wire = wire;
    }
  }

  private static final String RUN_SUBAGENT_TOOL = "run_subagent";
  private static final String LEGACY_UPGRADE_HINT = "upgrade to copilot pro (30-day free trial)";
  private static final int AGENT_DESCRIPTION_PREVIEW = 100;

  /** Creates the widget of a sub-agent block. */
  @FunctionalInterface
  public interface SubagentFactory {
    /**
     * Create a sub-agent block.
     *
     * @param parent the presenter of the enclosing turn
     * @param toolCallId the id of the {@code run_subagent} tool call
     * @param toolCall the tool call, or {@code null} when restoring persisted data
     * @return the widget
     */
    WebSubagentTurnWidget create(TurnPresenter parent, String toolCallId, AgentToolCall toolCall);
  }

  private final SubagentFactory subagentFactory;

  private final ChatSurface surface;
  private final BaseTurnWidget widget;
  private final Role role;
  private final String domId;
  private final Runnable cancelPendingConfirmation;
  private final ThinkingPresenter thinking;

  private final Map<String, WebSubagentTurnWidget> subagents = new HashMap<>();
  private WebSubagentTurnWidget currentSubagent;

  /** Mirrors "the last child is an AgentToolCancelLabel" of the classic widget. */
  private boolean cancelLabelIsLast;

  /**
   * Create the presenter and announce the turn to the page.
   *
   * @param surface the viewer
   * @param widget the turn widget that owns this presenter
   * @param role the role in the page
   * @param name the display name
   * @param avatarId the page id of the avatar image, may be {@code null}
   * @param parent the presenter of the enclosing turn for sub-agents, otherwise {@code null}
   * @param cancelPendingConfirmation cancels the confirmation that is pending on the widget, if any
   * @param subagentFactory creates sub-agent widgets; {@code null} for turns that cannot host sub-agents
   */
  public TurnPresenter(ChatSurface surface, BaseTurnWidget widget, Role role, String name, String avatarId,
      TurnPresenter parent, Runnable cancelPendingConfirmation,
      SubagentFactory subagentFactory) {
    this.surface = surface;
    this.widget = widget;
    this.role = role;
    this.cancelPendingConfirmation = cancelPendingConfirmation;
    this.subagentFactory = subagentFactory;
    this.domId = surface.registerTurn(widget);
    this.thinking = role == Role.USER ? null : new ThinkingPresenter(surface, this);

    JsonObject msg = new JsonObject();
    msg.addProperty("turnId", domId);
    msg.addProperty("role", role.wire);
    msg.addProperty("name", name);
    if (avatarId != null) {
      msg.addProperty("avatarId", avatarId);
    }
    if (parent != null) {
      msg.addProperty("parentId", parent.domId());
    }
    surface.post(Protocol.OUT_TURN_CREATE, msg);
  }

  /** The id of this turn in the page. */
  public String domId() {
    return domId;
  }

  /** The widget that owns this presenter. */
  public BaseTurnWidget widget() {
    return widget;
  }

  ChatSurface surface() {
    return surface;
  }

  ThinkingPresenter thinking() {
    return thinking;
  }

  /** The sub-agent that currently receives messages, or {@code null}. */
  WebSubagentTurnWidget currentSubagent() {
    return currentSubagent;
  }

  /** Something new was added to the turn (a text block, a status line, a block...). */
  void onChildAdded() {
    cancelLabelIsLast = false;
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Text

  /** {@code BaseTurnWidget#appendMessage}. */
  public void appendMessage(String message) {
    if (StringUtils.isEmpty(message)) {
      return;
    }
    if (currentSubagent != null) {
      currentSubagent.appendMessage(message);
      return;
    }
    onChildAdded();
    JsonObject msg = new JsonObject();
    msg.addProperty("turnId", domId);
    msg.addProperty("text", message);
    surface.post(Protocol.OUT_MD_APPEND, msg);
  }

  /** {@code BaseTurnWidget#flushMessageBuffer}: renders the text received so far as complete. */
  public void flush() {
    post(Protocol.OUT_MD_FLUSH);
  }

  /**
   * {@code BaseTurnWidget#reset()}: ends the current text segment and cancels a pending confirmation, exactly like
   * the classic widget does before it adds a status line or a confirmation.
   */
  void reset() {
    cancelPendingConfirmation.run();
    post(Protocol.OUT_SEGMENT_END);
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Tool calls and sub-agents

  /** {@code BaseTurnWidget#appendToolCallStatus}. */
  public void appendToolCallStatus(AgentToolCall toolCall) {
    if (toolCall == null || toolCall.getStatus() == null) {
      return;
    }
    // Sub-agent tool calls drive routing, so they are always dispatched.
    if (RUN_SUBAGENT_TOOL.equalsIgnoreCase(toolCall.getName()) && subagentFactory != null) {
      handleSubagentToolCall(toolCall);
      return;
    }
    String status = toolCall.getStatus().toLowerCase();
    boolean isError = "error".equals(status);
    if (!isError && StringUtils.isBlank(toolCall.getProgressMessage())) {
      return;
    }
    if (currentSubagent != null) {
      currentSubagent.appendToolCallStatus(toolCall);
      return;
    }
    reset();
    // The classic widget skips the update when a dismissed confirmation already left its cancel line.
    if (cancelLabelIsLast) {
      return;
    }
    switch (status) {
      case "running", "completed", "cancelled" -> postToolStatus(toolCall, status, toolCall.getProgressMessage());
      case "error" -> postToolStatus(toolCall, "error", errorDisplayText(toolCall));
      default -> {
        postToolStatus(toolCall, "error", null);
        CopilotCore.LOGGER.error(new IllegalStateException("Unknown status: " + status));
      }
    }
  }

  private void handleSubagentToolCall(AgentToolCall toolCall) {
    String status = toolCall.getStatus().toLowerCase();
    switch (status) {
      case "running" -> {
        if (currentSubagent == null) {
          reset();
          currentSubagent = createSubagent(toolCall.getId(), toolCall);
        }
      }
      case "completed" -> {
        if (currentSubagent != null) {
          currentSubagent.flushMessageBuffer();
          currentSubagent.presenter().postSubagentState("completed");
          currentSubagent = null;
        } else if (!subagents.containsKey(toolCall.getId())) {
          // Restoration path: create a completed block for later content injection.
          reset();
          createSubagent(toolCall.getId(), toolCall).presenter().postSubagentState("completed");
        }
      }
      case "cancelled", "error" -> {
        if (currentSubagent != null) {
          currentSubagent.flushMessageBuffer();
          currentSubagent.presenter().postSubagentState(status);
          currentSubagent = null;
        }
        if ("cancelled".equals(status)) {
          postToolStatus(toolCall, "cancelled",
              StringUtils.isNotBlank(toolCall.getProgressMessage()) ? toolCall.getProgressMessage() : null);
        } else {
          postToolStatus(toolCall, "error", errorDisplayText(toolCall));
        }
      }
      default -> {
        postToolStatus(toolCall, "error", null);
        CopilotCore.LOGGER.error(new IllegalStateException("Unknown status: " + status));
      }
    }
  }

  private WebSubagentTurnWidget createSubagent(String toolCallId, AgentToolCall toolCall) {
    onChildAdded();
    WebSubagentTurnWidget subagent = subagentFactory.create(this, toolCallId, toolCall);
    subagents.put(toolCallId, subagent);
    return subagent;
  }

  void postSubagentState(String state) {
    JsonObject msg = new JsonObject();
    msg.addProperty("turnId", domId);
    msg.addProperty("state", state);
    surface.post(Protocol.OUT_SUBAGENT_STATE, msg);
  }

  /** {@code BaseTurnWidget#restoreSubagentContent}. */
  public void restoreSubagentContent(String toolCallId, CopilotTurnData copilotTurn,
      ConversationDataFactory dataFactory) {
    if (subagentFactory == null) {
      return;
    }
    WebSubagentTurnWidget block = subagents.get(toolCallId);
    if (block == null) {
      block = createSubagent(toolCallId, null);
      block.presenter().postSubagentState("completed");
    }
    ReplyData replyData = copilotTurn.getReply();
    if (replyData == null) {
      return;
    }
    if (StringUtils.isNotBlank(replyData.getText())) {
      block.appendMessage(replyData.getText());
    }
    if (replyData.getEditAgentRounds() != null) {
      for (EditAgentRoundData round : replyData.getEditAgentRounds()) {
        if (round.getThinkingBlock() != null) {
          block.restoreThinkingBlock(round.getThinkingBlock());
        }
        if (round.getReply() != null && !round.getReply().isEmpty()) {
          block.appendMessage(round.getReply());
        }
        if (round.getToolCalls() != null) {
          for (ToolCallData toolCallData : round.getToolCalls()) {
            block.appendToolCallStatus(dataFactory.convertToolCallDataToAgentToolCall(toolCallData));
          }
        }
      }
    }
    if (replyData.getErrorMessages() != null) {
      for (CopilotTurnData.ErrorMessageData errorMessageData : replyData.getErrorMessages()) {
        CopilotTurnData.ErrorData errorData = errorMessageData.getError();
        String errorMessage = errorData != null ? errorData.getMessage() : "";
        int errorCode = errorData != null ? errorData.getCode() : 0;
        String modelProviderName = errorData != null ? errorData.getModelProviderName() : null;
        block.presenter().showWarning(errorMessage, errorCode, modelProviderName);
      }
    }
    block.flushMessageBuffer();
  }

  private void postToolStatus(AgentToolCall toolCall, String status, String message) {
    onChildAdded();
    JsonObject msg = new JsonObject();
    msg.addProperty("turnId", domId);
    msg.addProperty("toolId", StringUtils.defaultString(toolCall.getId()));
    msg.addProperty("status", status);
    if (message != null) {
      msg.addProperty("message", message);
    }
    if (StringUtils.isNotBlank(toolCall.getName())) {
      msg.addProperty("toolName", toolCall.getName());
    }
    surface.post(Protocol.OUT_TOOL_STATUS, msg);
  }

  /** Same text as the classic status line: the error (or progress message), prefixed with the tool name. */
  static String errorDisplayText(AgentToolCall toolCall) {
    String detail = toolCall.getError();
    if (StringUtils.isBlank(detail)) {
      detail = toolCall.getProgressMessage();
    }
    if (StringUtils.isBlank(detail)) {
      detail = Messages.chat_toolCall_genericError;
    }
    String name = toolCall.getName();
    if (StringUtils.isBlank(name)) {
      return detail;
    }
    return NLS.bind(Messages.chat_toolCall_errorTemplate, name, detail);
  }

  /** The user cancelled the request: running status lines and the streaming thinking block are cancelled. */
  void onChatMessageCancelled() {
    post(Protocol.OUT_TURN_CANCEL_RUNNING);
    if (thinking != null) {
      thinking.cancel();
    }
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Confirmations

  /** Called by a confirmation when it closes; a dismissed command leaves a cancel line like the classic view. */
  void onConfirmationClosed(boolean leftCancelLine) {
    if (leftCancelLine) {
      cancelLabelIsLast = true;
    }
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Warnings, agent messages, footer

  /**
   * {@code BaseTurnWidget#createWarnDialog}: BYOK 402 shows the BYOK message without actions, plain 402 shows the
   * server message with plan-driven actions, other codes show the message only. Without token based billing the
   * legacy single "upgrade" button is shown.
   */
  public void showWarning(String message, int code, String modelProviderName) {
    onChildAdded();
    String displayMessage = message;
    JsonArray actions = new JsonArray();
    CheckQuotaResult quotaStatus = quotaStatus();
    if (quotaStatus == null || !quotaStatus.tokenBasedBillingEnabled()) {
      // TODO: Remove together with the legacy fallback of the classic WarnWidget.
      if (code == 402 && message != null && message.toLowerCase().contains(LEGACY_UPGRADE_HINT)) {
        actions.add(linkAction(com.microsoft.copilot.eclipse.ui.i18n.Messages.chat_noQuotaView_updatePlanButton,
            com.microsoft.copilot.eclipse.ui.i18n.Messages.chat_noQuotaView_updatePlanButton_Tooltip,
            com.microsoft.copilot.eclipse.ui.i18n.Messages.chat_noQuotaView_updatePlanLink, true));
      }
    } else {
      boolean byokQuotaExceeded = QuotaActions.isByokQuotaExceeded(code, modelProviderName);
      if (byokQuotaExceeded) {
        displayMessage = Messages.chat_warnWidget_byokQuotaUsageMessage;
      }
      if (code == 402 && !byokQuotaExceeded) {
        CopilotPlan plan = quotaStatus.copilotPlan();
        boolean overageEnabled = quotaStatus.premiumInteractions() != null
            && quotaStatus.premiumInteractions().overagePermitted();
        List<QuotaAction> quotaActions = QuotaActions.forPlan(plan, overageEnabled, quotaStatus.canUpgradePlan());
        for (QuotaAction action : quotaActions) {
          actions.add(linkAction(action.label(), action.tooltip(), action.url(), action.primary()));
        }
      }
    }
    JsonObject msg = new JsonObject();
    msg.addProperty("turnId", domId);
    msg.addProperty("message", StringUtils.defaultString(displayMessage));
    msg.add("actions", actions);
    surface.post(Protocol.OUT_WARN_SHOW, msg);
  }

  private CheckQuotaResult quotaStatus() {
    if (surface.serviceManager() == null || surface.serviceManager().getAuthStatusManager() == null) {
      return null;
    }
    return surface.serviceManager().getAuthStatusManager().getQuotaStatus();
  }

  private JsonObject linkAction(String label, String tooltip, String url, boolean primary) {
    return action(label, tooltip, primary, () -> UiUtils.openLink(url));
  }

  private JsonObject action(String label, String tooltip, boolean primary, Runnable runnable) {
    JsonObject action = new JsonObject();
    action.addProperty("id", surface.registerAction(runnable));
    action.addProperty("label", StringUtils.defaultString(label));
    if (tooltip != null) {
      action.addProperty("tooltip", tooltip);
    }
    action.addProperty("primary", primary);
    return action;
  }

  /** {@code BaseTurnWidget#createAgentMessageWidget}. */
  public void showAgentMessage(CodingAgentMessageRequestParams params) {
    if (params == null) {
      return;
    }
    onChildAdded();
    JsonObject msg = new JsonObject();
    msg.addProperty("turnId", domId);
    if (StringUtils.isNotEmpty(params.getTitle())) {
      msg.addProperty("title", params.getTitle());
    }
    String description = params.getDescription();
    if (StringUtils.isNotBlank(description)) {
      // The classic widget shows a preview of the description.
      msg.addProperty("description", description.length() > AGENT_DESCRIPTION_PREVIEW
          ? description.substring(0, AGENT_DESCRIPTION_PREVIEW) + "..." : description);
    }
    JsonArray actions = new JsonArray();
    if (StringUtils.isNotEmpty(params.getPrLink())) {
      String prLink = params.getPrLink();
      actions.add(action(Messages.agentMessageWidget_openInBrowserButton,
          Messages.agentMessageWidget_openInBrowserTooltip, true, () -> UiUtils.openLink(prLink)));
      actions.add(action(Messages.agentMessageWidget_openJobListButton, Messages.agentMessageWidget_openJobListTooltip,
          false, () -> UiUtils.openE4Part(Constants.GITHUB_JOBS_VIEW_ID)));
    }
    msg.add("actions", actions);
    surface.post(Protocol.OUT_AGENT_MESSAGE_SHOW, msg);
  }

  /** Model information in the turn footer. */
  void showModelInfo(String text) {
    JsonObject msg = new JsonObject();
    msg.addProperty("turnId", domId);
    msg.addProperty("text", text);
    surface.post(Protocol.OUT_MODEL_INFO, msg);
  }

  /** The "Compacting conversation..." indicator. */
  void showCompacting(boolean visible, String label) {
    JsonObject msg = new JsonObject();
    msg.addProperty("turnId", domId);
    msg.addProperty("visible", visible);
    if (label != null) {
      msg.addProperty("label", label);
    }
    surface.post(Protocol.OUT_COMPACTING, msg);
  }

  private void post(String type) {
    JsonObject msg = new JsonObject();
    msg.addProperty("turnId", domId);
    surface.post(type, msg);
  }

  /** Release resources held for the page. */
  void dispose() {
    if (thinking != null) {
      thinking.dispose();
    }
  }
}
