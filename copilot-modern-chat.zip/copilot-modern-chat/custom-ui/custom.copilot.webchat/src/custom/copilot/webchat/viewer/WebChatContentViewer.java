package custom.copilot.webchat.viewer;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTError;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.browser.BrowserFunction;
import org.eclipse.swt.browser.LocationEvent;
import org.eclipse.swt.browser.LocationListener;
import org.eclipse.swt.browser.ProgressEvent;
import org.eclipse.swt.browser.ProgressListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.ScrollBar;

import com.microsoft.copilot.eclipse.ui.chat.BaseTurnWidget;
import com.microsoft.copilot.eclipse.ui.chat.ChatContentViewer;
import com.microsoft.copilot.eclipse.ui.chat.ChatView;
import com.microsoft.copilot.eclipse.ui.chat.CopilotTurnWidget;
import com.microsoft.copilot.eclipse.ui.chat.DragReferenceManager;
import com.microsoft.copilot.eclipse.ui.chat.services.ChatServiceManager;
import com.microsoft.copilot.eclipse.ui.utils.SwtUtils;
import com.microsoft.copilot.eclipse.ui.utils.UiUtils;

import custom.copilot.webchat.Messages;
import custom.copilot.webchat.WebChatPlugin;
import custom.copilot.webchat.actions.CodeActions;
import custom.copilot.webchat.actions.LinkOpener;
import custom.copilot.webchat.bridge.ChatBridge;
import custom.copilot.webchat.bridge.Protocol;
import custom.copilot.webchat.preferences.WebChatPreferences;

/**
 * Renders the chat conversation in an embedded browser.
 *
 * <p>Extends the classic {@link ChatContentViewer}, so the chat view and the services keep using the same API and
 * the same event processing (streaming queue, error handling, quota fallback, todo list updates). Only the creation
 * of turn widgets is redirected to web-backed turns; the inherited SWT content area stays hidden.
 */
public class WebChatContentViewer extends ChatContentViewer implements ChatSurface {

  private static final String CHAT_VIEW_ID = "com.microsoft.copilot.eclipse.ui.chat.ChatView";
  private static final int MAX_LINK_LENGTH = 8192;
  private static final int MAX_CODE_LENGTH = 5_000_000;
  private static final int MAX_ID_LENGTH = 200;

  private final ChatServiceManager services;
  private final Browser browser;
  private final ChatBridge bridge;
  private final String pageUrl;
  private final Executor uiExecutor;

  private final AtomicInteger idCounter = new AtomicInteger();
  private final Map<String, BaseTurnWidget> turnsByDomId = new ConcurrentHashMap<>();
  private final Map<String, Runnable> actions = new ConcurrentHashMap<>();
  private final Map<String, WebToolConfirmationDialog> confirmations = new ConcurrentHashMap<>();
  private final Map<Image, String> avatarIds = new IdentityHashMap<>();
  private final Map<String, String> avatarUris = new HashMap<>();
  private final Runnable fontCallback;
  private final IPropertyChangeListener textFontListener;
  private DragReferenceManager dragReferenceManager;
  private boolean pageLoaded;

  /**
   * Create the viewer.
   *
   * @param parent the parent composite
   * @param style the SWT style
   * @param serviceManager the chat services
   * @param pageUrl the URL of {@code web/index.html}
   * @throws SWTError if no suitable browser is available (the caller falls back to the classic viewer)
   */
  public WebChatContentViewer(Composite parent, int style, ChatServiceManager serviceManager, String pageUrl) {
    super(parent, style, serviceManager);
    this.services = serviceManager;
    this.pageUrl = pageUrl;
    Display display = getDisplay();
    this.uiExecutor = task -> {
      if (!display.isDisposed()) {
        display.asyncExec(() -> {
          if (!isDisposed()) {
            task.run();
          }
        });
      }
    };

    // The inherited SWT content area and scroll bar are not used.
    for (Control child : getChildren()) {
      child.setVisible(false);
    }
    ScrollBar verticalBar = getVerticalBar();
    if (verticalBar != null) {
      verticalBar.setVisible(false);
    }

    try {
      this.browser = new Browser(this, browserStyle());
    } catch (SWTError e) {
      dispose();
      throw e;
    }
    browser.setBounds(getClientArea());
    addListener(SWT.Resize, e -> browser.setBounds(getClientArea()));

    this.bridge = new ChatBridge(this::execute, uiExecutor, this::createInitMessage, this::logError);
    registerInboundHandlers();
    new BrowserFunction(browser, Protocol.JAVA_FUNCTION) {
      @Override
      public Object function(Object[] arguments) {
        bridge.receive(arguments != null && arguments.length > 0 ? arguments[0] : null);
        return null;
      }
    };
    installNavigationGuards();
    installContextMenu();

    this.fontCallback = () -> postTheme();
    if (services != null && services.getChatFontService() != null) {
      services.getChatFontService().registerCallback(fontCallback);
    }
    this.textFontListener = event -> {
      if (JFaceResources.TEXT_FONT.equals(event.getProperty())) {
        uiExecutor.execute(this::postTheme);
      }
    };
    JFaceResources.getFontRegistry().addListener(textFontListener);
    attachDropSupport();

    browser.setUrl(pageUrl);
  }

  private static int browserStyle() {
    // Internet Explorer cannot run the page; on Windows only Edge (WebView2) is accepted.
    return "win32".equals(SWT.getPlatform()) ? SWT.EDGE : SWT.NONE;
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Page lifecycle and security

  private void installNavigationGuards() {
    browser.addLocationListener(new LocationListener() {
      @Override
      public void changing(LocationEvent event) {
        // Only the chat page itself may be loaded; everything else (dropped files, stray links) is blocked.
        if (!pageLoaded && isPageUrl(event.location)) {
          bridge.pageLoading();
          return;
        }
        event.doit = false;
      }

      @Override
      public void changed(LocationEvent event) {
        // nothing to do
      }
    });
    browser.addOpenWindowListener(event -> event.required = true);
    browser.addProgressListener(new ProgressListener() {
      @Override
      public void changed(ProgressEvent event) {
        // nothing to do
      }

      @Override
      public void completed(ProgressEvent event) {
        pageLoaded = true;
        // In case the page announced itself before the browser function was available.
        execute("window.CopilotChat&&window.CopilotChat.announce&&window.CopilotChat.announce();");
      }
    });
  }

  private boolean isPageUrl(String location) {
    if ("about:blank".equals(location)) {
      return true;
    }
    return samePage(location, pageUrl);
  }

  /** Compares two file URLs by their decoded path; engines differ in slashes and percent-encoding. */
  static boolean samePage(String location, String page) {
    String a = pathOf(location);
    String b = pathOf(page);
    return a != null && a.equalsIgnoreCase(b);
  }

  private static String pathOf(String url) {
    if (url == null || !url.regionMatches(true, 0, "file:", 0, 5)) {
      return null;
    }
    try {
      String path = new java.net.URI(url.replace(" ", "%20").replace("\\", "/")).getPath();
      return path != null ? path.replaceAll("/+", "/") : null;
    } catch (java.net.URISyntaxException e) {
      return null;
    }
  }

  private boolean execute(String script) {
    return !browser.isDisposed() && browser.execute(script);
  }

  private void installContextMenu() {
    // Replaces the browser's own menu (which offers "Reload" and would discard the conversation).
    Menu menu = new Menu(browser);
    MenuItem copy = new MenuItem(menu, SWT.PUSH);
    copy.setText(Messages.menu_copy);
    copy.addListener(SWT.Selection, e -> {
      Object selection = browser.evaluate("return window.getSelection ? window.getSelection().toString() : '';");
      if (selection instanceof String text && !text.isEmpty()) {
        SwtUtils.copyToClipboard(browser, text);
      }
    });
    MenuItem selectAll = new MenuItem(menu, SWT.PUSH);
    selectAll.setText(Messages.menu_selectAll);
    selectAll.addListener(SWT.Selection, e -> execute(
        "(function(){var c=document.getElementById('conversation');var r=document.createRange();"
            + "r.selectNodeContents(c);var s=window.getSelection();s.removeAllRanges();s.addRange(r);})();"));
    browser.setMenu(menu);
  }

  private void attachDropSupport() {
    try {
      ChatView chatView = UiUtils.getView(CHAT_VIEW_ID, ChatView.class);
      if (chatView != null && services != null) {
        dragReferenceManager = new DragReferenceManager(chatView, services.getReferencedFileService());
        dragReferenceManager.attach(browser);
      }
    } catch (SWTError | RuntimeException e) {
      // Some engines do not allow a drop target on the browser; files can still be dropped on the input area.
      dragReferenceManager = null;
    }
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Messages from the page

  private void registerInboundHandlers() {
    bridge.on(Protocol.IN_LOG, payload -> {
      String level = ChatBridge.stringOf(payload, "level");
      String message = ChatBridge.boundedString(payload, "message", 8000);
      if (message == null) {
        return;
      }
      if ("error".equals(level)) {
        WebChatPlugin.logError("Chat page: " + message, null);
      } else if ("warn".equals(level)) {
        WebChatPlugin.logWarning("Chat page: " + message, null);
      }
    });
    bridge.on(Protocol.IN_OPEN_LINK, payload -> {
      String href = ChatBridge.boundedString(payload, "href", MAX_LINK_LENGTH);
      if (href != null) {
        LinkOpener.open(href);
      }
    });
    bridge.on(Protocol.IN_COPY_CODE, payload -> {
      String code = ChatBridge.boundedString(payload, "code", MAX_CODE_LENGTH);
      String domId = ChatBridge.boundedString(payload, "turnId", MAX_ID_LENGTH);
      BaseTurnWidget turn = domId != null ? turnsByDomId.get(domId) : null;
      int index = intOf(payload, "blockIndex");
      CodeActions.copy(browser, services != null ? services.getLanguageServerConnection() : null,
          turn != null ? turn.getTurnId() : null, index, code);
    });
    bridge.on(Protocol.IN_COPY_TEXT, payload -> {
      String text = ChatBridge.boundedString(payload, "text", MAX_CODE_LENGTH);
      if (text != null && !text.isEmpty()) {
        SwtUtils.copyToClipboard(browser, text);
      }
    });
    bridge.on(Protocol.IN_INSERT_CODE, payload -> {
      String code = ChatBridge.boundedString(payload, "code", MAX_CODE_LENGTH);
      if (code != null) {
        CodeActions.insert(browser, code);
      }
    });
    bridge.on(Protocol.IN_ACTION, payload -> {
      String id = ChatBridge.boundedString(payload, "id", MAX_ID_LENGTH);
      Runnable action = id != null ? actions.get(id) : null;
      if (action != null) {
        action.run();
      }
    });
    bridge.on(Protocol.IN_CONFIRM, payload -> {
      String id = ChatBridge.boundedString(payload, "confirmId", MAX_ID_LENGTH);
      String choice = ChatBridge.boundedString(payload, "choice", MAX_ID_LENGTH);
      WebToolConfirmationDialog dialog = id != null ? confirmations.get(id) : null;
      if (dialog != null && !dialog.isDisposed()) {
        dialog.choose(choice);
      }
    });
  }

  private static int intOf(JsonObject payload, String key) {
    JsonElement element = payload.get(key);
    if (element == null || !element.isJsonPrimitive() || !element.getAsJsonPrimitive().isNumber()) {
      return 0;
    }
    return Math.max(0, element.getAsInt());
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Init and theme

  private JsonObject createInitMessage() {
    JsonObject init = new JsonObject();
    init.add("theme", ThemeSupport.theme(themeSource()));
    JsonObject features = new JsonObject();
    features.addProperty("mermaid", WebChatPreferences.get(WebChatPreferences.MERMAID));
    features.addProperty("math", WebChatPreferences.get(WebChatPreferences.MATH));
    init.add("features", features);
    init.add("labels", labels());
    return init;
  }

  /** The chat view's content wrapper carries the themed colors. */
  private Control themeSource() {
    return getParent() != null && !getParent().isDisposed() ? getParent() : this;
  }

  private void postTheme() {
    if (isDisposed()) {
      return;
    }
    JsonObject msg = new JsonObject();
    msg.add("theme", ThemeSupport.theme(themeSource()));
    bridge.post(Protocol.OUT_THEME, msg);
  }

  private static JsonObject labels() {
    JsonObject labels = new JsonObject();
    labels.addProperty("copy", Messages.web_copy);
    labels.addProperty("copyCode", Messages.web_copyCode);
    labels.addProperty("copied", Messages.web_copied);
    labels.addProperty("insert", Messages.web_insert);
    labels.addProperty("plainText", Messages.web_plainText);
    labels.addProperty("mermaid", Messages.web_mermaid);
    labels.addProperty("showDiagram", Messages.web_showDiagram);
    labels.addProperty("showSource", Messages.web_showSource);
    labels.addProperty("diagram", Messages.web_diagram);
    labels.addProperty("renderingDiagram", Messages.web_renderingDiagram);
    labels.addProperty("diagramError", Messages.web_diagramError);
    labels.addProperty("diagramTooLarge", Messages.web_diagramTooLarge);
    labels.addProperty("showAllLines", Messages.web_showAllLines);
    labels.addProperty("showLess", Messages.web_showLess);
    labels.addProperty("subagent", Messages.web_subagent);
    labels.addProperty("moreOptions", Messages.web_moreOptions);
    labels.addProperty("copyResponse", Messages.web_copyResponse);
    labels.addProperty("scrollToBottom", Messages.web_scrollToBottom);
    labels.addProperty("conversation", Messages.web_conversation);
    labels.addProperty("responding", Messages.web_responding);
    labels.addProperty("responseComplete", Messages.web_responseComplete);
    labels.addProperty("thinking", com.microsoft.copilot.eclipse.ui.chat.Messages.thinking_title);
    labels.addProperty("compacting", com.microsoft.copilot.eclipse.ui.i18n.Messages.chat_compacting_conversation);
    return labels;
  }

  // ---------------------------------------------------------------------------------------------------------------
  // ChatContentViewer overrides

  @Override
  protected CopilotTurnWidget createCopilotTurnWidget(Composite parent, String turnId) {
    return new WebCopilotTurnWidget(parent, this, turnId);
  }

  @Override
  protected BaseTurnWidget createUserTurnWidget(Composite parent, String turnId) {
    return new WebUserTurnWidget(parent, this, turnId);
  }

  @Override
  public void startNewTurn(String workDoneToken, String message) {
    super.startNewTurn(workDoneToken, message);
    // Like the classic view: the new user message moves to the top and the answer follows below it.
    if (getTurnWidget(workDoneToken) instanceof WebUserTurnWidget userTurn) {
      JsonObject msg = new JsonObject();
      msg.addProperty("turnId", userTurn.presenter().domId());
      bridge.post(Protocol.OUT_SCROLL_PIN, msg);
    }
  }

  @Override
  public void renderErrorMessage(String errorMessage) {
    JsonObject msg = new JsonObject();
    msg.addProperty("message", errorMessage);
    bridge.post(Protocol.OUT_ERROR_SHOW, msg);
  }

  @Override
  public boolean setFocus() {
    return browser != null && !browser.isDisposed() ? browser.setFocus() : super.setFocus();
  }

  @Override
  public void dispose() {
    if (bridge != null) {
      bridge.dispose();
    }
    if (fontCallback != null && services != null && services.getChatFontService() != null) {
      services.getChatFontService().unregisterCallback(fontCallback);
    }
    if (textFontListener != null) {
      JFaceResources.getFontRegistry().removeListener(textFontListener);
    }
    if (dragReferenceManager != null) {
      dragReferenceManager.dispose();
      dragReferenceManager = null;
    }
    actions.clear();
    confirmations.clear();
    turnsByDomId.clear();
    super.dispose();
  }

  // ---------------------------------------------------------------------------------------------------------------
  // ChatSurface

  @Override
  public void post(String type, JsonObject fields) {
    if (bridge != null) {
      bridge.post(type, fields);
    }
  }

  @Override
  public String registerTurn(BaseTurnWidget widget) {
    String id = "t" + idCounter.incrementAndGet();
    turnsByDomId.put(id, widget);
    return id;
  }

  @Override
  public String registerAction(Runnable action) {
    String id = UUID.randomUUID().toString();
    actions.put(id, action);
    return id;
  }

  @Override
  public String registerConfirmation(WebToolConfirmationDialog dialog) {
    String id = UUID.randomUUID().toString();
    confirmations.put(id, dialog);
    return id;
  }

  @Override
  public void unregisterConfirmation(String confirmationId) {
    confirmations.remove(confirmationId);
  }

  @Override
  public synchronized String avatarId(Image image) {
    if (image == null || image.isDisposed()) {
      return null;
    }
    String id = avatarIds.get(image);
    if (id != null) {
      return id;
    }
    String uri = ThemeSupport.dataUri(image);
    if (uri == null) {
      return null;
    }
    // Different Image instances with the same pixels share one id.
    for (Map.Entry<String, String> entry : avatarUris.entrySet()) {
      if (entry.getValue().equals(uri)) {
        avatarIds.put(image, entry.getKey());
        return entry.getKey();
      }
    }
    id = "a" + idCounter.incrementAndGet();
    avatarIds.put(image, id);
    avatarUris.put(id, uri);
    JsonObject msg = new JsonObject();
    msg.addProperty("id", id);
    msg.addProperty("uri", uri);
    post(Protocol.OUT_AVATAR, msg);
    return id;
  }

  @Override
  public ChatServiceManager serviceManager() {
    return services;
  }

  @Override
  public Executor uiExecutor() {
    return uiExecutor;
  }

  @Override
  public void logError(String message, Throwable cause) {
    WebChatPlugin.logError(message, cause);
  }

  /** For tests: the embedded browser. */
  Browser browser() {
    return browser;
  }

  /** For tests: the bridge. */
  ChatBridge bridge() {
    return bridge;
  }
}
