// @ts-check
// Derives the UI palette from the colors and fonts of the Eclipse chat view, so the web view blends into the IDE in
// both light and dark themes.
(function (global) {
  'use strict';

  /** @type {any} */
  const CC = (global.CopilotChat = global.CopilotChat || {});
  const { parseColor, mix, luminance } = CC.util;

  const WHITE = { r: 255, g: 255, b: 255 };
  const BLACK = { r: 0, g: 0, b: 0 };

  /**
   * @param {string|undefined} name
   * @param {string} fallbackStack
   * @returns {string}
   */
  function fontStack(name, fallbackStack) {
    // macOS reports private system font names such as ".AppleSystemUIFont" which CSS cannot address.
    if (!name || name.startsWith('.') || /^(System|Segoe UI Variable)/i.test(name)) {
      return fallbackStack;
    }
    return `"${name.replace(/["\\]/g, '')}", ${fallbackStack}`;
  }

  const UI_FONTS = '-apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, Ubuntu, "Helvetica Neue", Arial, sans-serif';
  const CODE_FONTS = '"SF Mono", Menlo, Monaco, Consolas, "Cascadia Mono", "DejaVu Sans Mono", "Liberation Mono", monospace';

  /**
   * Applies the theme received from Java.
   * @param {{dark?: boolean, background?: string, foreground?: string, fontFamily?: string, fontSize?: number,
   *   codeFontFamily?: string, codeFontSize?: number, platform?: string}} theme
   */
  function apply(theme) {
    const t = theme || {};
    let bg = parseColor(t.background || '');
    let fg = parseColor(t.foreground || '');
    let dark = typeof t.dark === 'boolean' ? t.dark : bg ? luminance(bg) < 0.4 : false;
    if (!bg) {
      bg = dark ? { r: 31, g: 31, b: 31 } : WHITE;
    }
    if (!fg || Math.abs(luminance(fg) - luminance(bg)) < 0.25) {
      fg = dark ? { r: 204, g: 204, b: 204 } : { r: 31, g: 31, b: 31 };
    }
    // Trust the measured background over the reported flag when they disagree (e.g. custom themes).
    dark = luminance(bg) < 0.4;

    const vars = {
      '--cc-bg': `rgb(${bg.r}, ${bg.g}, ${bg.b})`,
      '--cc-fg': `rgb(${fg.r}, ${fg.g}, ${fg.b})`,
      '--cc-muted': mix(fg, bg, 0.36),
      '--cc-subtle': mix(fg, bg, 0.55),
      '--cc-border': mix(bg, fg, dark ? 0.15 : 0.12),
      '--cc-border-strong': mix(bg, fg, dark ? 0.26 : 0.22),
      '--cc-surface': mix(bg, fg, dark ? 0.04 : 0.025),
      '--cc-surface-2': mix(bg, fg, dark ? 0.075 : 0.05),
      '--cc-hover': mix(bg, fg, dark ? 0.09 : 0.06),
      '--cc-code-bg': dark ? mix(bg, BLACK, 0.22) : mix(bg, fg, 0.03),
      '--cc-user-bg': mix(bg, fg, dark ? 0.07 : 0.045),
      '--cc-accent': dark ? '#4daafc' : '#005fb8',
      '--cc-focus': dark ? '#0078d4' : '#005fb8',
      '--cc-button-bg': '#0078d4',
      '--cc-button-hover': dark ? '#026ec1' : '#0258a8',
      '--cc-button-fg': '#ffffff',
      '--cc-secondary-bg': mix(bg, fg, dark ? 0.12 : 0.08),
      '--cc-secondary-hover': mix(bg, fg, dark ? 0.18 : 0.13),
      '--cc-danger': dark ? '#f48771' : '#c4314b',
      '--cc-danger-bg': dark ? 'rgba(244, 135, 113, 0.10)' : 'rgba(196, 49, 75, 0.07)',
      '--cc-warning': dark ? '#cca700' : '#bf8803',
      '--cc-warning-bg': dark ? 'rgba(204, 167, 0, 0.10)' : 'rgba(191, 136, 3, 0.08)',
      '--cc-success': dark ? '#89d185' : '#388a34',
      '--cc-font': fontStack(t.fontFamily, UI_FONTS),
      '--cc-font-size': `${clampSize(t.fontSize, 13)}px`,
      '--cc-code-font': fontStack(t.codeFontFamily, CODE_FONTS),
      '--cc-code-font-size': `${clampSize(t.codeFontSize, Math.max(11, clampSize(t.fontSize, 13) - 1))}px`,
    };
    const root = document.documentElement;
    for (const [k, v] of Object.entries(vars)) {
      root.style.setProperty(k, v);
    }
    root.dataset.theme = dark ? 'dark' : 'light';
    root.dataset.platform = t.platform || '';
    root.style.colorScheme = dark ? 'dark' : 'light';
    CC.theme.dark = dark;
  }

  /**
   * @param {unknown} value
   * @param {number} fallback
   */
  function clampSize(value, fallback) {
    const n = typeof value === 'number' && isFinite(value) ? value : fallback;
    return Math.round(Math.max(9, Math.min(32, n)) * 10) / 10;
  }

  CC.theme = { apply, dark: false };
})(window);
