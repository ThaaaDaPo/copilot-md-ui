// @ts-check
// Web side of the Java <-> web message channel.
//
// Java -> web: Java calls window.CopilotChat.receive([...messages]) with a batch of {type, ...payload} objects.
// Web -> Java: the page calls the BrowserFunction installed by Java (window.__copilotChatPost) with a JSON string
//              {"type": "...", "payload": {...}}. Java validates every message; the page holds no privileges.
(function (global) {
  'use strict';

  /** @type {any} */
  const CC = (global.CopilotChat = global.CopilotChat || {});

  const PROTOCOL_VERSION = 1;
  const JAVA_FUNCTION = '__copilotChatPost';

  /** @type {Map<string, (msg: any) => void>} */
  const handlers = new Map();
  /** @type {string[]} */
  const outbox = [];
  const instanceId = Math.random().toString(36).slice(2) + Date.now().toString(36);
  let flushTimer = 0;

  function javaFunction() {
    const fn = /** @type {any} */ (global)[JAVA_FUNCTION];
    return typeof fn === 'function' ? fn : null;
  }

  function flushOutbox() {
    const fn = javaFunction();
    if (!fn) {
      if (!flushTimer) {
        flushTimer = global.setTimeout(() => {
          flushTimer = 0;
          flushOutbox();
        }, 50);
      }
      return;
    }
    while (outbox.length) {
      const message = /** @type {string} */ (outbox.shift());
      try {
        fn(message);
      } catch (e) {
        // Never let a failing bridge call break rendering; the message is dropped.
        if (global.console) {
          global.console.error('Bridge post failed', e);
        }
      }
    }
  }

  /**
   * Sends a message to Java.
   * @param {string} type
   * @param {Record<string, unknown>=} payload
   */
  function post(type, payload) {
    outbox.push(JSON.stringify({ type, payload: payload || {} }));
    flushOutbox();
  }

  /**
   * Registers the handler for a Java -> web message type.
   * @param {string} type
   * @param {(msg: any) => void} handler
   */
  function on(type, handler) {
    handlers.set(type, handler);
  }

  /**
   * Entry point used by Java. Each message is handled in isolation so a single failure cannot block the rest.
   * @param {Array<any>} batch
   */
  function receive(batch) {
    if (!Array.isArray(batch)) {
      return;
    }
    for (const msg of batch) {
      if (!msg || typeof msg.type !== 'string') {
        continue;
      }
      const handler = handlers.get(msg.type);
      if (!handler) {
        log('warn', 'Unknown message type: ' + msg.type);
        continue;
      }
      try {
        handler(msg);
      } catch (e) {
        log('error', 'Failed to handle ' + msg.type + ': ' + describe(e));
      }
    }
    if (typeof CC.afterBatch === 'function') {
      try {
        CC.afterBatch();
      } catch (e) {
        log('error', 'afterBatch failed: ' + describe(e));
      }
    }
  }

  /**
   * @param {'info'|'warn'|'error'} level
   * @param {string} message
   */
  function log(level, message) {
    post('log', { level, message: String(message).slice(0, 4000) });
  }

  /** @param {unknown} e */
  function describe(e) {
    if (e instanceof Error) {
      return e.message + (e.stack ? '\n' + e.stack : '');
    }
    return String(e);
  }

  /** Tells Java this page instance is ready. Safe to call repeatedly; Java de-duplicates by instance id. */
  function announce() {
    post('ready', { instanceId, protocol: PROTOCOL_VERSION });
  }

  global.addEventListener('error', (event) => {
    log('error', 'Uncaught: ' + (event.message || '') + ' @' + (event.filename || '') + ':' + (event.lineno || ''));
  });
  global.addEventListener('unhandledrejection', (event) => {
    log('error', 'Unhandled rejection: ' + describe(event.reason));
  });

  CC.protocolVersion = PROTOCOL_VERSION;
  CC.bridge = { post, on, log, describe, announce, instanceId };
  CC.receive = receive;
  CC.announce = announce;
})(window);
