// @ts-check
// Mermaid diagrams inside chat messages.
//
// - Mermaid (3.5 MB) is loaded on first use only.
// - securityLevel "strict": no click handlers, labels are sanitized by Mermaid; the SVG is sanitized again here.
// - Diagrams render one at a time and only when (nearly) visible, so long chats with many diagrams stay responsive.
// - A broken diagram shows an error and its source; the rest of the message is unaffected.
(function (global) {
  'use strict';

  /** @type {any} */
  const CC = (global.CopilotChat = global.CopilotChat || {});
  const g = /** @type {any} */ (global);

  const SCRIPT = 'vendor/mermaid/mermaid.min.js';
  const MAX_SOURCE = 50000;

  /** @type {Promise<any>|null} */
  let loading = null;
  let initializedFor = '';
  let counter = 0;
  /** @type {Element[]} */
  const queue = [];
  let running = false;
  /** @type {Map<string, {svg?: string, error?: string}>} */
  const cache = new Map();
  /** @type {IntersectionObserver|null} */
  let observer = null;

  function load() {
    if (g.mermaid) {
      return Promise.resolve(g.mermaid);
    }
    if (!loading) {
      loading = new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = SCRIPT;
        script.onload = () => (g.mermaid ? resolve(g.mermaid) : reject(new Error('Mermaid did not initialize')));
        script.onerror = () => reject(new Error('Failed to load ' + SCRIPT));
        document.head.appendChild(script);
      });
      loading.catch(() => {
        loading = null;
      });
    }
    return loading;
  }

  function themeKey() {
    return CC.theme && CC.theme.dark ? 'dark' : 'default';
  }

  /** @param {any} mermaid */
  function initialize(mermaid) {
    const theme = themeKey();
    if (initializedFor === theme) {
      return;
    }
    const style = getComputedStyle(document.documentElement);
    mermaid.initialize({
      startOnLoad: false,
      securityLevel: 'strict',
      theme,
      fontFamily: style.getPropertyValue('--cc-font') || 'sans-serif',
      suppressErrorRendering: true,
      deterministicIds: true,
      maxTextSize: MAX_SOURCE,
      maxEdges: 1000,
      flowchart: { useMaxWidth: true, htmlLabels: false },
      sequence: { useMaxWidth: true },
      class: { useMaxWidth: true, htmlLabels: false },
      state: { useMaxWidth: true },
      er: { useMaxWidth: true },
      gantt: { useMaxWidth: true },
    });
    initializedFor = theme;
  }

  function ensureObserver() {
    if (observer || typeof IntersectionObserver === 'undefined') {
      return observer;
    }
    observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            /** @type {IntersectionObserver} */ (observer).unobserve(entry.target);
            schedule(entry.target);
          }
        }
      },
      { root: document.getElementById('scroller'), rootMargin: '600px 0px' }
    );
    return observer;
  }

  /**
   * Registers a freshly rendered mermaid block.
   * @param {Element} block
   */
  function enqueue(block) {
    block.setAttribute('data-state', 'pending');
    const obs = ensureObserver();
    if (obs) {
      obs.observe(block);
    } else {
      schedule(block);
    }
  }

  /** @param {Element} block */
  function schedule(block) {
    if (!queue.includes(block)) {
      queue.push(block);
    }
    if (!running) {
      running = true;
      // Yield to the renderer first so the surrounding message paints before the diagram work starts.
      setTimeout(drain, 0);
    }
  }

  async function drain() {
    try {
      while (queue.length) {
        const block = /** @type {Element} */ (queue.shift());
        if (!block.isConnected) {
          continue;
        }
        await renderBlock(block);
        await new Promise((r) => setTimeout(r, 0));
      }
    } finally {
      running = false;
    }
  }

  /** @param {Element} block */
  async function renderBlock(block) {
    const sourceEl = block.querySelector('.mermaid-block__source code');
    const target = block.querySelector('.mermaid-block__diagram');
    if (!sourceEl || !target) {
      return;
    }
    const source = sourceEl.textContent || '';
    const key = themeKey() + ':' + CC.util.hash(source);
    let result = cache.get(key);
    if (!result) {
      result = await renderSource(source);
      cache.set(key, result);
    }
    if (!block.isConnected) {
      return;
    }
    if (result.svg) {
      target.innerHTML = result.svg;
      block.setAttribute('data-state', 'rendered');
    } else {
      showError(block, target, result.error || 'Unknown error');
    }
  }

  /**
   * @param {string} source
   * @returns {Promise<{svg?: string, error?: string}>}
   */
  async function renderSource(source) {
    if (source.length > MAX_SOURCE) {
      return { error: CC.label('diagramTooLarge', 'The diagram is too large to render.') };
    }
    const id = 'cc-mermaid-' + ++counter;
    try {
      const mermaid = await load();
      initialize(mermaid);
      const out = await mermaid.render(id, source);
      return { svg: sanitizeSvg(out.svg) };
    } catch (e) {
      return { error: e instanceof Error ? e.message : String(e) };
    } finally {
      // Mermaid renders into temporary nodes; make sure none is left behind on failure.
      for (const stray of [document.getElementById(id), document.getElementById('d' + id)]) {
        if (stray && !stray.closest('.mermaid-block')) {
          stray.remove();
        }
      }
    }
  }

  /** @param {string} svg */
  function sanitizeSvg(svg) {
    if (!g.DOMPurify) {
      return '';
    }
    return g.DOMPurify.sanitize(svg, {
      USE_PROFILES: { svg: true, svgFilters: true, html: true },
      ADD_TAGS: ['foreignObject', 'style'],
      FORBID_TAGS: ['script', 'iframe', 'object', 'embed', 'image', 'a'],
      FORBID_ATTR: ['href', 'xlink:href', 'onclick', 'onload', 'onerror'],
      HTML_INTEGRATION_POINTS: { foreignobject: true },
    });
  }

  /**
   * @param {Element} block
   * @param {Element} target
   * @param {string} message
   */
  function showError(block, target, message) {
    block.setAttribute('data-state', 'error');
    target.textContent = '';
    const box = document.createElement('div');
    box.className = 'mermaid-block__error';
    const title = document.createElement('div');
    title.className = 'mermaid-block__error-title';
    title.textContent = CC.label('diagramError', 'The diagram could not be rendered.');
    const detail = document.createElement('div');
    detail.className = 'mermaid-block__error-detail';
    detail.textContent = message.split('\n').slice(0, 6).join('\n');
    box.append(title, detail);
    target.appendChild(box);
    setView(block, 'source');
  }

  /**
   * Switches between diagram and source view.
   * @param {Element} block
   * @param {string} view "diagram" | "source"
   */
  function setView(block, view) {
    block.setAttribute('data-view', view === 'source' ? 'source' : 'diagram');
    for (const button of Array.from(block.querySelectorAll('[data-action="mermaid-view"]'))) {
      button.setAttribute('aria-pressed', String(button.getAttribute('data-view') === view));
    }
  }

  /** Re-renders all diagrams, e.g. after a theme change. */
  function refreshAll() {
    initializedFor = '';
    for (const block of Array.from(document.querySelectorAll('.mermaid-block[data-state="rendered"]'))) {
      schedule(block);
    }
  }

  CC.mermaidView = { enqueue, setView, refreshAll, sanitizeSvg };
})(window);
