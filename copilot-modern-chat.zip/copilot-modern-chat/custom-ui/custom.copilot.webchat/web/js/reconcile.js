// @ts-check
// Block-level DOM reconciliation for streamed markdown.
//
// A streamed message is re-rendered as a whole (markdown is not incremental), but only top-level blocks whose
// generated HTML changed are replaced in the DOM. Earlier blocks stay untouched, which keeps the user's text
// selection, rendered diagrams and highlighted code stable while new tokens arrive.
(function (global) {
  'use strict';

  /** @type {any} */
  const CC = (global.CopilotChat = global.CopilotChat || {});

  /** Generated (pre-enhancement) HTML of each block, used to detect changes. */
  const RAW = new WeakMap();

  /** @param {Node} node */
  function isBlank(node) {
    return node.nodeType === 3 && !(node.textContent || '').trim();
  }

  /** @param {Node} node */
  function rawOf(node) {
    return node.nodeType === 1 ? /** @type {Element} */ (node).outerHTML : node.textContent || '';
  }

  /**
   * Updates {@code container} so its children match {@code html}.
   * @param {Element} container
   * @param {string} html sanitized HTML
   * @returns {Element[]} the elements that were inserted (need post-processing)
   */
  function reconcile(container, html) {
    const template = document.createElement('template');
    template.innerHTML = html;
    const next = Array.from(template.content.childNodes).filter((n) => !isBlank(n));
    const current = Array.from(container.childNodes).filter((n) => !isBlank(n));
    /** @type {Element[]} */
    const inserted = [];
    let i = 0;
    for (; i < next.length; i++) {
      const node = next[i];
      const raw = rawOf(node);
      const old = current[i];
      if (old && RAW.get(old) === raw) {
        continue;
      }
      RAW.set(node, raw);
      if (old) {
        container.replaceChild(node, old);
      } else {
        container.appendChild(node);
      }
      if (node.nodeType === 1) {
        inserted.push(/** @type {Element} */ (node));
      }
    }
    for (; i < current.length; i++) {
      container.removeChild(current[i]);
    }
    return inserted;
  }

  CC.reconcile = reconcile;
})(window);
