// @ts-check
// Conversation model and rendering. The Java side is the source of truth; this script only projects the messages it
// receives (see Protocol.java for the message catalogue) into the DOM.
(function (global) {
  'use strict';

  /** @type {any} */
  const CC = (global.CopilotChat = global.CopilotChat || {});
  const { el, frameCoalescer } = CC.util;
  const bridge = CC.bridge;

  /** Minimum time between two renders of a part that is still streaming. */
  const STREAM_RENDER_INTERVAL_MS = 50;
  /** Distance from the bottom (px) that still counts as "at the bottom" for auto-scroll. */
  const STICK_THRESHOLD_PX = 48;

  /**
   * @typedef {{kind: 'markdown'|'user', el: HTMLElement, src: string, final: boolean, renderedAt: number,
   *   turn: Turn}} TextPart
   * @typedef {{el: HTMLElement, status: string}} ToolPart
   * @typedef {{el: HTMLElement, body: TextPart, state: string, titleEl: HTMLElement}} ThinkingPart
   */

  class Turn {
    /**
     * @param {string} id
     * @param {string} role
     * @param {HTMLElement} root element that represents the turn
     * @param {HTMLElement} body element that receives the parts
     * @param {Turn|null} parent
     */
    constructor(id, role, root, body, parent) {
      this.id = id;
      this.role = role;
      this.el = root;
      this.body = body;
      this.parent = parent;
      /** @type {TextPart|null} */
      this.current = null;
      /** @type {TextPart[]} */
      this.textParts = [];
      /** @type {Map<string, ToolPart>} */
      this.tools = new Map();
      /** @type {Map<string, ThinkingPart>} */
      this.thinking = new Map();
      /** @type {Map<string, HTMLElement>} */
      this.confirmations = new Map();
      /** @type {HTMLElement|null} */
      this.footer = null;
      /** @type {HTMLElement|null} */
      this.compacting = null;
    }
  }

  const state = {
    /** @type {Map<string, Turn>} */
    turns: new Map(),
    /** @type {Map<string, string>} */
    avatars: new Map(),
    /** @type {Set<TextPart>} */
    dirty: new Set(),
    /** @type {Turn|null} */
    pinnedTurn: null,
    stick: true,
    userIntentAt: 0,
    /** @type {HTMLElement|null} */
    errorBanner: null,
    renderTimer: 0,
  };

  /** @type {HTMLElement} */
  let scroller;
  /** @type {HTMLElement} */
  let conversation;
  /** @type {HTMLElement} */
  let spacer;
  /** @type {HTMLElement} */
  let scrollButton;
  /** @type {HTMLElement} */
  let liveRegion;

  /**
   * @param {string} key
   * @param {string} fallback
   */
  function label(key, fallback) {
    const value = CC.labels && CC.labels[key];
    return typeof value === 'string' && value ? value : fallback;
  }
  CC.label = label;

  // ---------------------------------------------------------------------------------------------------------------
  // Turns

  /**
   * @param {string} turnId
   * @returns {Turn|null}
   */
  function turnOf(turnId) {
    const turn = state.turns.get(turnId);
    if (!turn) {
      bridge.log('warn', 'Unknown turn ' + turnId);
      return null;
    }
    return turn;
  }

  /** @param {any} msg */
  function createTurn(msg) {
    if (state.turns.has(msg.turnId)) {
      return;
    }
    if (msg.role === 'subagent') {
      createSubagentTurn(msg);
      return;
    }
    const root = el('section', `turn turn--${msg.role === 'user' ? 'user' : 'copilot'}`);
    root.setAttribute('aria-label', msg.name || '');
    const header = el('header', 'turn__header');
    const avatar = /** @type {HTMLImageElement} */ (el('img', 'turn__avatar'));
    avatar.alt = '';
    if (msg.avatarId) {
      avatar.dataset.avatar = msg.avatarId;
      const uri = state.avatars.get(msg.avatarId);
      if (uri) {
        avatar.src = uri;
      }
    }
    header.append(avatar, el('span', 'turn__name', msg.name || ''));
    const body = el('div', 'turn__body');
    root.append(header, body);
    insertTurn(root);
    const turn = new Turn(msg.turnId, msg.role === 'user' ? 'user' : 'copilot', root, body, null);
    state.turns.set(msg.turnId, turn);
    if (turn.role === 'copilot') {
      setLive(label('responding', 'Copilot is responding'));
    }
  }

  /** @param {HTMLElement} root */
  function insertTurn(root) {
    // The global error banner always stays below the newest turn.
    if (state.errorBanner && state.errorBanner.parentNode === conversation) {
      conversation.insertBefore(root, state.errorBanner);
    } else {
      conversation.appendChild(root);
    }
  }

  /** @param {any} msg */
  function createSubagentTurn(msg) {
    const parent = turnOf(msg.parentId);
    if (!parent) {
      return;
    }
    closeSegment(parent);
    const root = el('div', 'subagent is-running');
    const header = el('button', 'subagent__header');
    header.setAttribute('type', 'button');
    header.setAttribute('aria-expanded', 'true');
    header.setAttribute('data-action', 'toggle-subagent');
    header.append(el('span', 'status-icon status-icon--running'), el('span', 'subagent__title', msg.name || label('subagent', 'Subagent')),
      el('span', 'chevron'));
    const body = el('div', 'subagent__body');
    root.append(header, body);
    parent.body.appendChild(root);
    state.turns.set(msg.turnId, new Turn(msg.turnId, 'subagent', root, body, parent));
  }

  /** @param {any} msg */
  function setSubagentState(msg) {
    const turn = turnOf(msg.turnId);
    if (!turn || turn.role !== 'subagent') {
      return;
    }
    closeSegment(turn);
    turn.el.classList.remove('is-running', 'is-completed', 'is-cancelled', 'is-error');
    turn.el.classList.add('is-' + msg.state);
    const icon = turn.el.querySelector('.subagent__header .status-icon');
    if (icon) {
      icon.className = 'status-icon status-icon--' + msg.state;
    }
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Text (markdown and user text)

  /**
   * @param {Turn} turn
   * @returns {TextPart}
   */
  function openTextPart(turn) {
    if (turn.current) {
      return turn.current;
    }
    const kind = turn.role === 'user' ? 'user' : 'markdown';
    const node = el('div', kind === 'user' ? 'user-text' : 'md');
    turn.body.appendChild(node);
    /** @type {TextPart} */
    const part = { kind, el: node, src: '', final: false, renderedAt: 0, turn };
    turn.current = part;
    turn.textParts.push(part);
    return part;
  }

  /**
   * Ends the current text segment of a turn (the next text starts a new block below other content).
   * @param {Turn} turn
   */
  function closeSegment(turn) {
    const part = turn.current;
    if (part) {
      part.final = true;
      markDirty(part);
      turn.current = null;
    }
  }

  /** @param {TextPart} part */
  function markDirty(part) {
    state.dirty.add(part);
    requestRender();
  }

  /** @param {any} msg */
  function appendText(msg) {
    const turn = turnOf(msg.turnId);
    if (!turn || typeof msg.text !== 'string' || !msg.text) {
      return;
    }
    const part = openTextPart(turn);
    part.src += msg.text;
    part.final = false;
    markDirty(part);
  }

  /** @param {any} msg */
  function flushText(msg) {
    const turn = turnOf(msg.turnId);
    if (!turn || !turn.current) {
      return;
    }
    // A flush renders everything received so far as complete; text appended later continues the same block.
    turn.current.final = true;
    markDirty(turn.current);
  }

  /** @param {TextPart} part */
  function renderTextPart(part) {
    part.renderedAt = performance.now();
    if (part.kind === 'user') {
      part.el.textContent = part.src.replace(/\s+$/, '');
      return;
    }
    let inserted;
    try {
      const html = CC.markdown.render(part.src, { final: part.final });
      inserted = CC.reconcile(part.el, html);
    } catch (e) {
      bridge.log('error', 'Rendering a message failed: ' + bridge.describe(e));
      part.el.textContent = '';
      const pre = el('pre', 'md-fallback', part.src);
      part.el.appendChild(pre);
      return;
    }
    CC.code.enhance(inserted, { final: part.final });
    if (part.final) {
      CC.code.finalize(part.el);
    }
    if (part.el.classList.contains('thinking__body') && !part.final) {
      part.el.scrollTop = part.el.scrollHeight;
    }
  }

  const requestRender = frameCoalescer(renderDirty);

  function renderDirty() {
    const now = performance.now();
    let deferred = false;
    for (const part of Array.from(state.dirty)) {
      if (!part.el.isConnected) {
        state.dirty.delete(part);
        continue;
      }
      if (!part.final && now - part.renderedAt < STREAM_RENDER_INTERVAL_MS) {
        deferred = true;
        continue;
      }
      state.dirty.delete(part);
      renderTextPart(part);
    }
    if (deferred && !state.renderTimer) {
      state.renderTimer = global.setTimeout(() => {
        state.renderTimer = 0;
        requestRender();
      }, STREAM_RENDER_INTERVAL_MS);
    }
    afterLayoutChange();
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Tool calls

  /** @param {any} msg */
  function toolStatus(msg) {
    const turn = turnOf(msg.turnId);
    if (!turn) {
      return;
    }
    closeSegment(turn);
    let part = turn.tools.get(msg.toolId);
    if (!part) {
      const node = el('div', 'tool');
      node.append(el('span', 'status-icon'), el('div', 'tool__message'));
      turn.body.appendChild(node);
      part = { el: node, status: '' };
      turn.tools.set(msg.toolId, part);
    }
    applyToolStatus(part, msg.status, msg.message, msg.toolName);
    requestRender();
  }

  /**
   * @param {ToolPart} part
   * @param {string} status
   * @param {string|undefined} message markdown
   * @param {string|undefined} toolName
   */
  function applyToolStatus(part, status, message, toolName) {
    const normalized = ['running', 'completed', 'cancelled', 'error'].includes(status) ? status : 'error';
    part.status = normalized;
    part.el.className = 'tool tool--' + normalized;
    const icon = part.el.querySelector('.status-icon');
    if (icon) {
      icon.className = 'status-icon status-icon--' + normalized;
    }
    if (typeof message === 'string') {
      const target = /** @type {HTMLElement} */ (part.el.querySelector('.tool__message'));
      target.innerHTML = CC.markdown.renderInline(message);
    }
    if (toolName) {
      part.el.title = toolName;
    }
  }

  /** @param {any} msg */
  function cancelRunning(msg) {
    const turn = turnOf(msg.turnId);
    if (!turn) {
      return;
    }
    for (const part of turn.tools.values()) {
      if (part.status === 'running') {
        applyToolStatus(part, 'cancelled', undefined, undefined);
      }
    }
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Thinking

  /**
   * @param {Turn} turn
   * @param {string} blockId
   * @returns {ThinkingPart}
   */
  function thinkingPart(turn, blockId) {
    let part = turn.thinking.get(blockId);
    if (part) {
      return part;
    }
    closeSegment(turn);
    const root = el('div', 'thinking is-streaming');
    const header = el('button', 'thinking__header');
    header.setAttribute('type', 'button');
    header.setAttribute('data-action', 'toggle-thinking');
    header.setAttribute('aria-expanded', 'true');
    const titleEl = el('span', 'thinking__title', label('thinking', 'Thinking…'));
    header.append(el('span', 'status-icon status-icon--running'), titleEl, el('span', 'chevron'));
    const bodyEl = el('div', 'thinking__body md');
    root.append(header, bodyEl);
    turn.body.appendChild(root);
    /** @type {TextPart} */
    const body = { kind: 'markdown', el: bodyEl, src: '', final: false, renderedAt: 0, turn };
    part = { el: root, body, state: 'streaming', titleEl };
    turn.thinking.set(blockId, part);
    return part;
  }

  /** @param {any} msg */
  function thinkingAppend(msg) {
    const turn = turnOf(msg.turnId);
    if (!turn || typeof msg.text !== 'string') {
      return;
    }
    const part = thinkingPart(turn, msg.blockId);
    part.body.src += msg.text;
    markDirty(part.body);
  }

  /**
   * @param {ThinkingPart} part
   * @param {string} newState
   * @param {string|undefined} title
   */
  function applyThinkingState(part, newState, title) {
    part.state = newState;
    if (title) {
      part.titleEl.textContent = title;
    }
    part.el.classList.remove('is-streaming', 'is-sealed', 'is-completed', 'is-cancelled');
    part.el.classList.add('is-' + newState);
    const icon = part.el.querySelector('.thinking__header .status-icon');
    if (icon) {
      icon.className = 'status-icon status-icon--' + (newState === 'cancelled' ? 'cancelled'
        : newState === 'streaming' ? 'running' : 'thinking');
    }
    if (newState !== 'streaming') {
      setExpanded(part.el, false);
      part.body.final = true;
      markDirty(part.body);
    }
  }

  /** @param {any} msg */
  function thinkingState(msg) {
    const turn = turnOf(msg.turnId);
    const part = turn && turn.thinking.get(msg.blockId);
    if (!part) {
      return;
    }
    applyThinkingState(part, msg.state, msg.title);
  }

  /** @param {any} msg */
  function thinkingRestore(msg) {
    const turn = turnOf(msg.turnId);
    if (!turn) {
      return;
    }
    const part = thinkingPart(turn, msg.blockId);
    part.body.src = msg.text || '';
    applyThinkingState(part, msg.cancelled ? 'cancelled' : 'completed', msg.cancelled ? undefined : msg.title);
  }

  /**
   * @param {Element} root
   * @param {boolean} expanded
   */
  function setExpanded(root, expanded) {
    root.classList.toggle('is-collapsed', !expanded);
    const header = root.querySelector(':scope > button');
    if (header) {
      header.setAttribute('aria-expanded', String(expanded));
    }
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Confirmations, notices, cards

  /**
   * @param {string} text
   * @param {string} className
   * @param {string} action
   * @param {Record<string,string>} data
   * @param {string=} tooltip
   */
  function button(text, className, action, data, tooltip) {
    const node = /** @type {HTMLButtonElement} */ (el('button', className, text));
    node.type = 'button';
    node.setAttribute('data-action', action);
    for (const [k, v] of Object.entries(data)) {
      node.setAttribute('data-' + k, v);
    }
    if (tooltip) {
      node.title = tooltip;
    }
    return node;
  }

  /** @param {any} msg */
  function showConfirmation(msg) {
    const turn = turnOf(msg.turnId);
    if (!turn) {
      return;
    }
    closeSegment(turn);
    const box = el('div', 'confirm');
    box.setAttribute('role', 'group');
    box.setAttribute('aria-label', msg.title || '');
    box.dataset.confirmId = msg.confirmId;
    box.appendChild(el('div', 'confirm__title', msg.title || ''));
    if (msg.message) {
      box.appendChild(el('div', 'confirm__message', msg.message));
    }
    if (msg.command) {
      const pre = el('pre', 'confirm__command' + (msg.commandKind === 'json' ? ' is-json' : ''));
      pre.appendChild(el('code', '', msg.command));
      box.appendChild(pre);
    }
    if (msg.explanation) {
      box.appendChild(el('div', 'confirm__explanation', msg.explanation));
    }
    const actions = el('div', 'confirm__actions');
    if (msg.primary) {
      const split = el('div', 'split-button');
      split.appendChild(button(msg.primary.label, 'btn btn--primary', 'confirm', { choice: msg.primary.id }));
      const alternatives = Array.isArray(msg.alternatives) ? msg.alternatives : [];
      if (alternatives.length) {
        const arrow = button('', 'btn btn--primary split-button__arrow', 'confirm-menu', {},
          label('moreOptions', 'More options'));
        arrow.setAttribute('aria-haspopup', 'menu');
        arrow.setAttribute('aria-expanded', 'false');
        arrow.setAttribute('aria-label', label('moreOptions', 'More options'));
        const menu = el('div', 'split-button__menu');
        menu.setAttribute('role', 'menu');
        menu.hidden = true;
        for (const alt of alternatives) {
          const item = button(alt.label, 'menu-item', 'confirm', { choice: alt.id });
          item.setAttribute('role', 'menuitem');
          menu.appendChild(item);
        }
        split.append(arrow, menu);
      }
      actions.appendChild(split);
    }
    if (msg.dismiss) {
      actions.appendChild(button(msg.dismiss.label, 'btn btn--secondary', 'confirm', { choice: msg.dismiss.id }));
    }
    box.appendChild(actions);
    turn.body.appendChild(box);
    turn.confirmations.set(msg.confirmId, box);
    reveal(box);
  }

  /** @param {any} msg */
  function closeConfirmation(msg) {
    const turn = turnOf(msg.turnId);
    const box = turn && turn.confirmations.get(msg.confirmId);
    if (!turn || !box) {
      return;
    }
    turn.confirmations.delete(msg.confirmId);
    if (msg.cancelMessage) {
      const cancelled = el('div', 'tool tool--cancelled');
      cancelled.append(el('span', 'status-icon status-icon--cancelled'), el('div', 'tool__message', msg.cancelMessage));
      box.replaceWith(cancelled);
    } else {
      box.remove();
    }
    afterLayoutChange();
  }

  /**
   * @param {Array<any>} actions
   * @returns {HTMLElement|null}
   */
  function actionButtons(actions) {
    if (!Array.isArray(actions) || !actions.length) {
      return null;
    }
    const row = el('div', 'notice__actions');
    for (const action of actions) {
      row.appendChild(button(action.label, action.primary ? 'btn btn--primary' : 'btn btn--secondary', 'invoke',
        { id: action.id }, action.tooltip));
    }
    return row;
  }

  /** @param {any} msg */
  function showWarning(msg) {
    const turn = turnOf(msg.turnId);
    if (!turn) {
      return;
    }
    closeSegment(turn);
    const box = el('div', 'notice notice--warning');
    box.setAttribute('role', 'alert');
    const content = el('div', 'notice__content md');
    content.innerHTML = CC.markdown.render(msg.message || '', { final: true });
    box.append(el('span', 'notice__icon'), content);
    const actions = actionButtons(msg.actions);
    if (actions) {
      content.appendChild(actions);
    }
    turn.body.appendChild(box);
    reveal(box);
  }

  /** @param {any} msg */
  function showAgentMessage(msg) {
    const turn = turnOf(msg.turnId);
    if (!turn) {
      return;
    }
    closeSegment(turn);
    const card = el('div', 'agent-card');
    if (msg.title) {
      const title = el('div', 'agent-card__title');
      title.append(el('span', 'agent-card__icon'), el('strong', '', msg.title));
      card.appendChild(title);
    }
    if (msg.description) {
      const description = el('div', 'agent-card__description md');
      description.innerHTML = CC.markdown.render(msg.description, { final: true });
      card.appendChild(description);
    }
    const actions = actionButtons(msg.actions);
    if (actions) {
      card.appendChild(actions);
    }
    turn.body.appendChild(card);
    requestRender();
  }

  /** @param {any} msg */
  function showError(msg) {
    if (state.errorBanner) {
      state.errorBanner.remove();
    }
    const box = el('div', 'notice notice--error');
    box.setAttribute('role', 'alert');
    box.append(el('span', 'notice__icon'), el('div', 'notice__content', msg.message || ''));
    conversation.appendChild(box);
    state.errorBanner = box;
    reveal(box);
  }

  /** @param {any} msg */
  function modelInfo(msg) {
    const turn = turnOf(msg.turnId);
    if (!turn) {
      return;
    }
    const footer = ensureFooter(turn);
    const info = /** @type {HTMLElement} */ (footer.querySelector('.turn__model'));
    info.textContent = msg.text || '';
    setLive(label('responseComplete', 'Response complete'));
    requestRender();
  }

  /** @param {Turn} turn */
  function ensureFooter(turn) {
    if (!turn.footer) {
      const footer = el('footer', 'turn__footer');
      const copy = button('', 'cb-btn turn__copy', 'copy-response', {}, label('copyResponse', 'Copy response'));
      copy.setAttribute('aria-label', label('copyResponse', 'Copy response'));
      copy.innerHTML = CC.markdown.ICONS.copy;
      footer.append(copy, el('span', 'turn__model'));
      turn.el.appendChild(footer);
      turn.footer = footer;
    }
    return turn.footer;
  }

  /** @param {any} msg */
  function compacting(msg) {
    const turn = turnOf(msg.turnId);
    if (!turn) {
      return;
    }
    if (msg.visible) {
      if (!turn.compacting) {
        closeSegment(turn);
        const node = el('div', 'tool tool--running compacting');
        node.append(el('span', 'status-icon status-icon--running'),
          el('div', 'tool__message', msg.label || label('compacting', 'Compacting conversation…')));
        turn.body.appendChild(node);
        turn.compacting = node;
      }
    } else if (turn.compacting) {
      turn.compacting.remove();
      turn.compacting = null;
    }
    afterLayoutChange();
  }

  /** @param {any} msg */
  function setAvatar(msg) {
    if (typeof msg.uri !== 'string' || !msg.uri.startsWith('data:image/')) {
      return;
    }
    state.avatars.set(msg.id, msg.uri);
    for (const img of Array.from(document.querySelectorAll('img[data-avatar]'))) {
      if (/** @type {HTMLElement} */ (img).dataset.avatar === msg.id) {
        /** @type {HTMLImageElement} */ (img).src = msg.uri;
      }
    }
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Scrolling

  function isAtBottom() {
    return scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight <= STICK_THRESHOLD_PX;
  }

  function scrollToBottom() {
    scroller.scrollTop = scroller.scrollHeight;
  }

  /**
   * Reserves space below the latest round so the newest user message can sit at the top of the viewport while the
   * answer is still short (matches the behaviour of the classic chat view).
   */
  function updateSpacer() {
    const turn = state.pinnedTurn;
    if (!turn || !turn.el.isConnected) {
      spacer.style.height = '0px';
      return;
    }
    const contentBottom = conversation.offsetTop + conversation.offsetHeight;
    const roundHeight = contentBottom - turn.el.offsetTop;
    const free = scroller.clientHeight - roundHeight - 16;
    spacer.style.height = Math.max(0, free) + 'px';
  }

  function afterLayoutChange() {
    updateSpacer();
    if (state.stick) {
      scrollToBottom();
    }
    updateScrollButton();
  }

  function updateScrollButton() {
    scrollButton.hidden = state.stick || isAtBottom();
  }

  /**
   * Brings an element into view (confirmations, warnings, errors are always revealed).
   * @param {HTMLElement} node
   */
  function reveal(node) {
    global.requestAnimationFrame(() => {
      updateSpacer();
      if (!node.isConnected) {
        return;
      }
      node.scrollIntoView({ block: 'nearest' });
      state.stick = isAtBottom();
      updateScrollButton();
    });
  }

  /** @param {any} msg */
  function pinTurn(msg) {
    const turn = turnOf(msg.turnId);
    if (!turn) {
      return;
    }
    state.pinnedTurn = turn;
    state.stick = true;
    global.requestAnimationFrame(() => {
      updateSpacer();
      scrollToBottom();
      updateScrollButton();
    });
  }

  function followIfSticky() {
    afterLayoutChange();
  }

  /** @param {string} text */
  function setLive(text) {
    if (liveRegion) {
      liveRegion.textContent = text;
    }
  }

  // ---------------------------------------------------------------------------------------------------------------
  // User interaction (delegated)

  /**
   * Index (1-based) of a code block among the code blocks of its turn, matching the classic view's numbering.
   * @param {Element} block
   */
  function codeBlockIndex(block) {
    const turnRoot = block.closest('.subagent, .turn');
    if (!turnRoot) {
      return 0;
    }
    const blocks = Array.from(turnRoot.querySelectorAll('.code-block, .mermaid-block'))
      .filter((b) => b.closest('.subagent, .turn') === turnRoot);
    return blocks.indexOf(block) + 1;
  }

  /** @param {Element} node */
  function turnIdOf(node) {
    for (const [id, turn] of state.turns) {
      if (turn.el === node.closest('.subagent, .turn')) {
        return id;
      }
    }
    return '';
  }

  /** @param {Element} buttonEl */
  function flashCopied(buttonEl) {
    buttonEl.classList.add('is-done');
    const previous = buttonEl.getAttribute('title') || '';
    buttonEl.setAttribute('title', label('copied', 'Copied'));
    global.setTimeout(() => {
      buttonEl.classList.remove('is-done');
      buttonEl.setAttribute('title', previous);
    }, 1200);
  }

  /** @param {MouseEvent} event */
  function onClick(event) {
    const target = /** @type {Element} */ (event.target);
    if (!target || !target.closest) {
      return;
    }
    const link = target.closest('a');
    if (link) {
      event.preventDefault();
      const href = link.getAttribute('href');
      if (href) {
        bridge.post('openLink', { href });
      }
      return;
    }
    const actionEl = target.closest('[data-action]');
    if (!actionEl) {
      closeMenus(null);
      return;
    }
    const action = actionEl.getAttribute('data-action');
    switch (action) {
      case 'copy': {
        const block = actionEl.closest('.code-block, .mermaid-block');
        if (block) {
          const code = block.classList.contains('mermaid-block')
            ? (block.querySelector('.mermaid-block__source code') || {}).textContent || ''
            : CC.code.sourceOf(block);
          bridge.post('copyCode', { turnId: turnIdOf(block), blockIndex: codeBlockIndex(block), code });
          flashCopied(actionEl);
        }
        break;
      }
      case 'insert': {
        const block = actionEl.closest('.code-block');
        if (block) {
          bridge.post('insertCode', { code: CC.code.sourceOf(block) });
        }
        break;
      }
      case 'expand': {
        const block = actionEl.closest('.code-block');
        if (block) {
          CC.code.toggleExpanded(block);
          afterLayoutChange();
        }
        break;
      }
      case 'mermaid-view': {
        const block = actionEl.closest('.mermaid-block');
        if (block) {
          CC.mermaidView.setView(block, actionEl.getAttribute('data-view') || 'diagram');
        }
        break;
      }
      case 'toggle-thinking':
      case 'toggle-subagent': {
        const root = actionEl.parentElement;
        if (root) {
          setExpanded(root, root.classList.contains('is-collapsed'));
        }
        break;
      }
      case 'copy-response': {
        const turnEl = actionEl.closest('.turn');
        const turn = turnEl && Array.from(state.turns.values()).find((t) => t.el === turnEl);
        if (turn) {
          const text = turn.textParts.map((p) => p.src.trim()).filter(Boolean).join('\n\n');
          bridge.post('copyText', { text });
          flashCopied(actionEl);
        }
        break;
      }
      case 'confirm': {
        const box = actionEl.closest('.confirm');
        if (box && !box.classList.contains('is-pending')) {
          box.classList.add('is-pending');
          for (const b of Array.from(box.querySelectorAll('button'))) {
            /** @type {HTMLButtonElement} */ (b).disabled = true;
          }
          bridge.post('confirm', {
            confirmId: /** @type {HTMLElement} */ (box).dataset.confirmId,
            choice: actionEl.getAttribute('data-choice'),
          });
        }
        break;
      }
      case 'confirm-menu': {
        const menu = actionEl.parentElement && actionEl.parentElement.querySelector('.split-button__menu');
        if (menu) {
          const open = /** @type {HTMLElement} */ (menu).hidden;
          closeMenus(open ? menu : null);
          /** @type {HTMLElement} */ (menu).hidden = !open;
          actionEl.setAttribute('aria-expanded', String(open));
          if (open) {
            const first = menu.querySelector('button');
            if (first) {
              /** @type {HTMLElement} */ (first).focus();
            }
          }
        }
        return;
      }
      case 'invoke': {
        bridge.post('action', { id: actionEl.getAttribute('data-id') });
        break;
      }
      default:
        break;
    }
    closeMenus(null);
  }

  /** @param {Element|null} except */
  function closeMenus(except) {
    for (const menu of Array.from(document.querySelectorAll('.split-button__menu'))) {
      if (menu !== except && !(/** @type {HTMLElement} */ (menu).hidden)) {
        /** @type {HTMLElement} */ (menu).hidden = true;
        const arrow = menu.parentElement && menu.parentElement.querySelector('.split-button__arrow');
        if (arrow) {
          arrow.setAttribute('aria-expanded', 'false');
        }
      }
    }
  }

  /** @param {KeyboardEvent} event */
  function onKeyDown(event) {
    const key = event.key;
    const mod = event.ctrlKey || event.metaKey;
    // The page must never reload or navigate: its content only exists in memory.
    if (key === 'F5' || (mod && (key === 'r' || key === 'R' || key === 'p' || key === 'P'))
      || (event.altKey && (key === 'ArrowLeft' || key === 'ArrowRight')) || key === 'BrowserBack') {
      event.preventDefault();
      return;
    }
    if (key === 'Escape') {
      closeMenus(null);
    }
    if (['PageUp', 'ArrowUp', 'Home'].includes(key)) {
      state.userIntentAt = Date.now();
    }
  }

  function onScroll() {
    if (isAtBottom()) {
      state.stick = true;
    } else if (Date.now() - state.userIntentAt < 600) {
      state.stick = false;
    }
    updateScrollButton();
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Boot

  /** @param {any} msg */
  function init(msg) {
    CC.labels = msg.labels || {};
    CC.features = msg.features || {};
    CC.theme.apply(msg.theme || {});
    scrollButton.setAttribute('aria-label', label('scrollToBottom', 'Scroll to bottom'));
    scrollButton.title = label('scrollToBottom', 'Scroll to bottom');
    conversation.setAttribute('aria-label', label('conversation', 'Chat conversation'));
    document.documentElement.classList.add('is-ready');
  }

  /** @param {any} msg */
  function applyTheme(msg) {
    CC.theme.apply(msg.theme || {});
    CC.mermaidView.refreshAll();
  }

  function start() {
    scroller = /** @type {HTMLElement} */ (document.getElementById('scroller'));
    conversation = /** @type {HTMLElement} */ (document.getElementById('conversation'));
    spacer = /** @type {HTMLElement} */ (document.getElementById('spacer'));
    scrollButton = /** @type {HTMLElement} */ (document.getElementById('scroll-bottom'));
    liveRegion = /** @type {HTMLElement} */ (document.getElementById('live'));

    document.addEventListener('click', onClick);
    document.addEventListener('auxclick', (e) => {
      if (/** @type {Element} */ (e.target).closest && /** @type {Element} */ (e.target).closest('a')) {
        e.preventDefault();
      }
    });
    document.addEventListener('keydown', onKeyDown);
    scroller.addEventListener('scroll', onScroll, { passive: true });
    for (const type of ['wheel', 'touchmove', 'mousedown']) {
      scroller.addEventListener(type, () => {
        state.userIntentAt = Date.now();
      }, { passive: true });
    }
    scrollButton.addEventListener('click', () => {
      state.stick = true;
      scrollToBottom();
      updateScrollButton();
    });
    // Dropped files must not replace the page.
    document.addEventListener('dragover', (e) => e.preventDefault());
    document.addEventListener('drop', (e) => e.preventDefault());
    if (typeof ResizeObserver !== 'undefined') {
      new ResizeObserver(() => afterLayoutChange()).observe(scroller);
    } else {
      global.addEventListener('resize', afterLayoutChange);
    }

    const on = bridge.on;
    on('init', init);
    on('theme', applyTheme);
    on('avatar', setAvatar);
    on('turn.create', createTurn);
    on('md.append', appendText);
    on('md.flush', flushText);
    on('segment.end', (/** @type {any} */ msg) => {
      const turn = turnOf(msg.turnId);
      if (turn) {
        closeSegment(turn);
      }
    });
    on('tool.status', toolStatus);
    on('turn.cancelRunning', cancelRunning);
    on('subagent.state', setSubagentState);
    on('thinking.append', thinkingAppend);
    on('thinking.state', thinkingState);
    on('thinking.restore', thinkingRestore);
    on('confirm.show', showConfirmation);
    on('confirm.close', closeConfirmation);
    on('warn.show', showWarning);
    on('agentMessage.show', showAgentMessage);
    on('modelInfo', modelInfo);
    on('compacting', compacting);
    on('error.show', showError);
    on('scroll.pin', pinTurn);
    on('scroll.follow', followIfSticky);
    CC.afterBatch = requestRender;

    bridge.announce();
  }

  CC.chat = { state, start, label };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})(window);
