// @ts-check
// highlight.js grammars for ABAP (incl. ABAP Objects, ABAP SQL, string templates) and ABAP CDS.
// highlight.js does not ship ABAP, so these grammars are maintained here.
(function (global) {
  'use strict';

  /** @type {any} */
  const hljs = /** @type {any} */ (global).hljs;
  if (!hljs) {
    return;
  }

  const STATEMENT_KEYWORDS = [
    'abstract', 'add', 'add-corresponding', 'adjacent', 'alias', 'aliases', 'all', 'append', 'appending', 'as',
    'ascending', 'assign', 'assigning', 'at', 'authority-check', 'back', 'begin', 'binary', 'block', 'break-point',
    'by', 'bypassing', 'call', 'case', 'catch', 'changing', 'check', 'class', 'class-data', 'class-events',
    'class-methods', 'class-pool', 'clear', 'cleanup', 'close', 'collect', 'commit', 'communication', 'comparing',
    'components', 'compute', 'concatenate', 'condense', 'constants', 'context', 'continue', 'controls', 'convert',
    'create', 'critical', 'currency', 'cursor', 'data', 'database', 'deferred', 'define', 'definition', 'delete',
    'demand', 'describe', 'descending', 'destination', 'detail', 'dialog', 'divide', 'divide-corresponding', 'do',
    'duplicates', 'dynpro', 'else', 'elseif', 'end', 'end-of-definition', 'end-of-page', 'end-of-selection', 'endat',
    'endcase', 'endcatch', 'endclass', 'enddo', 'endexec', 'endform', 'endfunction', 'endif', 'endinterface',
    'endloop', 'endmethod', 'endmodule', 'endon', 'endprovide', 'endselect', 'endtry', 'endwhile', 'endenhancement',
    'endenhancement-section', 'endwith', 'enhancement', 'enhancement-point', 'enhancement-section', 'entries',
    'event', 'events', 'exceptions', 'exec', 'exit', 'export', 'exporting', 'extract', 'fetch', 'field-groups',
    'field-symbol', 'field-symbols', 'fields', 'final', 'find', 'first', 'for', 'form', 'format', 'free', 'friends', 'from',
    'function', 'function-pool', 'generate', 'get', 'global', 'group', 'handle', 'handler', 'hashed', 'header',
    'hide', 'id', 'if', 'implementation', 'implementations', 'import', 'importing', 'in', 'include', 'index',
    'infotypes', 'inheriting', 'initialization', 'insert', 'instances', 'interface', 'interface-pool', 'interfaces',
    'into', 'key', 'kind', 'leave', 'length', 'level', 'line', 'lines', 'load', 'load-of-program', 'local', 'lock',
    'loop', 'message', 'method', 'methods', 'modify', 'module', 'move', 'move-corresponding', 'multiply',
    'multiply-corresponding', 'new-line', 'new-page', 'next', 'no', 'non-unique', 'object', 'objects', 'occurs',
    'of', 'on', 'open', 'optional', 'output', 'overlay', 'pack', 'parameters', 'perform', 'pf-status', 'position',
    'preferred', 'print-control', 'private', 'program', 'protected', 'provide', 'public', 'put', 'raise',
    'raising', 'ranges', 'read', 'read-only', 'receive', 'receiving', 'redefinition', 'reduced', 'ref', 'reference',
    'refresh', 'reject', 'replace', 'report', 'reserve', 'resumable', 'retry', 'return', 'returning', 'rollback',
    'scan', 'scroll', 'search', 'section', 'select', 'select-options', 'selection-screen', 'set', 'shared', 'shift',
    'skip', 'sort', 'sorted', 'split', 'standard', 'start-of-selection', 'starting', 'statics', 'stop', 'structure',
    'submit', 'subtract', 'subtract-corresponding', 'sum', 'summary', 'supply', 'suppress', 'syntax-check', 'table',
    'tables', 'task', 'test', 'testing', 'text', 'then', 'times', 'title', 'titlebar', 'to', 'top-of-page',
    'transaction', 'transfer', 'translate', 'transporting', 'try', 'type', 'type-pool', 'type-pools', 'types',
    'uline', 'unassign', 'unique', 'unpack', 'until', 'up', 'update', 'upon', 'user-command', 'using', 'value',
    'value-request', 'when', 'where', 'while', 'window', 'with', 'with-heading', 'with-title', 'write', 'zero',
    // ABAP SQL
    'distinct', 'single', 'having', 'order', 'inner', 'outer', 'left', 'right', 'cross', 'join', 'union',
    'intersect', 'except', 'rows', 'package', 'size', 'corresponding', 'fields', 'connection', 'client',
    'specified', 'up', 'offset', 'exists', 'escape', 'like', 'between', 'avg', 'count', 'max', 'min',
    'coalesce', 'when', 'end',
    // Constructor expression keywords
    'new', 'let', 'base', 'default', 'deep', 'mapping', 'init',
    // ABAP Unit / RAP
    'for testing', 'risk', 'duration', 'harmless', 'dangerous', 'short', 'medium', 'long', 'entity', 'entities',
    'behavior', 'request', 'response', 'failed', 'reported', 'mapped', 'early', 'late', 'determinations',
    'validations', 'actions',
  ];

  const OPERATOR_KEYWORDS = [
    'and', 'or', 'not', 'equiv', 'eq', 'ne', 'lt', 'gt', 'le', 'ge', 'co', 'cn', 'ca', 'na', 'cs', 'ns', 'cp',
    'np', 'byte-co', 'byte-cn', 'byte-ca', 'byte-na', 'byte-cs', 'byte-ns', 'is', 'initial',
    'bound', 'assigned', 'supplied', 'instance', 'bit-and', 'bit-or', 'bit-xor', 'bit-not', 'div', 'mod',
  ];

  const LITERALS = ['abap_true', 'abap_false', 'abap_undefined', 'space', 'me', 'super', 'null'];

  const BUILT_IN_TYPES = [
    'abap_bool', 'c', 'd', 'decfloat16', 'decfloat34', 'f', 'i', 'int1', 'int2', 'int4', 'int8', 'n', 'p',
    'string', 't', 'utclong', 'x', 'xstring', 'xsdboolean', 'any', 'clike', 'csequence', 'decfloat', 'numeric',
    'simple', 'xsequence',
  ];

  // Names that are also statements (FIND, REPLACE, CONDENSE, INSERT, ...) are listed as keywords only.
  const BUILT_IN_FUNCTIONS = [
    'abs', 'acos', 'asin', 'atan', 'bit-set', 'boolc', 'boolx', 'ceil', 'char_off', 'charlen', 'cmax', 'cmin',
    'concat_lines_of', 'contains', 'contains_any_not_of', 'contains_any_of', 'cos', 'cosh', 'count_any_not_of',
    'count_any_of', 'dbmaxlen', 'distance', 'exp', 'find_any_not_of', 'find_any_of', 'find_end', 'floor', 'frac',
    'from_mixed', 'ipow', 'line_exists', 'line_index', 'log', 'log10', 'match', 'matches', 'nmax', 'nmin',
    'numofchar', 'repeat', 'rescale', 'reverse', 'round', 'segment', 'shift_left', 'shift_right', 'sign', 'sin',
    'sinh', 'sqrt', 'strlen', 'substring', 'substring_after', 'substring_before', 'substring_from', 'substring_to',
    'tan', 'tanh', 'to_lower', 'to_mixed', 'to_upper', 'trunc', 'utclong_add', 'utclong_current', 'utclong_diff',
    'xsdbool', 'xstrlen',
    // Constructor operators
    'cond', 'conv', 'cast', 'exact', 'filter', 'reduce', 'switch',
    // System fields
    'sy-subrc', 'sy-tabix', 'sy-index', 'sy-datum', 'sy-uzeit', 'sy-uname', 'sy-mandt', 'sy-langu', 'sy-dbcnt',
    'sy-sysid', 'sy-msgid', 'sy-msgno', 'sy-msgty', 'sy-msgv1', 'sy-msgv2', 'sy-msgv3', 'sy-msgv4', 'sy-repid',
    'sy-cprog', 'sy-tcode', 'sy-ucomm', 'sy-batch', 'sy-fdpos', 'sy-timlo', 'sy-datlo', 'sy-zonlo',
  ];

  /** Words may contain hyphens (END-OF-SELECTION, sy-subrc) but never end with one. */
  const WORD = /[A-Za-z_](?:[A-Za-z0-9_]|-(?=[A-Za-z0-9_]))*/;

  function abap(hl) {
    const STRING_TEMPLATE = {
      scope: 'string',
      begin: /\|/,
      end: /\|/,
      contains: [
        { scope: 'char.escape', match: /\\[|{}\\nrt]/ },
        {
          scope: 'subst',
          begin: /\{/,
          end: /\}/,
          // Embedded expressions reuse the main grammar (minus templates to keep nesting finite).
          keywords: KEYWORDS,
          contains: [],
        },
      ],
    };
    const KEYWORD_MODES = [
      {
        scope: 'comment',
        begin: /^\*/,
        end: /$/,
        relevance: 0,
      },
      hl.COMMENT(/"/, /$/, { relevance: 0 }),
      {
        scope: 'string',
        begin: /'/,
        end: /'/,
        contains: [{ match: /''/ }],
        relevance: 0,
      },
      {
        scope: 'string',
        begin: /`/,
        end: /`/,
        contains: [{ match: /``/ }],
        relevance: 0,
      },
      STRING_TEMPLATE,
      {
        // Pragmas such as ##NEEDED or ##NO_TEXT
        scope: 'meta',
        match: /##[A-Za-z_]+(?:\[[^\]]*\])*/,
      },
      {
        // Field symbols <fs_name>; also after FIELD-SYMBOL( ... )
        scope: 'variable',
        match: /<[A-Za-z_][\w\/]*>/,
      },
      {
        // ABAP SQL inline declaration: @DATA(lt_result)
        match: [/@/, /(?:data|final)(?=\()/],
        scope: { 2: 'keyword' },
        relevance: 0,
      },
      {
        // ABAP SQL host variables: @lv_value
        scope: 'variable',
        match: /@[A-Za-z_][\w\/~-]*/,
        relevance: 0,
      },
      {
        // Text symbols: TEXT-001
        scope: 'symbol',
        match: /\btext-[A-Za-z0-9]{3}\b/i,
      },
      {
        // Namespaced names such as /UI2/CL_JSON
        scope: 'title.class',
        match: /\/[A-Za-z0-9_]+\/[A-Za-z0-9_]+/,
        relevance: 0,
      },
      {
        // Static method call: zcl_foo=>create( ... )
        match: [/[A-Za-z_\/][\w\/]*/, /=>/, /[A-Za-z_]\w*/, /(?=\()/],
        scope: { 1: 'title.class', 2: 'operator', 3: 'title.function' },
        relevance: 0,
      },
      {
        // Static component or type reference: cl_abap_typedescr=>typekind_char
        match: [/[A-Za-z_\/][\w\/]*/, /=>/],
        scope: { 1: 'title.class', 2: 'operator' },
        relevance: 0,
      },
      {
        // Instance method call: lo_obj->run( ... )
        match: [/->/, /[A-Za-z_]\w*/, /(?=\()/],
        scope: { 1: 'operator', 2: 'title.function' },
        relevance: 0,
      },
      {
        // METHOD name. / METHODS name / CLASS name DEFINITION
        match: [/\b(?:method|methods|class-methods|form|perform|function)\b/, /\s+/, /[A-Za-z_][\w\/~]*/],
        scope: { 1: 'keyword', 3: 'title.function' },
      },
      {
        match: [/\b(?:class|interface)\b/, /\s+/, /[A-Za-z_\/][\w\/]*/],
        scope: { 1: 'keyword', 3: 'title.class' },
      },
      {
        scope: 'number',
        match: /\b\d+\b/,
        relevance: 0,
      },
      {
        scope: 'operator',
        match: /->|=>|\?=|\+=|-=|\*=|\/=|&&|<>|<=|>=|=|<|>|\+|\*\*|\*|\/(?!\w)/,
        relevance: 0,
      },
    ];
    STRING_TEMPLATE.contains[1].contains = KEYWORD_MODES.filter((m) => m !== STRING_TEMPLATE);
    return {
      name: 'ABAP',
      aliases: ['abap4', 'sap-abap'],
      case_insensitive: true,
      keywords: KEYWORDS,
      contains: KEYWORD_MODES,
    };
  }

  const KEYWORDS = {
    $pattern: WORD,
    keyword: [...STATEMENT_KEYWORDS, ...OPERATOR_KEYWORDS].filter((k) => !k.includes(' ')),
    literal: LITERALS,
    type: BUILT_IN_TYPES,
    built_in: BUILT_IN_FUNCTIONS,
  };

  function cds(hl) {
    return {
      name: 'ABAP CDS',
      aliases: ['abap-cds', 'acds', 'ddl', 'cds-ddl', 'ddls'],
      case_insensitive: true,
      keywords: {
        $pattern: /[$A-Za-z_][\w$]*/,
        keyword: [
          'define', 'view', 'entity', 'root', 'as', 'select', 'from', 'where', 'group', 'by', 'having', 'union',
          'all', 'distinct', 'key', 'association', 'composition', 'to', 'of', 'on', 'parent', 'redirected',
          'child', 'inner', 'left', 'right', 'outer', 'join', 'cross', 'case', 'when', 'then', 'else', 'end',
          'cast', 'and', 'or', 'not', 'is', 'null', 'between', 'like', 'escape', 'with', 'parameters',
          'projection', 'provider', 'contract', 'transactional_query', 'transactional_interface', 'extend',
          'abstract', 'custom', 'table', 'function', 'implemented', 'by', 'method', 'returns', 'type', 'virtual',
          'exposes', 'role', 'grant', 'aspect', 'pfcg_auth', 'annotate', 'behavior', 'for', 'implementation',
          'managed', 'unmanaged', 'persistent', 'draft', 'lock', 'master', 'dependent', 'authorization',
          'etag', 'create', 'update', 'delete', 'field', 'readonly', 'mandatory', 'numbering', 'action',
          'determination', 'validation', 'save', 'modify', 'mapping', 'strict', 'use', 'static', 'factory',
          'result', 'internal', 'side', 'effects',
        ],
        literal: ['true', 'false', 'null'],
        built_in: [
          '$projection', '$parameters', '$session', 'abs', 'ceil', 'div', 'division', 'floor', 'mod', 'round',
          'concat', 'concat_with_space', 'instr', 'length', 'lower', 'lpad', 'ltrim', 'replace', 'rpad', 'rtrim', 'substring', 'upper', 'coalesce', 'currency_conversion', 'unit_conversion',
          'dats_add_days', 'dats_add_months', 'dats_days_between', 'dats_is_valid', 'tstmp_current_utctimestamp',
          'tstmp_to_dats', 'tstmp_to_tims', 'count', 'sum', 'avg', 'min', 'max', 'bintohex', 'hextobin',
        ],
      },
      contains: [
        hl.C_LINE_COMMENT_MODE,
        hl.C_BLOCK_COMMENT_MODE,
        hl.COMMENT(/--/, /$/),
        { scope: 'meta', match: /@[A-Za-z_][\w.]*/ },
        { scope: 'string', begin: /'/, end: /'/, contains: [{ match: /''/ }] },
        { scope: 'variable', match: /\b_[A-Za-z]\w*/ },
        { scope: 'number', match: /\b\d+(?:\.\d+)?\b/ },
        { scope: 'type', match: /\babap\.[a-z0-9_]+(?:\(\s*\d+(?:\s*,\s*\d+)?\s*\))?/i },
        { scope: 'punctuation', match: /\[\s*(?:\d+|\*)\s*\.\.\s*(?:\d+|\*)\s*\]/ },
      ],
    };
  }

  hljs.registerLanguage('abap', abap);
  hljs.registerLanguage('cds', cds);
})(window);
