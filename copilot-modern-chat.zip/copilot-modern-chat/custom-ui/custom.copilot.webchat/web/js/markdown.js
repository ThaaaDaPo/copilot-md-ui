// @ts-check
// Markdown -> sanitized HTML for chat messages.
//
// Security model: markdown-it runs with `html: false`, so raw HTML in a message is rendered as text. The generated
// HTML is passed through DOMPurify as a second line of defence, and links are restricted to safe schemes. All
// interactive elements (buttons) are produced by this renderer only; a message cannot create them.
(function (global) {
  'use strict';

  /** @type {any} */
  const CC = (global.CopilotChat = global.CopilotChat || {});
  const { escapeHtml } = CC.util;
  const g = /** @type {any} */ (global);

  const BLOCKED_SCHEMES = /^\s*(javascript|vbscript|data|blob|about|chrome|edge|resource|jar):/i;
  const EXTERNAL_LINK = /^\s*(https?|mailto):/i;
  /** DOMPurify's default URI rule plus file: URLs and Windows drive paths, which Copilot uses for file links. */
  const SAFE_URI = /^(?:(?:https?|mailto|file):|[a-z]:[\\/]|[^a-z]|[a-z+.-]+(?:[^a-z+.\-:]|$))/i;

  const ICONS = {
    copy: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 4V2.5A1.5 1.5 0 0 1 5.5 1h7A1.5 1.5 0 0 1 14 2.5v7a1.5 1.5 0 0 1-1.5 1.5H11v1.5A1.5 1.5 0 0 1 9.5 14h-7A1.5 1.5 0 0 1 1 12.5v-7A1.5 1.5 0 0 1 2.5 4H4Zm1 0h4.5A1.5 1.5 0 0 1 11 5.5V10h1.5a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.5-.5h-7a.5.5 0 0 0-.5.5V4ZM2.5 5a.5.5 0 0 0-.5.5v7a.5.5 0 0 0 .5.5h7a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.5-.5h-7Z"/></svg>',
    insert: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1a.5.5 0 0 1 .5.5v7.79l2.65-2.64a.5.5 0 0 1 .7.7l-3.5 3.5a.5.5 0 0 1-.7 0l-3.5-3.5a.5.5 0 1 1 .7-.7L7.5 9.29V1.5A.5.5 0 0 1 8 1ZM2 13.5a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5Z"/></svg>',
    diagram: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M2 2h5v4H2V2Zm1 1v2h3V3H3Zm6 7h5v4H9v-4Zm1 1v2h3v-2h-3ZM4.5 6v2.5H11V10h1V7.5H5.5V6h-1Z"/></svg>',
    source: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M5.85 4.15a.5.5 0 0 1 0 .7L2.71 8l3.14 3.15a.5.5 0 0 1-.7.7l-3.5-3.5a.5.5 0 0 1 0-.7l3.5-3.5a.5.5 0 0 1 .7 0Zm4.3 0a.5.5 0 0 1 .7 0l3.5 3.5a.5.5 0 0 1 0 .7l-3.5 3.5a.5.5 0 0 1-.7-.7L13.29 8l-3.14-3.15a.5.5 0 0 1 0-.7Z"/></svg>',
  };

  /** @type {any} */
  let md = null;

  function labels() {
    return CC.labels || {};
  }

  function createRenderer() {
    const instance = g.markdownit({
      html: false,
      linkify: true,
      typographer: false,
      breaks: false,
    });
    instance.validateLink = (/** @type {string} */ url) => !BLOCKED_SCHEMES.test(url);
    // Only explicit URLs are linkified: fuzzy detection would turn file names such as README.md or setup.py into
    // web links because .md and .py are top-level domains.
    instance.linkify.set({ fuzzyLink: false, fuzzyEmail: false });

    const rules = instance.renderer.rules;
    rules.table_open = () => '<div class="table-wrap"><table>\n';
    rules.table_close = () => '</table></div>\n';
    rules.fence = renderFence;
    rules.code_block = renderFence;
    rules.image = (/** @type {any[]} */ tokens, /** @type {number} */ idx) => {
      // Remote images are not loaded (privacy, tracking pixels); show them as links instead.
      const token = tokens[idx];
      const src = token.attrGet('src') || '';
      const alt = token.content || src;
      return `<a class="img-link" href="${escapeHtml(src)}">${escapeHtml(alt)}</a>`;
    };
    const defaultLinkOpen = rules.link_open
      || ((/** @type {any} */ tokens, /** @type {number} */ idx, /** @type {any} */ options, /** @type {any} */ env,
        /** @type {any} */ self) => self.renderToken(tokens, idx, options));
    rules.link_open = (/** @type {any[]} */ tokens, /** @type {number} */ idx, /** @type {any} */ options,
      /** @type {any} */ env, /** @type {any} */ self) => {
      const token = tokens[idx];
      const href = token.attrGet('href') || '';
      token.attrSet('title', href);
      if (!EXTERNAL_LINK.test(href) && !href.startsWith('#')) {
        token.attrJoin('class', 'file-link');
      }
      return defaultLinkOpen(tokens, idx, options, env, self);
    };

    instance.use(taskListPlugin);
    instance.use(mathPlugin);
    return instance;
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Code blocks

  /**
   * @param {any[]} tokens
   * @param {number} idx
   * @param {any} _options
   * @param {any} env
   */
  function renderFence(tokens, idx, _options, env) {
    const token = tokens[idx];
    const info = (token.info || '').trim();
    const lang = info.split(/\s+/)[0].toLowerCase();
    const code = token.content;
    const closed = token.type === 'code_block' || isFenceClosed(token, env);
    const l = labels();

    if (lang === 'mermaid' && CC.features && CC.features.mermaid !== false && (closed || env.final)) {
      return (
        '<div class="mermaid-block" data-state="pending">' +
        '<div class="code-block__header">' +
        `<span class="code-block__lang">${escapeHtml(l.mermaid || 'Mermaid')}</span>` +
        '<span class="code-block__actions">' +
        `<button type="button" class="cb-btn" data-action="mermaid-view" data-view="diagram" title="${escapeHtml(l.showDiagram || 'Show diagram')}" aria-label="${escapeHtml(l.showDiagram || 'Show diagram')}" aria-pressed="true">${ICONS.diagram}</button>` +
        `<button type="button" class="cb-btn" data-action="mermaid-view" data-view="source" title="${escapeHtml(l.showSource || 'Show source')}" aria-label="${escapeHtml(l.showSource || 'Show source')}" aria-pressed="false">${ICONS.source}</button>` +
        `<button type="button" class="cb-btn" data-action="copy" title="${escapeHtml(l.copy || 'Copy')}" aria-label="${escapeHtml(l.copyCode || 'Copy code')}">${ICONS.copy}</button>` +
        '</span></div>' +
        `<div class="mermaid-block__diagram" role="img" aria-label="${escapeHtml(l.diagram || 'Diagram')}"><div class="mermaid-block__placeholder">${escapeHtml(l.renderingDiagram || 'Rendering diagram…')}</div></div>` +
        `<pre class="mermaid-block__source"><code class="language-mermaid">${escapeHtml(code)}</code></pre>` +
        '</div>\n'
      );
    }

    const shownLang = lang || (token.type === 'code_block' ? '' : '');
    const streaming = !closed && !env.final;
    return (
      `<div class="code-block${streaming ? ' is-streaming' : ''}" data-lang="${escapeHtml(lang)}">` +
      '<div class="code-block__header">' +
      `<span class="code-block__lang">${escapeHtml(shownLang || l.plainText || 'text')}</span>` +
      '<span class="code-block__actions">' +
      `<button type="button" class="cb-btn" data-action="copy" title="${escapeHtml(l.copy || 'Copy')}" aria-label="${escapeHtml(l.copyCode || 'Copy code')}">${ICONS.copy}</button>` +
      `<button type="button" class="cb-btn" data-action="insert" title="${escapeHtml(l.insert || 'Insert into editor')}" aria-label="${escapeHtml(l.insert || 'Insert into editor')}">${ICONS.insert}</button>` +
      '</span></div>' +
      `<pre><code${lang ? ` class="language-${escapeHtml(lang)}"` : ''}>${escapeHtml(code)}</code></pre>` +
      '</div>\n'
    );
  }

  /**
   * A fence is closed when the line before token.map[1] is a closing fence. While a response is streaming the last
   * fence is usually still open; diagrams are only rendered once the fence is complete.
   * @param {any} token
   * @param {any} env
   */
  function isFenceClosed(token, env) {
    if (!token.map || !env || !env.lines) {
      return true;
    }
    const [start, end] = token.map;
    if (end - 1 <= start) {
      return false;
    }
    const line = (env.lines[end - 1] || '').trim();
    const marker = token.markup || '```';
    return line.startsWith(marker) && line.replace(/[`~]/g, '').trim() === '';
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Task lists: "- [ ] todo" / "- [x] done"

  /** @param {any} instance */
  function taskListPlugin(instance) {
    instance.core.ruler.after('inline', 'task_list', (/** @type {any} */ state) => {
      const tokens = state.tokens;
      for (let i = 2; i < tokens.length; i++) {
        const inline = tokens[i];
        if (inline.type !== 'inline' || tokens[i - 1].type !== 'paragraph_open'
          || tokens[i - 2].type !== 'list_item_open') {
          continue;
        }
        const m = /^\[([ xX])\]\s+/.exec(inline.content);
        const first = inline.children && inline.children[0];
        if (!m || !first || first.type !== 'text' || !first.content.startsWith(m[0].slice(0, 3))) {
          continue;
        }
        first.content = first.content.slice(3).replace(/^\s+/, '');
        const box = new state.Token('html_inline', '', 0);
        const checked = m[1] !== ' ';
        box.content = `<span class="task-box${checked ? ' is-checked' : ''}" role="img" aria-label="${checked ? 'done' : 'open'}"></span>`;
        inline.children.unshift(box);
        tokens[i - 2].attrJoin('class', 'task-item');
      }
    });
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Math: $inline$, \(inline\), $$block$$, \[block\] rendered with KaTeX (trust disabled)

  /** @param {any} instance */
  function mathPlugin(instance) {
    instance.inline.ruler.before('escape', 'math_inline', mathInline);
    instance.block.ruler.before('fence', 'math_block', mathBlock, { alt: ['paragraph', 'reference', 'blockquote', 'list'] });
    instance.renderer.rules.math_inline = (/** @type {any[]} */ tokens, /** @type {number} */ idx) =>
      renderMath(tokens[idx].content, !!(tokens[idx].meta && tokens[idx].meta.display));
    instance.renderer.rules.math_block = (/** @type {any[]} */ tokens, /** @type {number} */ idx) =>
      `<div class="math-block">${renderMath(tokens[idx].content, true)}</div>\n`;
  }

  /**
   * @param {any} state
   * @param {boolean} silent
   */
  function mathInline(state, silent) {
    if (!mathEnabled()) {
      return false;
    }
    const src = state.src;
    const pos = state.pos;
    const max = state.posMax;
    let open;
    let close;
    if (src.charCodeAt(pos) === 0x5c /* \ */ && src.charCodeAt(pos + 1) === 0x28 /* ( */) {
      open = '\\(';
      close = '\\)';
    } else if (src.charCodeAt(pos) === 0x24 /* $ */) {
      if (src.charCodeAt(pos + 1) === 0x24) {
        open = '$$';
        close = '$$';
      } else {
        open = '$';
        close = '$';
      }
    } else {
      return false;
    }

    const start = pos + open.length;
    if (open === '$') {
      const next = src[start];
      const prev = pos > 0 ? src[pos - 1] : '';
      // "$5 and $10", "US$" and "$ x $" are not math.
      if (!next || /\s/.test(next) || /[\w$]/.test(prev)) {
        return false;
      }
    }
    let end = start;
    for (;;) {
      end = src.indexOf(close, end);
      if (end < 0 || end >= max) {
        return false;
      }
      if (src[end - 1] === '\\' && open === '$') {
        end += 1;
        continue;
      }
      if (open === '$') {
        const before = src[end - 1];
        const after = src[end + 1] || '';
        if (/\s/.test(before) || /\d/.test(after)) {
          end += 1;
          continue;
        }
      }
      break;
    }
    const content = src.slice(start, end);
    if (!content.trim() || content.length > 4000 || (open === '$' && content.includes('\n\n'))) {
      return false;
    }
    if (!silent) {
      const token = state.push('math_inline', 'math', 0);
      token.content = content;
      token.markup = open;
      if (open === '$$') {
        token.meta = { display: true };
      }
    }
    state.pos = end + close.length;
    return true;
  }

  /**
   * @param {any} state
   * @param {number} startLine
   * @param {number} endLine
   * @param {boolean} silent
   */
  function mathBlock(state, startLine, endLine, silent) {
    if (!mathEnabled()) {
      return false;
    }
    if (state.sCount[startLine] - state.blkIndent >= 4) {
      return false;
    }
    const firstPos = state.bMarks[startLine] + state.tShift[startLine];
    const firstLine = state.src.slice(firstPos, state.eMarks[startLine]);
    let open;
    let close;
    if (firstLine.startsWith('$$')) {
      open = '$$';
      close = '$$';
    } else if (firstLine.startsWith('\\[')) {
      open = '\\[';
      close = '\\]';
    } else {
      return false;
    }
    let rest = firstLine.slice(open.length);
    /** @type {string[]} */
    const body = [];
    let line = startLine;
    let found = false;
    if (rest.trim().endsWith(close) && rest.trim().length >= close.length) {
      body.push(rest.trim().slice(0, -close.length));
      found = true;
    } else {
      if (rest.trim()) {
        body.push(rest);
      }
      for (line = startLine + 1; line < endLine; line++) {
        const text = state.src.slice(state.bMarks[line] + state.tShift[line], state.eMarks[line]);
        if (text.trim().endsWith(close)) {
          body.push(text.trim().slice(0, -close.length));
          found = true;
          break;
        }
        body.push(state.src.slice(state.bMarks[line], state.eMarks[line]));
      }
    }
    if (!found) {
      return false;
    }
    if (silent) {
      return true;
    }
    const token = state.push('math_block', 'math', 0);
    token.block = true;
    token.content = body.join('\n').trim();
    token.map = [startLine, line + 1];
    token.markup = open;
    state.line = line + 1;
    return true;
  }

  function mathEnabled() {
    return !(CC.features && CC.features.math === false);
  }

  /**
   * @param {string} tex
   * @param {boolean} display
   */
  function renderMath(tex, display) {
    const katex = g.katex;
    if (!katex) {
      return `<code class="math-src">${escapeHtml(tex)}</code>`;
    }
    try {
      return katex.renderToString(tex, {
        displayMode: display,
        throwOnError: false,
        trust: false,
        strict: 'ignore',
        maxSize: 50,
        maxExpand: 500,
        output: 'htmlAndMathml',
      });
    } catch (e) {
      return `<code class="math-src math-error" title="${escapeHtml(String(e))}">${escapeHtml(tex)}</code>`;
    }
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Sanitizing

  let purifyConfigured = false;

  function configurePurify() {
    if (purifyConfigured || !g.DOMPurify) {
      return;
    }
    purifyConfigured = true;
    g.DOMPurify.addHook('afterSanitizeAttributes', (/** @type {Element} */ node) => {
      if (node.tagName === 'A') {
        const href = node.getAttribute('href') || '';
        if (BLOCKED_SCHEMES.test(href)) {
          node.removeAttribute('href');
        }
        node.setAttribute('rel', 'noopener noreferrer');
        node.removeAttribute('target');
      }
    });
  }

  /**
   * @param {string} html
   * @returns {string}
   */
  function sanitize(html) {
    if (!g.DOMPurify) {
      // Without the sanitizer nothing rich is shown.
      return `<pre>${escapeHtml(html.replace(/<[^>]*>/g, ''))}</pre>`;
    }
    configurePurify();
    return g.DOMPurify.sanitize(html, {
      FORBID_TAGS: ['style', 'form', 'iframe', 'object', 'embed', 'link', 'meta', 'base', 'img', 'video', 'audio',
        'source', 'picture', 'input', 'textarea', 'select'],
      FORBID_ATTR: ['srcset', 'action', 'formaction', 'xlink:href', 'ping'],
      ALLOW_UNKNOWN_PROTOCOLS: false,
      ALLOWED_URI_REGEXP: SAFE_URI,
    });
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Public API

  /**
   * Renders a markdown document.
   * @param {string} src
   * @param {{final?: boolean}=} options
   * @returns {string} sanitized HTML
   */
  function render(src, options) {
    if (!md) {
      md = createRenderer();
    }
    const env = { lines: src.split('\n'), final: !!(options && options.final) };
    let html;
    try {
      html = md.render(src, env);
    } catch (e) {
      CC.bridge && CC.bridge.log('error', 'Markdown rendering failed: ' + CC.bridge.describe(e));
      html = `<pre class="md-fallback">${escapeHtml(src)}</pre>`;
    }
    return sanitize(html);
  }

  /**
   * Renders short single-paragraph markdown (status texts) without the wrapping paragraph.
   * @param {string} src
   * @returns {string}
   */
  function renderInline(src) {
    if (!md) {
      md = createRenderer();
    }
    let html;
    try {
      html = md.renderInline(src || '', { lines: [], final: true });
    } catch (e) {
      html = escapeHtml(src);
    }
    return sanitize(html);
  }

  CC.markdown = { render, renderInline, sanitize, isFenceClosed, ICONS };
})(window);
