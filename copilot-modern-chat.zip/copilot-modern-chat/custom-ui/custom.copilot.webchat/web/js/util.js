// @ts-check
// Small, dependency-free helpers shared by the chat UI scripts.
(function (global) {
  'use strict';

  /** @type {any} */
  const CC = (global.CopilotChat = global.CopilotChat || {});

  /**
   * Escapes text for safe insertion into HTML.
   * @param {unknown} value
   * @returns {string}
   */
  function escapeHtml(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  /**
   * FNV-1a hash of a string, used as a cheap cache key (not for security).
   * @param {string} text
   * @returns {string}
   */
  function hash(text) {
    let h = 0x811c9dc5;
    for (let i = 0; i < text.length; i++) {
      h ^= text.charCodeAt(i);
      h = Math.imul(h, 0x01000193);
    }
    return (h >>> 0).toString(36) + ':' + text.length.toString(36);
  }

  /**
   * Creates an element with optional class and text content.
   * @param {string} tag
   * @param {string=} className
   * @param {string=} text
   * @returns {HTMLElement}
   */
  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) {
      node.className = className;
    }
    if (text !== undefined) {
      node.textContent = text;
    }
    return node;
  }

  /**
   * Parses "#rgb", "#rrggbb" or "rgb(r, g, b)" into components.
   * @param {string} color
   * @returns {{r:number,g:number,b:number}|null}
   */
  function parseColor(color) {
    if (typeof color !== 'string') {
      return null;
    }
    const value = color.trim();
    let m = /^#([0-9a-f]{3})$/i.exec(value);
    if (m) {
      const [r, g, b] = m[1].split('').map((c) => parseInt(c + c, 16));
      return { r, g, b };
    }
    m = /^#([0-9a-f]{6})$/i.exec(value);
    if (m) {
      const n = parseInt(m[1], 16);
      return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
    }
    m = /^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i.exec(value);
    if (m) {
      return { r: +m[1], g: +m[2], b: +m[3] };
    }
    return null;
  }

  /**
   * Linear mix of two colors; weight is the share of {@code b}.
   * @param {{r:number,g:number,b:number}} a
   * @param {{r:number,g:number,b:number}} b
   * @param {number} weight 0..1
   * @returns {string}
   */
  function mix(a, b, weight) {
    const w = Math.max(0, Math.min(1, weight));
    const c = (x, y) => Math.round(x + (y - x) * w);
    return `rgb(${c(a.r, b.r)}, ${c(a.g, b.g)}, ${c(a.b, b.b)})`;
  }

  /**
   * Relative luminance (WCAG) of a color.
   * @param {{r:number,g:number,b:number}} c
   * @returns {number}
   */
  function luminance(c) {
    const f = (v) => {
      const s = v / 255;
      return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
    };
    return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b);
  }

  /**
   * Runs {@code task} at most once per animation frame, no matter how often it is requested.
   * @param {() => void} task
   * @returns {() => void} the request function
   */
  function frameCoalescer(task) {
    let scheduled = false;
    const raf = global.requestAnimationFrame || ((cb) => global.setTimeout(cb, 16));
    return () => {
      if (scheduled) {
        return;
      }
      scheduled = true;
      raf(() => {
        scheduled = false;
        task();
      });
    };
  }

  CC.util = { escapeHtml, hash, el, parseColor, mix, luminance, frameCoalescer };
})(window);
