// @ts-check
// Post-processing of rendered code blocks: syntax highlighting, JSON formatting and collapsing of long blocks.
(function (global) {
  'use strict';

  /** @type {any} */
  const CC = (global.CopilotChat = global.CopilotChat || {});
  const g = /** @type {any} */ (global);

  const MAX_HIGHLIGHT_CHARS = 200000;
  const MAX_STREAMING_HIGHLIGHT_CHARS = 40000;
  const COLLAPSE_LINES = 60;

  /** Original source of code blocks whose displayed text was reformatted (copy uses the original). */
  const ORIGINAL = new WeakMap();

  const ALIASES = {
    sh: 'bash', shell: 'bash', zsh: 'bash', console: 'bash', terminal: 'bash', shellsession: 'bash',
    ps: 'powershell', ps1: 'powershell', pwsh: 'powershell', bat: 'dos', cmd: 'dos', batch: 'dos',
    yml: 'yaml', jsonc: 'json', json5: 'json', js: 'javascript', jsx: 'javascript', mjs: 'javascript',
    cjs: 'javascript', ts: 'typescript', tsx: 'typescript', py: 'python', rb: 'ruby', kt: 'kotlin',
    kts: 'kotlin', 'c++': 'cpp', 'c#': 'csharp', cs: 'csharp', html: 'xml', xhtml: 'xml', svg: 'xml',
    xsd: 'xml', xslt: 'xml', wsdl: 'xml', plist: 'xml', pom: 'xml', md: 'markdown', patch: 'diff',
    docker: 'dockerfile', plsql: 'sql', tsql: 'sql', hana: 'sql', hanasql: 'sql', 'abap-sql': 'abap',
    abap_cds: 'cds', proto: 'protobuf', tex: 'latex', toml: 'ini', conf: 'ini', cfg: 'ini', mf: 'properties',
    manifest: 'properties', text: 'plaintext', txt: 'plaintext', plain: 'plaintext', log: 'plaintext',
  };

  /**
   * @param {string} lang
   * @returns {string|null}
   */
  function resolveLanguage(lang) {
    const hljs = g.hljs;
    if (!hljs || !lang) {
      return null;
    }
    const key = lang.toLowerCase();
    if (hljs.getLanguage(key)) {
      return key;
    }
    const alias = /** @type {Record<string,string>} */ (ALIASES)[key];
    if (alias && hljs.getLanguage(alias)) {
      return alias;
    }
    return null;
  }

  /**
   * @param {Element} block
   * @param {boolean} final
   */
  function enhanceCodeBlock(block, final) {
    const code = block.querySelector('pre > code');
    if (!code) {
      return;
    }
    const lang = (block.getAttribute('data-lang') || '').toLowerCase();
    let text = code.textContent || '';

    if (final && (lang === 'json' || lang === 'jsonc') && text.length > 120 && !text.includes('\n')) {
      try {
        const pretty = JSON.stringify(JSON.parse(text), null, 2);
        ORIGINAL.set(block, text);
        code.textContent = pretty;
        text = pretty;
      } catch (e) {
        // Not strict JSON; show as is.
      }
    }

    const language = resolveLanguage(lang);
    const limit = final ? MAX_HIGHLIGHT_CHARS : MAX_STREAMING_HIGHLIGHT_CHARS;
    if (language && language !== 'plaintext' && text.length <= limit) {
      try {
        code.innerHTML = g.hljs.highlight(text, { language, ignoreIllegals: true }).value;
        code.classList.add('hljs');
      } catch (e) {
        CC.bridge.log('warn', 'Highlighting failed for ' + lang + ': ' + CC.bridge.describe(e));
      }
    }

    if (final) {
      block.setAttribute('data-finalized', '');
      const lines = text.split('\n').length;
      if (lines > COLLAPSE_LINES && !block.querySelector('.code-block__expander')) {
        block.classList.add('is-collapsible', 'is-collapsed');
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'code-block__expander';
        button.setAttribute('data-action', 'expand');
        button.setAttribute('aria-expanded', 'false');
        button.dataset.lines = String(lines);
        button.textContent = CC.label('showAllLines', 'Show all {0} lines').replace('{0}', String(lines));
        block.appendChild(button);
      }
    }
  }

  /**
   * Post-processes freshly inserted message blocks.
   * @param {Element[]} nodes
   * @param {{final: boolean}} context
   */
  function enhance(nodes, context) {
    for (const node of nodes) {
      const blocks = node.matches('.code-block') ? [node] : Array.from(node.querySelectorAll('.code-block'));
      for (const block of blocks) {
        try {
          enhanceCodeBlock(block, context.final);
        } catch (e) {
          CC.bridge.log('error', 'Code block enhancement failed: ' + CC.bridge.describe(e));
        }
      }
      const diagrams = node.matches('.mermaid-block') ? [node] : Array.from(node.querySelectorAll('.mermaid-block'));
      for (const diagram of diagrams) {
        CC.mermaidView.enqueue(diagram);
      }
    }
  }

  /**
   * Applies the final-only enhancements (JSON formatting, collapsing, full highlighting) to blocks that were first
   * rendered while the message was still streaming and did not change afterwards.
   * @param {Element} container
   */
  function finalize(container) {
    for (const block of Array.from(container.querySelectorAll('.code-block:not([data-finalized])'))) {
      try {
        enhanceCodeBlock(block, true);
      } catch (e) {
        CC.bridge.log('error', 'Code block finalization failed: ' + CC.bridge.describe(e));
      }
    }
  }

  /**
   * Returns the source of a code block as written by Copilot.
   * @param {Element} block
   */
  function sourceOf(block) {
    if (ORIGINAL.has(block)) {
      return ORIGINAL.get(block);
    }
    const code = block.querySelector('pre > code');
    return code ? code.textContent || '' : '';
  }

  /**
   * @param {Element} block
   */
  function toggleExpanded(block) {
    const button = block.querySelector('.code-block__expander');
    const collapsed = block.classList.toggle('is-collapsed');
    if (button) {
      button.setAttribute('aria-expanded', String(!collapsed));
      button.textContent = collapsed
        ? CC.label('showAllLines', 'Show all {0} lines').replace('{0}', button.getAttribute('data-lines') || '')
        : CC.label('showLess', 'Show less');
    }
  }

  CC.code = { enhance, finalize, sourceOf, toggleExpanded, resolveLanguage };
})(window);
