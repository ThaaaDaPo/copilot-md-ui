package custom.copilot.webchat.viewer;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;

import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;

import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import com.microsoft.copilot.eclipse.core.AuthStatusManager;
import com.microsoft.copilot.eclipse.core.lsp.protocol.quota.CheckQuotaResult;
import com.microsoft.copilot.eclipse.core.persistence.ConversationPersistenceManager;
import com.microsoft.copilot.eclipse.ui.CopilotUi;
import com.microsoft.copilot.eclipse.ui.chat.services.AvatarService;
import com.microsoft.copilot.eclipse.ui.chat.services.ChatFontService;
import com.microsoft.copilot.eclipse.ui.chat.services.ChatServiceManager;

/**
 * SWT and service fixture for tests of the web-backed turn widgets. Same approach as the tests of the classic
 * widgets: services are mocks and {@link CopilotUi#getPlugin()} is stubbed on the UI thread.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
abstract class WebWidgetTestSupport {

  protected Shell shell;
  protected Image avatar;
  protected RecordingSurface surface;

  @Mock
  protected ChatServiceManager serviceManager;
  @Mock
  protected AvatarService avatarService;
  @Mock
  protected ChatFontService fontService;
  @Mock
  protected AuthStatusManager authStatusManager;
  @Mock
  protected ConversationPersistenceManager persistenceManager;

  private MockedStatic<CopilotUi> copilotUiMock;

  @BeforeEach
  void setUpWidgets() {
    lenient().when(serviceManager.getAvatarService()).thenReturn(avatarService);
    lenient().when(serviceManager.getChatFontService()).thenReturn(fontService);
    lenient().when(serviceManager.getAuthStatusManager()).thenReturn(authStatusManager);
    lenient().when(serviceManager.getPersistenceManager()).thenReturn(persistenceManager);
    lenient().when(authStatusManager.getUserName()).thenReturn("octocat");
    lenient().when(authStatusManager.getQuotaStatus()).thenReturn(quota(true));
    surface = new RecordingSurface(serviceManager);
    onUi(() -> {
      shell = new Shell(Display.getDefault());
      avatar = new Image(shell.getDisplay(), 8, 8);
      lenient().when(avatarService.getAvatarForCopilot()).thenReturn(avatar);
      lenient().when(avatarService.getAvatarForCurrentUser(any())).thenReturn(avatar);
      copilotUiMock = mockStatic(CopilotUi.class);
      CopilotUi plugin = mock(CopilotUi.class);
      copilotUiMock.when(CopilotUi::getPlugin).thenReturn(plugin);
      lenient().when(plugin.getChatServiceManager()).thenReturn(serviceManager);
    });
  }

  @AfterEach
  void tearDownWidgets() {
    onUi(() -> {
      if (copilotUiMock != null) {
        copilotUiMock.close();
      }
      if (shell != null && !shell.isDisposed()) {
        shell.dispose();
      }
      if (avatar != null) {
        avatar.dispose();
      }
    });
  }

  static CheckQuotaResult quota(boolean tokenBasedBilling) {
    return new CheckQuotaResult(null, null, null, null, null, null, tokenBasedBilling, null);
  }

  static void onUi(Runnable runnable) {
    AtomicReference<Throwable> failure = new AtomicReference<>();
    Display.getDefault().syncExec(() -> {
      try {
        runnable.run();
      } catch (Throwable t) {
        failure.set(t);
      }
    });
    if (failure.get() instanceof RuntimeException e) {
      throw e;
    }
    if (failure.get() instanceof Error e) {
      throw e;
    }
  }

  static <T> T onUi(Supplier<T> supplier) {
    AtomicReference<T> result = new AtomicReference<>();
    onUi(() -> result.set(supplier.get()));
    return result.get();
  }

  WebCopilotTurnWidget copilotTurn(String turnId) {
    return onUi(() -> new WebCopilotTurnWidget(shell, surface, turnId));
  }
}
