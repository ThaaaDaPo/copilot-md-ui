package custom.copilot.webchat.actions;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class LinkOpenerTest {

  @ParameterizedTest
  @CsvSource({
      "https://github.com, WEB",
      "HTTP://example.com/a?b=c, WEB",
      "mailto:someone@example.com, WEB",
      "file:///home/user/Foo.java, FILE",
      "src/main/Foo.java, FILE",
      "/Project/src/Foo.java#L10, FILE",
      "C:/work/Foo.java, FILE",
      "javascript:alert(1), BLOCKED",
      " JavaScript:alert(1), BLOCKED",
      "vbscript:msgbox, BLOCKED",
      "'data:text/html;base64,PHNjcmlwdD4=', BLOCKED",
      "jar:file:/x.jar!/a, BLOCKED",
  })
  void classifiesLinks(String href, LinkOpener.Kind expected) {
    assertEquals(expected, LinkOpener.classify(href));
  }

  @ParameterizedTest
  @CsvSource({
      "file:///a/Foo.java#L12, 11",
      "Foo.java#L1-L20, 0",
      "Foo.java#L7-9, 6",
      "Foo.java, -1",
      "Foo.java#section, -1",
  })
  void extractsTheLineOfALinkFragment(String href, int expectedLine) {
    assertEquals(expectedLine, LinkOpener.lineOf(href));
  }
}
