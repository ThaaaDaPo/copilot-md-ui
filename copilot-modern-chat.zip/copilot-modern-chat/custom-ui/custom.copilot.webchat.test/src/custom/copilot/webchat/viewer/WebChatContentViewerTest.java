package custom.copilot.webchat.viewer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;

import org.eclipse.lsp4j.WorkDoneProgressKind;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.microsoft.copilot.eclipse.core.chat.ConfirmationAction;
import com.microsoft.copilot.eclipse.core.chat.ConfirmationContent;
import com.microsoft.copilot.eclipse.core.lsp.protocol.ChatProgressValue;
import com.microsoft.copilot.eclipse.core.lsp.protocol.LanguageModelToolConfirmationResult;
import com.microsoft.copilot.eclipse.core.lsp.protocol.LanguageModelToolConfirmationResult.ToolConfirmationResult;
import com.microsoft.copilot.eclipse.ui.chat.BaseTurnWidget;

import custom.copilot.webchat.WebChatContentViewerProvider;

/**
 * End-to-end test with the platform's real browser engine: events go through the unchanged event processing of
 * {@code ChatContentViewer}, the web turn widgets, the bridge and the page; assertions read the resulting DOM.
 */
class WebChatContentViewerTest extends WebWidgetTestSupport {

  private static final String ANSWER = """
      ## Result

      | Carrier | Distance |
      |---------|---------:|
      | LH      | 6,162    |

      ```abap
      DATA(lv_text) = |Hello { iv_name }|.
      IF sy-subrc <> 0.
      ENDIF.
      ```

      ```mermaid
      flowchart LR
        A --> B
      ```

      ```mermaid
      this is not a diagram ((((
      ```

      Raw <img src=x onerror="window.__xss=1"> stays text.
      """;

  private WebChatContentViewer viewer;

  @BeforeEach
  void openViewer() {
    String url = WebChatContentViewerProvider.pageUrl();
    assertNotNull(url, "web/index.html must be packaged");
    onUi(() -> {
      shell.setLayout(new FillLayout());
      shell.setSize(800, 900);
      viewer = new WebChatContentViewer(shell, SWT.NONE, serviceManager, url);
      shell.open();
    });
    waitUntil(() -> onUi(() -> viewer.bridge().isReady()), 30, "page ready");
  }

  private Object js(String script) {
    return onUi(() -> viewer.browser().evaluate(script));
  }

  private int count(String selector) {
    Object value = js("return document.querySelectorAll('" + selector + "').length;");
    return value instanceof Number n ? n.intValue() : -1;
  }

  private static void waitUntil(BooleanSupplier condition, int seconds, String what) {
    long end = System.nanoTime() + TimeUnit.SECONDS.toNanos(seconds);
    while (System.nanoTime() < end) {
      if (condition.getAsBoolean()) {
        return;
      }
      try {
        Thread.sleep(50);
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
        return;
      }
    }
    fail("Timed out waiting for " + what);
  }

  private static ChatProgressValue progress(WorkDoneProgressKind kind, String turnId, String reply) {
    ChatProgressValue value = new ChatProgressValue();
    value.setKind(kind);
    value.setTurnId(turnId);
    value.setConversationId("conv-1");
    value.setReply(reply);
    return value;
  }

  /** Same calls as ChatView/ChatContentViewer make for a streamed answer. */
  private void streamAnswer(String text) {
    onUi(() -> {
      viewer.startNewTurn("token-1", "Explain the flight cache");
      viewer.getLatestOrCreateNewTurnWidget("turn-1", true, false);
    });
    int chunk = 37;
    for (int i = 0; i < text.length(); i += chunk) {
      viewer.processTurnEvent(progress(WorkDoneProgressKind.report, "turn-1", text.substring(i,
          Math.min(text.length(), i + chunk))));
    }
    viewer.processTurnEvent(progress(WorkDoneProgressKind.end, "turn-1", null));
  }

  @Test
  void streamedAnswerIsRenderedWithTablesCodeAndDiagrams() {
    streamAnswer(ANSWER);

    waitUntil(() -> count(".turn") == 2 && count(".md table") == 1, 20, "answer rendered");
    assertEquals("Explain the flight cache", js("return document.querySelector('.user-text').textContent;"));
    assertEquals("LH", js("return document.querySelector('.md td').textContent.trim();"));
    waitUntil(() -> count(".code-block[data-lang=\"abap\"] .hljs-keyword") > 0, 10, "ABAP highlighting");

    // One valid and one broken diagram: the valid one renders, the broken one shows an error, the rest stays intact.
    js("document.getElementById('scroller').scrollTop = 1e9; return 0;");
    try {
      waitUntil(() -> count(".mermaid-block[data-state=\"rendered\"] .mermaid-block__diagram > svg") == 1
          && count(".mermaid-block[data-state=\"error\"]") == 1, 30, "diagrams");
    } catch (AssertionError e) {
      fail("Diagrams not rendered: " + js("return JSON.stringify(Array.from(document.querySelectorAll("
          + "'.mermaid-block')).map(function(b){return b.getAttribute('data-state') + ':' + "
          + "b.querySelector('.mermaid-block__diagram').textContent.slice(0, 300);})) + ' mermaid=' + "
          + "typeof window.mermaid + ' io=' + typeof IntersectionObserver;"));
    }
    assertTrue(((String) js("return document.querySelector('.turn--copilot .md').textContent;"))
        .contains("stays text"));

    // Raw HTML from the model is shown as text and never executed.
    assertEquals(Boolean.TRUE, js("return typeof window.__xss === 'undefined';"));
    assertEquals(0, count(".md img"));
  }

  @Test
  void aClickInThePageAnswersTheToolConfirmation() throws Exception {
    streamAnswer("Running the tests.");
    waitUntil(() -> count(".turn") == 2, 20, "turns");
    BaseTurnWidget turn = onUi(() -> viewer.getTurnWidget("turn-1"));
    ConfirmationContent content = new ConfirmationContent("Run command?", null, List.of(
        ConfirmationAction.allowOnce("Allow"), ConfirmationAction.skip("Skip")));
    CompletableFuture<LanguageModelToolConfirmationResult> future = onUi(
        () -> turn.requestToolExecutionConfirmation(content, java.util.Map.of("command", "mvn test")));

    waitUntil(() -> count(".confirm .btn--primary") == 1, 10, "confirmation");
    assertEquals("mvn test", js("return document.querySelector('.confirm__command').textContent;"));
    js("document.querySelector('.confirm .btn--primary').click(); return 0;");

    assertEquals(ToolConfirmationResult.ACCEPT.toString(), future.get(10, TimeUnit.SECONDS).getResult());
    waitUntil(() -> count(".confirm") == 0, 10, "confirmation closed");
    assertTrue(onUi(() -> turn.getConfirmDialog().getSelectedAction().isAccept()));
  }

  @Test
  void errorsAreShownWithoutBreakingTheConversation() {
    streamAnswer("Partial answer");
    onUi(() -> viewer.renderErrorMessage("Request failed: connection reset"));
    waitUntil(() -> count(".notice--error") == 1, 10, "error banner");
    assertEquals(2, count(".turn"));
    assertTrue(((String) js("return document.querySelector('.notice--error').textContent;"))
        .contains("connection reset"));
  }

  @Test
  void aReloadedPageIsRestoredFromTheReplayLog() {
    streamAnswer("Answer that must survive a reload");
    waitUntil(() -> count(".turn") == 2, 20, "turns");
    onUi(() -> viewer.browser().execute("location.reload();"));
    // Navigation guard: a reload of the chat page itself is allowed only before the first load completed.
    waitUntil(() -> js("return document.body ? document.body.textContent : '';") instanceof String text
        && text.contains("must survive") && count(".turn") == 2, 20, "content after reload attempt");
  }
}
