package custom.copilot.webchat.viewer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.stream.Collectors;

import com.google.gson.JsonObject;
import org.eclipse.swt.graphics.Image;

import com.microsoft.copilot.eclipse.ui.chat.BaseTurnWidget;
import com.microsoft.copilot.eclipse.ui.chat.services.ChatServiceManager;

/**
 * A {@link ChatSurface} that records the protocol messages instead of sending them to a page.
 */
class RecordingSurface implements ChatSurface {

  final List<JsonObject> messages = new ArrayList<>();
  final Map<String, Runnable> actions = new HashMap<>();
  final Map<String, WebToolConfirmationDialog> confirmations = new HashMap<>();
  final Map<String, BaseTurnWidget> turns = new HashMap<>();
  final List<String> errors = new ArrayList<>();
  private final ChatServiceManager serviceManager;
  private int ids;

  RecordingSurface(ChatServiceManager serviceManager) {
    this.serviceManager = serviceManager;
  }

  @Override
  public synchronized void post(String type, JsonObject fields) {
    fields.addProperty("type", type);
    messages.add(fields);
  }

  @Override
  public String registerTurn(BaseTurnWidget widget) {
    String id = "t" + ++ids;
    turns.put(id, widget);
    return id;
  }

  @Override
  public String registerAction(Runnable action) {
    String id = "action" + ++ids;
    actions.put(id, action);
    return id;
  }

  @Override
  public String registerConfirmation(WebToolConfirmationDialog dialog) {
    String id = "confirm" + ++ids;
    confirmations.put(id, dialog);
    return id;
  }

  @Override
  public void unregisterConfirmation(String confirmationId) {
    confirmations.remove(confirmationId);
  }

  @Override
  public String avatarId(Image image) {
    return image == null ? null : "avatar";
  }

  @Override
  public ChatServiceManager serviceManager() {
    return serviceManager;
  }

  @Override
  public Executor uiExecutor() {
    return Runnable::run;
  }

  @Override
  public void logError(String message, Throwable cause) {
    errors.add(message);
  }

  /** Messages of the given type, in order. */
  synchronized List<JsonObject> ofType(String type) {
    return messages.stream().filter(m -> type.equals(m.get("type").getAsString())).collect(Collectors.toList());
  }

  /** Types of all messages, in order. */
  synchronized List<String> types() {
    return messages.stream().map(m -> m.get("type").getAsString()).collect(Collectors.toList());
  }

  synchronized void clear() {
    messages.clear();
  }
}
