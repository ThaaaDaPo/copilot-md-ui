package custom.copilot.webchat.bridge;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ChatBridgeTest {

  private final List<String> scripts = new ArrayList<>();
  private final List<Runnable> uiQueue = new ArrayList<>();
  private final List<String> errors = new ArrayList<>();
  private ChatBridge bridge;

  @BeforeEach
  void setUp() {
    bridge = new ChatBridge(script -> scripts.add(script), uiQueue::add, () -> {
      JsonObject init = new JsonObject();
      init.addProperty("marker", "init");
      return init;
    }, (message, cause) -> errors.add(message));
  }

  private void runUi() {
    while (!uiQueue.isEmpty()) {
      uiQueue.remove(0).run();
    }
  }

  private void ready(String instanceId) {
    bridge.receive("{\"type\":\"ready\",\"payload\":{\"instanceId\":\"" + instanceId + "\",\"protocol\":1}}");
  }

  /** All messages delivered to the page, in order. */
  private List<JsonObject> delivered() {
    List<JsonObject> messages = new ArrayList<>();
    for (String script : scripts) {
      String json = script.substring(script.indexOf("receive(") + "receive(".length(), script.lastIndexOf(')'));
      JsonArray batch = JsonParser.parseString(json).getAsJsonArray();
      batch.forEach(e -> messages.add(e.getAsJsonObject()));
    }
    return messages;
  }

  private static JsonObject text(String turnId, String text) {
    JsonObject msg = new JsonObject();
    msg.addProperty("turnId", turnId);
    msg.addProperty("text", text);
    return msg;
  }

  @Test
  void messagesAreHeldBackUntilThePageIsReady() {
    bridge.post(Protocol.OUT_TURN_CREATE, text("t1", null));
    runUi();
    assertTrue(scripts.isEmpty());

    ready("page-1");

    List<JsonObject> messages = delivered();
    assertEquals(2, messages.size());
    assertEquals(Protocol.OUT_INIT, messages.get(0).get("type").getAsString());
    assertEquals(Protocol.VERSION, messages.get(0).get("protocol").getAsInt());
    assertEquals(Protocol.OUT_TURN_CREATE, messages.get(1).get("type").getAsString());
  }

  @Test
  void streamingDeltasOfTheSameTurnAreMergedIntoOneMessage() {
    ready("page-1");
    scripts.clear();
    bridge.post(Protocol.OUT_MD_APPEND, text("t1", "Hello"));
    bridge.post(Protocol.OUT_MD_APPEND, text("t1", ", "));
    bridge.post(Protocol.OUT_MD_APPEND, text("t1", "world"));
    bridge.post(Protocol.OUT_MD_APPEND, text("t2", "other turn"));
    runUi();

    List<JsonObject> messages = delivered();
    assertEquals(1, scripts.size(), "one script per UI cycle");
    assertEquals(2, messages.size());
    assertEquals("Hello, world", messages.get(0).get("text").getAsString());
    assertEquals("other turn", messages.get(1).get("text").getAsString());
  }

  @Test
  void alreadyDeliveredMessagesAreNotModifiedByLaterDeltas() {
    ready("page-1");
    bridge.post(Protocol.OUT_MD_APPEND, text("t1", "a"));
    runUi();
    bridge.post(Protocol.OUT_MD_APPEND, text("t1", "b"));
    runUi();

    List<JsonObject> messages = delivered();
    assertEquals("a", messages.get(1).get("text").getAsString());
    assertEquals("b", messages.get(2).get("text").getAsString());
  }

  @Test
  void aReloadedPageReceivesTheWholeConversationAgain() {
    ready("page-1");
    bridge.post(Protocol.OUT_MD_APPEND, text("t1", "a"));
    runUi();
    scripts.clear();

    ready("page-1");
    assertTrue(scripts.isEmpty(), "duplicate ready of the same page is ignored");

    bridge.pageLoading();
    ready("page-2");
    List<JsonObject> messages = delivered();
    assertEquals(Protocol.OUT_INIT, messages.get(0).get("type").getAsString());
    assertEquals("a", messages.get(1).get("text").getAsString());
  }

  @Test
  void largeReplaysAreSplitIntoSeveralScripts() {
    String chunk = "x".repeat(100_000);
    for (int i = 0; i < 12; i++) {
      bridge.post(Protocol.OUT_TOOL_STATUS, text("t" + i, chunk));
    }
    ready("page-1");
    assertTrue(scripts.size() > 2);
    assertEquals(13, delivered().size());
    for (String script : scripts) {
      assertTrue(script.length() < ChatBridge.MAX_BATCH_CHARS + 200_000);
    }
  }

  @Test
  void scriptsAreSafeJavaScriptLiterals() {
    ready("page-1");
    scripts.clear();
    bridge.post(Protocol.OUT_MD_APPEND, text("t1", "</script><script>alert(1)</script>  '\""));
    runUi();
    String script = scripts.get(0);
    assertFalse(script.contains("</script>"));
    assertFalse(script.contains(" "));
    assertFalse(script.contains(" "));
    assertEquals("</script><script>alert(1)</script>  '\"",
        delivered().get(0).get("text").getAsString());
  }

  @Test
  void inboundMessagesAreDispatchedToTheirHandler() {
    List<JsonObject> received = new ArrayList<>();
    bridge.on(Protocol.IN_OPEN_LINK, received::add);
    bridge.receive("{\"type\":\"openLink\",\"payload\":{\"href\":\"https://example.com\"}}");
    assertEquals(1, received.size());
    assertEquals("https://example.com", ChatBridge.stringOf(received.get(0), "href"));
  }

  @Test
  void invalidInboundMessagesAreRejected() {
    List<JsonObject> received = new ArrayList<>();
    bridge.on(Protocol.IN_ACTION, received::add);

    bridge.receive("{\"type\":\"runCommand\",\"payload\":{}}");
    bridge.receive("not json");
    bridge.receive("[1,2,3]");
    bridge.receive(42.0);
    bridge.receive(null);
    bridge.receive("{\"type\":\"action\",\"payload\":{\"id\":\"" + "x".repeat(ChatBridge.MAX_INBOUND_CHARS) + "\"}}");

    assertTrue(received.isEmpty());
    assertEquals(6, errors.size());
  }

  @Test
  void aFailingHandlerDoesNotBreakTheBridge() {
    List<JsonObject> received = new ArrayList<>();
    bridge.on(Protocol.IN_ACTION, payload -> {
      throw new IllegalStateException("boom");
    });
    bridge.on(Protocol.IN_OPEN_LINK, received::add);

    bridge.receive("{\"type\":\"action\",\"payload\":{\"id\":\"a\"}}");
    bridge.receive("{\"type\":\"openLink\",\"payload\":{\"href\":\"x\"}}");

    assertEquals(1, errors.size());
    assertEquals(1, received.size());
  }

  @Test
  void handlersCanOnlyBeRegisteredForKnownTypes() {
    assertThrows(IllegalArgumentException.class, () -> bridge.on("eval", payload -> { }));
    assertThrows(IllegalArgumentException.class, () -> bridge.on(Protocol.IN_READY, payload -> { }));
  }

  @Test
  void boundedStringRejectsMissingWrongTypeAndTooLongValues() {
    JsonObject payload = JsonParser.parseString("{\"a\":\"abc\",\"n\":1,\"o\":{}}").getAsJsonObject();
    assertEquals("abc", ChatBridge.boundedString(payload, "a", 3));
    assertNull(ChatBridge.boundedString(payload, "a", 2));
    assertNull(ChatBridge.boundedString(payload, "n", 10));
    assertNull(ChatBridge.boundedString(payload, "o", 10));
    assertNull(ChatBridge.boundedString(payload, "missing", 10));
  }

  @Test
  void nothingIsSentAfterDispose() {
    ready("page-1");
    scripts.clear();
    bridge.dispose();
    bridge.post(Protocol.OUT_MD_APPEND, text("t1", "late"));
    runUi();
    assertTrue(scripts.isEmpty());
    assertEquals(0, bridge.logSize());
  }
}
