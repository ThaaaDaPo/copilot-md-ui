package custom.copilot.webchat.viewer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import com.microsoft.copilot.eclipse.core.chat.ConfirmationAction;
import com.microsoft.copilot.eclipse.core.chat.ConfirmationActionScope;
import com.microsoft.copilot.eclipse.core.chat.ConfirmationContent;
import com.microsoft.copilot.eclipse.core.lsp.CopilotLanguageServerConnection;
import com.microsoft.copilot.eclipse.core.lsp.protocol.AgentToolCall;
import com.microsoft.copilot.eclipse.core.lsp.protocol.GenerateThinkingTitleResponse;
import com.microsoft.copilot.eclipse.core.lsp.protocol.LanguageModelToolConfirmationResult;
import com.microsoft.copilot.eclipse.core.lsp.protocol.LanguageModelToolConfirmationResult.ToolConfirmationResult;
import com.microsoft.copilot.eclipse.core.lsp.protocol.Thinking;
import com.microsoft.copilot.eclipse.core.lsp.protocol.codingagent.CodingAgentMessageRequestParams;
import com.microsoft.copilot.eclipse.core.lsp.protocol.quota.CheckQuotaResult;
import com.microsoft.copilot.eclipse.core.lsp.protocol.quota.CopilotPlan;
import com.microsoft.copilot.eclipse.core.lsp.protocol.quota.Quota;
import com.microsoft.copilot.eclipse.core.persistence.CopilotTurnData;
import com.microsoft.copilot.eclipse.core.persistence.CopilotTurnData.ReplyData;
import com.microsoft.copilot.eclipse.core.persistence.CopilotTurnData.ThinkingBlockData;
import com.microsoft.copilot.eclipse.ui.chat.ThinkingTurnWidget;

import custom.copilot.webchat.bridge.Protocol;

class WebTurnWidgetTest extends WebWidgetTestSupport {

  private static final Gson GSON = new Gson();

  @AfterEach
  void restoreLanguageServer() {
    ThinkingPresenter.languageServerSupplier = () -> null;
  }

  static AgentToolCall toolCall(String id, String name, String status, String progressMessage, String error) {
    JsonObject json = new JsonObject();
    json.addProperty("id", id);
    json.addProperty("name", name);
    json.addProperty("status", status);
    if (progressMessage != null) {
      json.addProperty("progressMessage", progressMessage);
    }
    if (error != null) {
      json.addProperty("error", error);
    }
    return GSON.fromJson(json, AgentToolCall.class);
  }

  private static String str(JsonObject message, String key) {
    return message.has(key) && !message.get(key).isJsonNull() ? message.get(key).getAsString() : null;
  }

  private static ConfirmationContent terminalConfirmation() {
    return new ConfirmationContent("Run command?", "Copilot wants to run a command", List.of(
        ConfirmationAction.allowOnce("Allow"),
        new ConfirmationAction("Allow in this Session", true, ConfirmationActionScope.SESSION, null, false),
        new ConfirmationAction("Always Allow", true, ConfirmationActionScope.GLOBAL, null, false),
        ConfirmationAction.skip("Skip")));
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Text and turn creation

  @Test
  void turnsAreAnnouncedWithRoleNameAndAvatar() {
    WebCopilotTurnWidget copilot = copilotTurn("turn-1");
    WebUserTurnWidget user = onUi(() -> new WebUserTurnWidget(shell, surface, "user-1"));

    List<JsonObject> created = surface.ofType(Protocol.OUT_TURN_CREATE);
    assertEquals(2, created.size());
    assertEquals("copilot", str(created.get(0), "role"));
    assertEquals("avatar", str(created.get(0), "avatarId"));
    assertEquals("user", str(created.get(1), "role"));
    assertEquals("octocat", str(created.get(1), "name"));
    assertEquals(copilot.presenter().domId(), str(created.get(0), "turnId"));
    assertEquals(user.presenter().domId(), str(created.get(1), "turnId"));
  }

  @Test
  void textIsStreamedAndFlushed() {
    WebCopilotTurnWidget turn = copilotTurn("turn-1");
    onUi(() -> {
      turn.appendMessage("Hello ");
      turn.appendMessage("");
      turn.appendMessage(null);
      turn.appendMessage("world");
      turn.flushMessageBuffer();
    });
    List<JsonObject> appends = surface.ofType(Protocol.OUT_MD_APPEND);
    assertEquals(2, appends.size());
    assertEquals("Hello ", str(appends.get(0), "text"));
    assertEquals(1, surface.ofType(Protocol.OUT_MD_FLUSH).size());
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Tool calls

  @Test
  void toolStatusFollowsTheClassicRules() {
    WebCopilotTurnWidget turn = copilotTurn("turn-1");
    onUi(() -> {
      turn.appendToolCallStatus(toolCall("c1", "read_file", "running", "Reading `Foo.java`", null));
      turn.appendToolCallStatus(toolCall("c1", "read_file", "completed", "Read `Foo.java`", null));
      // Without a progress message non-error updates are not shown.
      turn.appendToolCallStatus(toolCall("c2", "grep", "completed", " ", null));
      turn.appendToolCallStatus(toolCall("c3", "get_errors", "error", null, "Workspace not indexed"));
      turn.appendToolCallStatus(null);
    });
    List<JsonObject> statuses = surface.ofType(Protocol.OUT_TOOL_STATUS);
    assertEquals(3, statuses.size());
    assertEquals("running", str(statuses.get(0), "status"));
    assertEquals("completed", str(statuses.get(1), "status"));
    assertEquals("c1", str(statuses.get(1), "toolId"));
    assertEquals("error", str(statuses.get(2), "status"));
    assertTrue(str(statuses.get(2), "message").contains("get_errors"));
    assertTrue(str(statuses.get(2), "message").contains("Workspace not indexed"));
    // Every status line ends the current text segment first (classic reset()).
    List<String> types = surface.types();
    assertEquals(Protocol.OUT_SEGMENT_END, types.get(types.indexOf(Protocol.OUT_TOOL_STATUS) - 1));
  }

  @Test
  void subagentMessagesAreRoutedIntoTheSubagentBlock() {
    WebCopilotTurnWidget turn = copilotTurn("turn-1");
    onUi(() -> {
      turn.appendToolCallStatus(toolCall("sub-1", "run_subagent", "running", "Explore callers", null));
      turn.appendMessage("inside");
      turn.appendToolCallStatus(toolCall("c9", "list_dir", "completed", "Listed `src`", null));
      assertInstanceOf(WebSubagentTurnWidget.class, turn.getActiveTurnWidget());
      turn.appendToolCallStatus(toolCall("sub-1", "run_subagent", "completed", null, null));
      turn.appendMessage("after");
      assertSame(turn, turn.getActiveTurnWidget());
    });

    JsonObject sub = surface.ofType(Protocol.OUT_TURN_CREATE).get(1);
    String subId = str(sub, "turnId");
    assertEquals("subagent", str(sub, "role"));
    assertEquals("Explore callers", str(sub, "name"));
    assertEquals(turn.presenter().domId(), str(sub, "parentId"));

    List<JsonObject> appends = surface.ofType(Protocol.OUT_MD_APPEND);
    assertEquals(subId, str(appends.get(0), "turnId"));
    assertEquals(turn.presenter().domId(), str(appends.get(1), "turnId"));
    assertEquals(subId, str(surface.ofType(Protocol.OUT_TOOL_STATUS).get(0), "turnId"));
    JsonObject state = surface.ofType(Protocol.OUT_SUBAGENT_STATE).get(0);
    assertEquals(subId, str(state, "turnId"));
    assertEquals("completed", str(state, "state"));
  }

  @Test
  void failedSubagentShowsAnErrorLineInTheParent() {
    WebCopilotTurnWidget turn = copilotTurn("turn-1");
    onUi(() -> {
      turn.appendToolCallStatus(toolCall("sub-1", "run_subagent", "running", "Explore", null));
      turn.appendToolCallStatus(toolCall("sub-1", "run_subagent", "error", null, "boom"));
    });
    assertEquals("error", str(surface.ofType(Protocol.OUT_SUBAGENT_STATE).get(0), "state"));
    JsonObject status = surface.ofType(Protocol.OUT_TOOL_STATUS).get(0);
    assertEquals(turn.presenter().domId(), str(status, "turnId"));
    assertTrue(str(status, "message").contains("boom"));
  }

  @Test
  void restoredSubagentContentIsInjectedIntoItsBlock() {
    WebCopilotTurnWidget turn = copilotTurn("turn-1");
    CopilotTurnData data = new CopilotTurnData();
    ReplyData reply = new ReplyData();
    reply.setText("restored text");
    data.setReply(reply);
    onUi(() -> {
      // Restoration: only the completed event of the run_subagent call is persisted.
      turn.appendToolCallStatus(toolCall("sub-1", "run_subagent", "completed", "Explore", null));
      turn.restoreSubagentContent("sub-1", data, null);
    });
    String subId = str(surface.ofType(Protocol.OUT_TURN_CREATE).get(1), "turnId");
    JsonObject append = surface.ofType(Protocol.OUT_MD_APPEND).get(0);
    assertEquals(subId, str(append, "turnId"));
    assertEquals("restored text", str(append, "text"));
    assertEquals(1, surface.ofType(Protocol.OUT_TURN_CREATE).size() - 1, "no second block for the same call");
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Confirmations

  @Test
  void acceptingAnAlternativeActionCompletesTheFutureAndExposesTheSelection() throws Exception {
    WebCopilotTurnWidget turn = copilotTurn("turn-1");
    ConfirmationContent content = terminalConfirmation();
    CompletableFuture<LanguageModelToolConfirmationResult> future = onUi(
        () -> turn.requestToolExecutionConfirmation(content, Map.of("command", "mvn test", "explanation", "why")));

    JsonObject show = surface.ofType(Protocol.OUT_CONFIRM_SHOW).get(0);
    assertEquals("Run command?", str(show, "title"));
    assertEquals("mvn test", str(show, "command"));
    assertEquals("shell", str(show, "commandKind"));
    assertEquals("why", str(show, "explanation"));
    assertEquals("Allow", str(show.getAsJsonObject("primary"), "label"));
    assertEquals(2, show.getAsJsonArray("alternatives").size());
    assertEquals("Skip", str(show.getAsJsonObject("dismiss"), "label"));

    String confirmId = str(show, "confirmId");
    String sessionChoice = str(show.getAsJsonArray("alternatives").get(0).getAsJsonObject(), "id");
    onUi(() -> assertTrue(surface.confirmations.get(confirmId).choose(sessionChoice)));

    assertEquals(ToolConfirmationResult.ACCEPT.toString(), future.get().getResult());
    assertEquals("Allow in this Session", turn.getConfirmDialog().getSelectedAction().getLabel());
    JsonObject close = surface.ofType(Protocol.OUT_CONFIRM_CLOSE).get(0);
    assertNull(str(close, "cancelMessage"));
    assertFalse(surface.confirmations.containsKey(confirmId));
  }

  @Test
  void skippingACommandLeavesACancelLineAndSuppressesTheToolUpdate() throws Exception {
    WebCopilotTurnWidget turn = copilotTurn("turn-1");
    CompletableFuture<LanguageModelToolConfirmationResult> future = onUi(
        () -> turn.requestToolExecutionConfirmation(terminalConfirmation(), Map.of("command", "rm -rf build")));
    JsonObject show = surface.ofType(Protocol.OUT_CONFIRM_SHOW).get(0);
    String dismiss = str(show.getAsJsonObject("dismiss"), "id");
    onUi(() -> surface.confirmations.get(str(show, "confirmId")).choose(dismiss));

    assertEquals(ToolConfirmationResult.DISMISS.toString(), future.get().getResult());
    assertFalse(turn.getConfirmDialog().getSelectedAction().isAccept());
    assertEquals("rm -rf build", str(surface.ofType(Protocol.OUT_CONFIRM_CLOSE).get(0), "cancelMessage"));

    onUi(() -> turn.appendToolCallStatus(toolCall("c1", "run_in_terminal", "cancelled", "Cancelled", null)));
    assertTrue(surface.ofType(Protocol.OUT_TOOL_STATUS).isEmpty(), "classic view skips it after the cancel label");

    onUi(() -> {
      turn.appendMessage("next");
      turn.appendToolCallStatus(toolCall("c2", "read_file", "completed", "Read", null));
    });
    assertEquals(1, surface.ofType(Protocol.OUT_TOOL_STATUS).size());
  }

  @Test
  void invalidChoicesAreIgnored() {
    WebCopilotTurnWidget turn = copilotTurn("turn-1");
    CompletableFuture<LanguageModelToolConfirmationResult> future = onUi(
        () -> turn.requestToolExecutionConfirmation(terminalConfirmation(), null));
    WebToolConfirmationDialog dialog = (WebToolConfirmationDialog) turn.getConfirmDialog();
    onUi(() -> {
      assertFalse(dialog.choose("99"));
      assertFalse(dialog.choose("abc"));
      assertFalse(dialog.choose(null));
    });
    assertFalse(future.isDone());
  }

  @Test
  void aNewStatusLineCancelsAPendingConfirmationLikeTheClassicView() throws Exception {
    WebCopilotTurnWidget turn = copilotTurn("turn-1");
    CompletableFuture<LanguageModelToolConfirmationResult> future = onUi(
        () -> turn.requestToolExecutionConfirmation(terminalConfirmation(), null));
    onUi(() -> turn.appendToolCallStatus(toolCall("c5", "read_file", "running", "Reading", null)));
    assertEquals(ToolConfirmationResult.DISMISS.toString(), future.get().getResult());
    assertEquals(1, surface.ofType(Protocol.OUT_CONFIRM_CLOSE).size());
  }

  @Test
  void cancellingTheRequestDismissesTheConfirmation() throws Exception {
    WebCopilotTurnWidget turn = copilotTurn("turn-1");
    CompletableFuture<LanguageModelToolConfirmationResult> future = onUi(
        () -> turn.requestToolExecutionConfirmation(terminalConfirmation(), null));
    onUi(turn::cancelToolConfirmation);
    assertEquals(ToolConfirmationResult.DISMISS.toString(), future.get().getResult());
    assertNull(turn.getConfirmDialog());
  }

  @Test
  void confirmationsInsideASubagentAreShownInItsBlock() {
    WebCopilotTurnWidget turn = copilotTurn("turn-1");
    onUi(() -> {
      turn.appendToolCallStatus(toolCall("sub-1", "run_subagent", "running", "Explore", null));
      ((ThinkingTurnWidget) turn.getActiveTurnWidget()).requestToolExecutionConfirmation(terminalConfirmation(), null);
    });
    String subId = str(surface.ofType(Protocol.OUT_TURN_CREATE).get(1), "turnId");
    assertEquals(subId, str(surface.ofType(Protocol.OUT_CONFIRM_SHOW).get(0), "turnId"));
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Warnings and agent messages

  @Test
  void quotaWarningOffersPlanActions() {
    Quota premium = new Quota(0, false, true, 0, 300, 0, null);
    when(authStatusManager.getQuotaStatus()).thenReturn(
        new CheckQuotaResult(null, null, premium, null, null, CopilotPlan.individual, true, true));
    WebCopilotTurnWidget turn = copilotTurn("turn-1");
    onUi(() -> turn.presenter().showWarning("Quota exceeded", 402, null));

    JsonObject warn = surface.ofType(Protocol.OUT_WARN_SHOW).get(0);
    assertEquals("Quota exceeded", str(warn, "message"));
    assertEquals(2, warn.getAsJsonArray("actions").size());
    String actionId = str(warn.getAsJsonArray("actions").get(0).getAsJsonObject(), "id");
    assertNotNull(surface.actions.get(actionId));
  }

  @Test
  void byokQuotaWarningUsesTheByokMessageWithoutActions() {
    WebCopilotTurnWidget turn = copilotTurn("turn-1");
    onUi(() -> turn.presenter().showWarning("server text", 402, "Anthropic"));
    JsonObject warn = surface.ofType(Protocol.OUT_WARN_SHOW).get(0);
    assertEquals(com.microsoft.copilot.eclipse.ui.chat.Messages.chat_warnWidget_byokQuotaUsageMessage,
        str(warn, "message"));
    assertEquals(0, warn.getAsJsonArray("actions").size());
  }

  @Test
  void legacyBillingShowsTheUpgradeButtonOnlyForTheTrialHint() {
    when(authStatusManager.getQuotaStatus()).thenReturn(quota(false));
    WebCopilotTurnWidget turn = copilotTurn("turn-1");
    onUi(() -> {
      turn.presenter().showWarning("Please Upgrade to Copilot Pro (30-day free trial)", 402, null);
      turn.presenter().showWarning("Other problem", 500, null);
    });
    List<JsonObject> warnings = surface.ofType(Protocol.OUT_WARN_SHOW);
    assertEquals(1, warnings.get(0).getAsJsonArray("actions").size());
    assertEquals(0, warnings.get(1).getAsJsonArray("actions").size());
  }

  @Test
  void agentMessageShowsAPreviewAndButtons() {
    WebCopilotTurnWidget turn = copilotTurn("turn-1");
    CodingAgentMessageRequestParams params = new CodingAgentMessageRequestParams();
    params.setTitle("PR created");
    params.setDescription("short");
    params.setPrLink("https://github.com/o/r/pull/1");
    CodingAgentMessageRequestParams longParams = new CodingAgentMessageRequestParams();
    longParams.setDescription("x".repeat(150));
    onUi(() -> {
      turn.presenter().showAgentMessage(params);
      turn.presenter().showAgentMessage(longParams);
    });
    List<JsonObject> cards = surface.ofType(Protocol.OUT_AGENT_MESSAGE_SHOW);
    assertEquals("short", str(cards.get(0), "description"));
    assertEquals(2, cards.get(0).getAsJsonArray("actions").size());
    assertEquals(103, str(cards.get(1), "description").length());
    assertEquals(0, cards.get(1).getAsJsonArray("actions").size());
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Thinking, footer, compacting

  @Test
  void thinkingIsSealedWithAGeneratedTitleAndPersisted() {
    CopilotLanguageServerConnection ls = mock(CopilotLanguageServerConnection.class);
    when(ls.generateThinkingTitle(any()))
        .thenReturn(CompletableFuture.completedFuture(new GenerateThinkingTitleResponse("Checked the cache")));
    ThinkingPresenter.languageServerSupplier = () -> ls;
    WebCopilotTurnWidget turn = copilotTurn("turn-1");
    String[] blockId = new String[1];
    onUi(() -> {
      turn.setConversationContext("conv-1", "turn-1");
      turn.appendThinking(new Thinking(null, "**Inspecting**\nlooking at the cache", null));
      blockId[0] = turn.getActiveThinkingBlockId();
      turn.sealThinking();
      // A sealed block does not accept more text: the next fragment starts a new block.
      turn.appendThinking(new Thinking(null, "more", null));
    });
    assertNotNull(blockId[0]);
    List<JsonObject> states = surface.ofType(Protocol.OUT_THINKING_STATE);
    assertEquals("sealed", str(states.get(0), "state"));
    assertEquals("completed", str(states.get(1), "state"));
    assertEquals("Checked the cache", str(states.get(1), "title"));
    verify(persistenceManager).updateThinkingBlockTitle("conv-1", "turn-1", blockId[0], "Checked the cache");
    List<JsonObject> appends = surface.ofType(Protocol.OUT_THINKING_APPEND);
    assertFalse(blockId[0].equals(str(appends.get(1), "blockId")));
  }

  @Test
  void cancellingWhileThinkingCancelsAndPersistsTheBlock() {
    WebCopilotTurnWidget turn = copilotTurn("turn-1");
    onUi(() -> {
      turn.setConversationContext("conv-1", "turn-1");
      turn.appendThinking(new Thinking(null, "thinking...", null));
      turn.appendToolCallStatus(toolCall("c1", "read_file", "running", "Reading", null));
    });
    String blockId = turn.getActiveThinkingBlockId();
    onUi(() -> turn.presenter().onChatMessageCancelled());

    assertEquals("cancelled", str(surface.ofType(Protocol.OUT_THINKING_STATE).get(0), "state"));
    assertEquals(1, surface.ofType(Protocol.OUT_TURN_CANCEL_RUNNING).size());
    verify(persistenceManager).cancelThinkingBlock(eq("conv-1"), eq("turn-1"), eq(blockId));
  }

  @Test
  void restoredThinkingBlocksKeepTheirTitle() {
    WebCopilotTurnWidget turn = copilotTurn("turn-1");
    ThinkingBlockData data = new ThinkingBlockData("block-1", "**A**\ntext");
    data.setTitle("Restored title");
    onUi(() -> turn.restoreThinkingBlock(data));
    JsonObject restore = surface.ofType(Protocol.OUT_THINKING_RESTORE).get(0);
    assertEquals("block-1", str(restore, "blockId"));
    assertEquals("Restored title", str(restore, "title"));
  }

  @Test
  void titlesAreExtractedLikeTheClassicThinkingBlock() {
    String[] titles = ThinkingPresenter.extractTitles("**First**\nbody\n**Second**\nmore\nnot **inline** title");
    assertEquals(List.of("First", "Second"), List.of(titles));
  }

  @Test
  void modelInfoAndCompactingAreShownInTheTurn() {
    WebCopilotTurnWidget turn = copilotTurn("turn-1");
    onUi(() -> {
      turn.renderModelInfo("GPT-5", 1.0, null);
      turn.showCompactingStatus();
      turn.hideCompactingStatus();
    });
    assertEquals("GPT-5", str(surface.ofType(Protocol.OUT_MODEL_INFO).get(0), "text"));
    List<JsonObject> compacting = surface.ofType(Protocol.OUT_COMPACTING);
    assertTrue(compacting.get(0).get("visible").getAsBoolean());
    assertFalse(compacting.get(1).get("visible").getAsBoolean());
  }
}
