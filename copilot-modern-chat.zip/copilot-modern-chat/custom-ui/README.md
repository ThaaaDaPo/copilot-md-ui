# Moderne Chat-Oberfläche für GitHub Copilot in Eclipse

Dieser Ordner enthält eine HTML-basierte Darstellung des Copilot-Chats. Sie orientiert sich an GitHub Copilot Chat in
VS Code: Markdown, echte Tabellen, Syntax-Highlighting (inkl. ABAP und ABAP CDS), Mermaid-Diagramme, KaTeX-Formeln,
aufklappbare Thinking- und Subagent-Blöcke sowie Tool-Bestätigungen im Chatverlauf.

Die gesamte Copilot-Logik bleibt unverändert: Kommunikation mit dem Language Server, Streaming, Agent-/Ask-/Plan- und
Custom-Modi, Tool Calling, MCP, Bestätigungen und deren „für diese Sitzung / immer erlauben“-Regeln, Persistenz und
Verlauf, Subagents, Quota-Hinweise, Abbruch. Die neue Oberfläche ist ausschließlich eine **alternative
Präsentationsschicht** für den Nachrichtenbereich der Chat-View.

| Hell | Dunkel |
|---|---|
| ![Chat hell](docs/screenshot-light.png) | ![Chat dunkel](docs/screenshot-dark.png) |

- [Architektur](#architektur)
- [Verzeichnisstruktur](#verzeichnisstruktur)
- [Technologien](#technologien)
- [Kommunikation Java ↔ Web](#kommunikation-java--web)
- [Integration in das Microsoft-Plugin](#integration-in-das-microsoft-plugin)
- [Änderungen am Originalcode](#änderungen-am-originalcode)
- [Verteilung an das Team (Update-Site)](#verteilung-an-das-team-update-site)
- [Build](#build)
- [In Eclipse testen](#in-eclipse-testen)
- [Tests](#tests)
- [Updates des offiziellen Plugins übernehmen](#updates-des-offiziellen-plugins-übernehmen)
- [Sicherheit](#sicherheit)
- [Performance](#performance)
- [Bekannte Einschränkungen](#bekannte-einschränkungen)
- [Verifikationsstand](#verifikationsstand)

## Architektur

```mermaid
flowchart TB
    subgraph MS["com.microsoft.copilot.eclipse.ui (unverändert bis auf 2 Hooks)"]
        CV[ChatView<br/>Senden, Sessions, Persistenz,<br/>Subagent-IDs, Verlauf]
        CCV[ChatContentViewer<br/>Streaming-Queue, Fehler, 402-Fallback,<br/>Todo-Liste, Thinking-Dispatch]
        ATS[AgentToolService<br/>Tool-Aufrufe, Auto-Approve,<br/>Bestätigungen]
        AB[ActionBar, TopBanner, WorkingSetBar,<br/>TodoListBar, Handoffs, Verlauf]
        F[ChatContentViewerFactory]
    end
    subgraph WEB["custom.copilot.webchat (neu)"]
        P[WebChatContentViewerProvider]
        V[WebChatContentViewer<br/>extends ChatContentViewer]
        T[WebCopilotTurnWidget / WebUserTurnWidget /<br/>WebSubagentTurnWidget<br/>extends Original-Widgets]
        TP[TurnPresenter / ThinkingPresenter /<br/>WebToolConfirmationDialog]
        B[ChatBridge<br/>Batching, Replay, Validierung]
        BR[SWT Browser<br/>web/index.html]
    end
    CV -- "createConversationPage()" --> F
    F -- Extension Point --> P --> V
    CV -- "processTurnEvent, startNewTurn, ..." --> CCV
    V -. erbt .-> CCV
    CCV -- "createCopilotTurnWidget()" --> T
    ATS -- "getTurnWidget().requestToolExecutionConfirmation()" --> T
    T --> TP --> B -- "execute(receive([...]))" --> BR
    BR -- "__copilotChatPost(json)" --> B
```

**Grundidee:** Die `ChatView` und alle Services sprechen mit dem Nachrichtenbereich ausschließlich über die API von
`ChatContentViewer` und den Turn-Widgets (`BaseTurnWidget`, `ThinkingTurnWidget`, `CopilotTurnWidget`). Die neue
Implementierung **erbt** von genau diesen Klassen:

- `WebChatContentViewer extends ChatContentViewer`: Die komplette Ereignisverarbeitung des Originals (Streaming-Queue,
  Thinking-Dispatch, Agent-Rounds, Todo-Liste, Fehlertexte, 402-/Fallback-Modell-Logik) läuft **unverändert**. Nur das
  Erzeugen der Turn-Widgets wird umgelenkt, und der SWT-Inhaltsbereich wird durch einen Browser überlagert.
- `WebCopilotTurnWidget extends CopilotTurnWidget` (analog für User- und Subagent-Turns): Die Widgets behalten die
  öffentliche API, die `ChatView`, `ChatContentViewer` und `AgentToolService` aufrufen, und delegieren an den
  `TurnPresenter`. Die geerbten SWT-Inhalte liegen in einem unsichtbaren Container.
- `WebToolConfirmationDialog extends InvokeToolConfirmationDialog`: `AgentToolService` liest nach einer Bestätigung
  `getConfirmDialog().getSelectedAction()`, um Sitzungs- und Dauerfreigaben zu speichern. Dieser Vertrag bleibt erhalten.

Zustand und Wahrheit liegen damit weiterhin vollständig in der Java-Logik. Die Web-Seite ist eine reine Projektion der
Nachrichten, die Java ihr sendet.

**Was bewusst nativ (SWT) bleibt:** Eingabeleiste (`ActionBar` mit Content-Assist für `/`-Befehle und `#`-Referenzen,
Modell-, Modus- und Reasoning-Auswahl, Kontextfenster-Anzeige, Anhänge), Top-Banner, Working-Set-, Todo- und
Handoff-Leisten, Chat-Verlauf sowie die Willkommens- und Login-Seiten. Diese Komponenten sind funktionsreich und
stellen keine Copilot-Antworten dar. Ein Nachbau in HTML hätte ein hohes Regressionsrisiko ohne Gewinn bei der
Antwortdarstellung (Regeln 1 und 4). Sie lassen sich in einer späteren Ausbaustufe nach demselben Muster migrieren.

## Verzeichnisstruktur

```
custom-ui/
├── README.md                          diese Datei
├── docs/                              Screenshots
├── team-update-site.properties         optional: gemeinsamer Ordner, in den der Build die Update-Site kopiert
├── custom.copilot.updatesite/         Build-Schritt, der die Site in diesen Ordner kopiert (nur wenn gesetzt)
├── pom.xml                            Komplettbuild inkl. Web-Chat-Tests (aggregiert das Repo + Test-Fragment)
├── checkstyle.xml                     abgeleitet von ../checkstyle.xml (ohne Microsoft-Copyright-Header)
├── parent/pom.xml                     gemeinsame Tycho-Konfiguration (erbt vom offiziellen Root-POM)
├── custom.copilot.webchat/            das Plug-in
│   ├── META-INF/MANIFEST.MF
│   ├── plugin.xml                     Extension: chatContentViewerProviders, Präferenzseite
│   ├── src/custom/copilot/webchat/
│   │   ├── WebChatContentViewerProvider.java   Entscheidung Web/Klassisch, Fallback
│   │   ├── WebChatPlugin.java, Messages.java, messages.properties
│   │   ├── bridge/      ChatBridge (Kanal), Protocol (Nachrichtenkatalog)
│   │   ├── viewer/      WebChatContentViewer, Turn-Widgets, TurnPresenter, ThinkingPresenter,
│   │   │                WebToolConfirmationDialog, ThemeSupport, ChatSurface
│   │   ├── actions/     LinkOpener (Datei-/Weblinks), CodeActions (Kopieren, Einfügen)
│   │   └── preferences/ Präferenzen + Seite „GitHub Copilot > Chat View“
│   └── web/                           die Oberfläche (ohne Build-Schritt lauffähig)
│       ├── index.html                 mit strikter Content-Security-Policy
│       ├── css/chat.css, highlight.css
│       ├── js/ util, bridge, theme, markdown, highlight-abap, reconcile, code, mermaid-view, chat
│       └── vendor/                    gepinnte Bibliotheken + Lizenzen (THIRD-PARTY-NOTICES.md)
├── custom.copilot.webchat.test/       JUnit-5-Tests (Fragment), inkl. End-to-End-Test im echten SWT-Browser
└── web-tooling/                       Node-Werkzeuge (nicht Teil des Maven-Builds)
    ├── package.json                   gepinnte Bibliotheksversionen
    ├── scripts/vendor.mjs             kopiert Bibliotheken nach web/vendor
    ├── scripts/browser-test.mjs       Tests in echtem Chrome/Edge (CSP, Mermaid, Performance)
    ├── scripts/screenshots.mjs        Screenshots hell/dunkel zur visuellen Prüfung
    ├── fixtures/scenarios.mjs         realistische Protokoll-Sequenzen
    └── test/*.test.mjs                Unit-Tests mit jsdom
```

## Technologien

| Bereich | Wahl | Begründung |
|---|---|---|
| Einbettung | **SWT `Browser`**: Edge/WebView2 (Windows), WebKit (macOS), WebKitGTK (Linux) | Teil von Eclipse, keine Zusatzinstallation, auf allen drei Plattformen gepflegt. JCEF würde ein ~150-MB-Chromium je Plattform mitbringen und ist in Eclipse nicht etabliert. Internet Explorer wird unter Windows ausdrücklich nicht verwendet. |
| Sprache | **Plain JavaScript (ES2020) mit `// @ts-check` + JSDoc-Typen**, CSS | Kein Bundler, kein Build-Schritt: der Tycho-Build bleibt frei von Node.js. Die Typprüfung ist mit `tsc --checkJs` möglich. Klassische Skripte statt ES-Module, weil Chromium Module von `file://` blockiert. |
| Markdown | **markdown-it 14** (`html: false`) | Standardkonform (CommonMark + GFM-Tabellen und Durchstreichen), erweiterbar, schnell, ignoriert Roh-HTML von Haus aus. |
| Sanitizing | **DOMPurify 3** | De-facto-Standard. Zweite Verteidigungslinie hinter `html: false` und für Mermaid-SVG. |
| Highlighting | **highlight.js 11** + eigene Grammatiken **ABAP** und **ABAP CDS** | 40+ Sprachen, synchron (wichtig fürs Streaming), klein. highlight.js liefert kein ABAP mit, daher eine eigene, getestete Grammatik (`js/highlight-abap.js`): Statements, ABAP SQL inkl. `@`-Hostvariablen und `@DATA(...)`, String-Templates `|...{ }...|`, Feldsymbole, Pragmas, `sy-`-Felder, statische und Instanz-Aufrufe, Namensräume `/NS/`. |
| Diagramme | **Mermaid 11** (lazy geladen) | Flowchart, Sequence, Class, State, ER, Gantt u. a. Läuft mit `securityLevel: 'strict'`. |
| Formeln | **KaTeX 0.16** | Schnell und synchron, `trust: false`. Fonts als Data-URIs eingebettet, weil Browser `file://`-Fonts per CORS blockieren. |
| Java ↔ Web | **`BrowserFunction`** (Web → Java) und **`Browser.execute`** (Java → Web), JSON mit Gson | Plattformunabhängige SWT-API, kein lokaler HTTP-Server, kein offener Port. |

## Kommunikation Java ↔ Web

Ein einziger, typisierter, ereignisbasierter Kanal (`bridge/ChatBridge.java`, `web/js/bridge.js`). Den
Nachrichtenkatalog definiert `bridge/Protocol.java`.

**Java → Web.** Nachrichten `{"type": ..., ...Felder}` werden gesammelt und einmal pro UI-Zyklus als Batch
`window.CopilotChat.receive([...])` ausgeführt. Aufeinanderfolgende Text-Deltas desselben Turns werden vor dem Senden
zusammengeführt. Alle Nachrichten landen zusätzlich in einem **Replay-Log**: Meldet sich die Seite (erneut) mit
`ready`, spielt Java das Log vollständig neu ein. So geht nichts verloren, wenn die Seite später fertig lädt als die
ersten Events eintreffen.

| Typ | Bedeutung |
|---|---|
| `init`, `theme`, `avatar` | Farben/Fonts aus Eclipse, Feature-Schalter, übersetzte Texte, Avatare (Data-URI) |
| `turn.create` | Neuer Turn (`user`, `copilot`, `subagent` mit `parentId`) |
| `md.append`, `md.flush`, `segment.end` | Gestreamter Markdown-Text; Segmentende wie `BaseTurnWidget.reset()` |
| `tool.status`, `turn.cancelRunning` | Tool-Statuszeilen (running/completed/cancelled/error) |
| `subagent.state` | Status eines Subagent-Blocks |
| `thinking.append`, `thinking.state`, `thinking.restore` | Thinking-Blöcke inkl. generiertem Titel |
| `confirm.show`, `confirm.close` | Tool-Bestätigung (Primär-, Dropdown- und Abbrechen-Aktion) |
| `warn.show`, `agentMessage.show`, `error.show` | Hinweise mit Aktions-IDs, Coding-Agent-Karte, Fehlerbanner |
| `modelInfo`, `compacting` | Fußzeile (Modell) und „Compacting conversation…“ |
| `scroll.pin` | Neue Nutzernachricht oben halten (wie die klassische Ansicht) |

**Web → Java.** `__copilotChatPost('{"type": ..., "payload": {...}}')`. Java akzeptiert nur die Typen aus
`Protocol.INBOUND_TYPES`, prüft Größe und Feldtypen und führt **nur registrierte Aktionen** aus:

| Typ | Wirkung in Java |
|---|---|
| `ready` | Handshake, Init und Replay |
| `openLink` | `LinkOpener`: http/https/mailto extern, `file:` und Workspace-Pfade im Editor (mit `#L12`), Ordner im Explorer |
| `copyCode`, `copyText` | Zwischenablage + `conversation/codeCopy`-Telemetrie wie im Original |
| `insertCode` | Einfügen an der Cursorposition des aktiven Editors (wie der Original-Button) |
| `action` | Führt eine vorher von Java registrierte Aktion aus (z. B. „Upgrade Plan“), adressiert über eine zufällige ID |
| `confirm` | Antwort auf eine Tool-Bestätigung (Index in der von Java gelieferten Aktionsliste) |
| `log` | Fehler der Seite ins Eclipse-Error-Log |

## Integration in das Microsoft-Plugin

1. `ChatView.createConversationPage()` erzeugt den Viewer über `ChatContentViewerFactory.create(...)`.
2. Die Factory fragt den Extension Point `com.microsoft.copilot.eclipse.ui.chatContentViewerProviders` ab.
   `custom.copilot.webchat` registriert dort `WebChatContentViewerProvider`.
3. Der Provider liefert `null`, und damit greift automatisch die klassische Ansicht, wenn
   - die Präferenz *GitHub Copilot › Chat View › Use the modern chat view* ausgeschaltet ist,
   - kein geeigneter Browser verfügbar ist (z. B. fehlende WebView2-Runtime unter Windows, fehlendes WebKitGTK unter
     Linux; danach für die laufende Sitzung dauerhaft), oder
   - die Web-Ressourcen nicht gefunden werden.

   Wirft ein Provider eine Exception, fängt die Factory sie ab und verwendet ebenfalls die klassische Ansicht.
4. `ChatContentViewer` erzeugt Turn-Widgets über die neuen Factory-Methoden `createCopilotTurnWidget` /
   `createUserTurnWidget`, die `WebChatContentViewer` überschreibt.

Ist das Plug-in nicht installiert, verhält sich Copilot exakt wie das Original.

## Änderungen am Originalcode

Nur das UI-Bundle `com.microsoft.copilot.eclipse.ui`; alle Änderungen sind additiv:

| Datei | Änderung | Notwendigkeit |
|---|---|---|
| `src/.../ui/chat/ChatView.java` | 1 Zeile: `new ChatContentViewer(...)` → `ChatContentViewerFactory.create(...)` | Einziger Punkt, an dem der Nachrichtenbereich erzeugt wird |
| `src/.../ui/chat/ChatContentViewer.java` | 2 Zeilen umgestellt, 2 `protected` Factory-Methoden ergänzt | Sonst müsste die komplette Ereignisverarbeitung (~150 Zeilen Business-Logik inkl. 402-Fallback) dupliziert werden |
| `src/.../ui/chat/IChatContentViewerProvider.java` | **neu** (Interface) | Vertrag des Extension Points |
| `src/.../ui/chat/ChatContentViewerFactory.java` | **neu** | Provider-Lookup mit sicherem Fallback |
| `plugin.xml` | 4 Zeilen: Deklaration des Extension Points | Eclipse-konforme, lose Kopplung |
| `schema/chatContentViewerProviders.exsd` | **neu** | Dokumentation des Extension Points für PDE |
| `pom.xml` (Root) | 2 Zeilen: Module `custom-ui/custom.copilot.webchat` und `custom-ui/custom.copilot.updatesite` | Der offizielle Build baut den Chat mit und kopiert die Site bei Bedarf in den Team-Ordner |
| `pom.xml` (Root) | 2 Zeilen: `-Dnet.bytebuddy.experimental=true` in `tycho.testArgLine` (Standard und macOS-Profil) | Die offiziellen Tests laufen auch mit JDK 25 (Mockito); unter JDK 21 wirkungslos |
| `.mvn/maven.config` | **neu**, 1 Zeile: `-Dtycho.buildqualifier.format='custom'yyyyMMddHHmm` | Jeder Build ist eine neuere Version, auch gegenüber offiziellen Builds derselben Versionsnummer |
| `com.microsoft.copilot.eclipse.feature/feature.xml` | 3 Zeilen: `<plugin id="custom.copilot.webchat"/>` | Der Chat ist Teil des Features „GitHub Copilot“, dadurch kommt er per normalem Update (siehe [Verteilung](#verteilung-an-das-team-update-site)) |

Manifeste, CSS-Themes, die Update-Site-Definition und alle anderen Klassen sind **unverändert**.

> Hinweis: Die `.project`-Dateien der Microsoft-Module wurden nicht vom Web-Chat geändert. Die dortigen
> `filteredResources`-Einträge stammen vom Java-Sprachserver von VS Code und sollten nicht committet werden.

## Verteilung an das Team (Update-Site)

Der Ablauf ist derselbe wie bei jedem anderen Eclipse-Plugin:

**Projekt bauen → Help › Check for Updates → installieren → fertig.**

Das funktioniert, weil

- der Chat **Teil des Features „GitHub Copilot“** ist (gleiche Feature-ID wie das offizielle Plugin). Für Eclipse ist
  er einfach eine neuere Version von GitHub Copilot;
- der normale Build (`./mvnw clean verify`) die fertige Update-Site erzeugt:
  `com.microsoft.copilot.eclipse.repository/target/repository`;
- jeder Build automatisch eine höhere Version bekommt (`0.21.0.custom<Zeitstempel>`, eingestellt in
  `.mvn/maven.config`). Bei gleicher Versionsnummer ist sie auch höher als jeder offizielle Microsoft-Build, deren
  Qualifier nur aus Ziffern bestehen.

**Wer selbst baut** (wie bisher): Die Site aus `target/repository` ist in Eclipse bereits bekannt, wenn von dort
installiert wurde. Danach reicht nach jedem Build *Check for Updates*.

**Wenn einer für alle baut:** In `custom-ui/team-update-site.properties` einmalig einen gemeinsamen Ordner
eintragen, z. B. `copilot.updatesite.dir=/Volumes/Team/eclipse/copilot`. Jeder Build kopiert die fertige Site dann
automatisch dorthin, erst die Plug-ins und dann die Metadaten, damit niemand eine halbe Site sieht. Jeder
Entwickler fügt diesen Ordner (oder die URL eines Webservers, der ihn ausliefert) **einmalig** unter
*Help › Install New Software › Add…* hinzu; ab dann genügt *Check for Updates*. Eclipse kann eine Update-Site nicht
von selbst entdecken, dieser eine Schritt ist daher unvermeidbar.

**Offizielle Microsoft-Site:** Ist bei einem Entwickler zusätzlich die offizielle Copilot-Update-Site von Microsoft
eingetragen, würde Eclipse eine *neue Versionsnummer* von Microsoft (z. B. 0.22.0) ohne den Chat einspielen. Diese
Site sollte deshalb nicht eingetragen sein; bei Installation über eure Site ist sie es nicht. Neue
Microsoft-Versionen kommen per Merge und Build.

## Build

Voraussetzungen wie beim offiziellen Projekt: JDK 21 (oder neuer), Netzwerkzugriff für den ersten Tycho-Lauf.

```bash
./mvnw clean verify                           # offizieller Build inkl. Web-Chat und Update-Site
./mvnw -f custom-ui/pom.xml clean verify      # zusätzlich die Tests des Web-Chats
# Update-Site: com.microsoft.copilot.eclipse.repository/target/repository  (und *.zip daneben)
```

Der Build läuft mit JDK 21 und JDK 25 ohne zusätzliche Parameter.

Bibliotheken aktualisieren (nur bei Versionswechsel nötig; das Ergebnis wird eingecheckt):

```bash
cd custom-ui/web-tooling
npm install            # Versionen stehen gepinnt in package.json / package-lock.json
npm run vendor         # kopiert nach custom.copilot.webchat/web/vendor, schreibt THIRD-PARTY-NOTICES.md
```

## In Eclipse testen

**Installieren:** siehe [Verteilung an das Team](#verteilung-an-das-team-update-site). Lokal lässt sich die Site
auch direkt aus `com.microsoft.copilot.eclipse.repository/target/repository` einbinden.

**Entwickeln (PDE):** Root-Projekte und `custom-ui/*` als „Existing Projects“ importieren, Target `base.target`
aktivieren, Eclipse-Application starten (*Run As › Eclipse Application*). Die Web-Dateien werden direkt aus
`web/` geladen. Für Änderungen an HTML/CSS/JS genügt es, eine neue Konversation zu öffnen.

**Ein-/Ausschalten:** *Preferences › GitHub Copilot › Chat View*. Die Einstellung gilt für danach geöffnete
Konversationen.

### Manuelle Testfälle

Diese Fälle benötigen ein echtes Copilot-Konto und lassen sich nicht automatisiert prüfen:

| # | Schritte | Erwartung |
|---|---|---|
| M1 | Anmelden, Ask-Modus, Frage stellen | Antwort streamt flüssig, Nutzernachricht bleibt oben, danach folgt der Text unten mit |
| M2 | Während des Streamings nach oben scrollen | Kein Zurückspringen; Button „Scroll to bottom“ erscheint |
| M3 | „Erkläre … mit Tabelle und Mermaid-Sequenzdiagramm“ | Tabelle, Diagramm, Umschalter Diagramm/Quelltext |
| M4 | Agent-Modus: Datei bearbeiten lassen | Tool-Zeilen running → completed, Working-Set-Leiste wie gewohnt, Keep/Undo funktioniert |
| M5 | Agent-Modus: Terminalbefehl | Bestätigung im Chat; *Allow*, *Allow in this Session* und *Skip* funktionieren; nach „Session“ keine erneute Nachfrage |
| M6 | MCP-Tool aufrufen | Bestätigung mit Server-Optionen, Ergebnis-Statuszeile |
| M7 | Stop während Tool-Bestätigung bzw. Thinking | Bestätigung verschwindet, laufende Zeilen werden „cancelled“, Thinking wird abgebrochen und persistiert |
| M8 | Modell mit Reasoning (Thinking) | Thinking-Block streamt, klappt zu, Titel erscheint |
| M9 | Subagent (`run_subagent`) | Verschachtelter Block mit eigenem Text und Tools |
| M10 | Verlauf öffnen und alte Konversation laden | Alle Turns inkl. Thinking, Tools, Subagent, Fehlermeldungen werden wiederhergestellt; Fortsetzen funktioniert |
| M11 | Link auf Datei / `#L42` in Antwort klicken | Datei öffnet im Editor an Zeile 42 |
| M12 | Code „Copy“ / „Insert into editor“ | Zwischenablage bzw. Einfügen an Cursor |
| M13 | Quota-Limit / 402 | Warnung mit „Enable Additional Usage“ / „Upgrade Plan“ |
| M14 | Theme hell ↔ dunkel, Chat-Schrift in *Preferences › Colors and Fonts* ändern | Farben passen nach Neuöffnen; Schrift sofort |
| M15 | Präferenz ausschalten, neue Konversation | Klassische Ansicht |
| M16 | Datei aus dem Project Explorer auf den Nachrichtenbereich ziehen | Datei wird als Referenz angehängt (plattformabhängig, siehe Einschränkungen) |

## Tests

| Ebene | Ausführen | Inhalt |
|---|---|---|
| Java (Tycho, JUnit 5) | `./mvnw -f custom-ui/pom.xml verify` | `ChatBridgeTest` (Batching, Merge, Replay, Validierung, Escaping), `WebTurnWidgetTest` (Tool-Regeln, Subagent-Routing und -Wiederherstellung, Bestätigungen inkl. ausgewählter Aktion und Abbruch-Zeile, Warnungen TBB/BYOK/Legacy, Agent-Karte, Thinking mit Titel und Persistenz, Abbruch), `WebChatContentViewerTest` (**End-to-End im echten SWT-Browser**: Streaming durch den Original-`ChatContentViewer`, Tabelle, ABAP, Mermaid gültig/ungültig, XSS, Bestätigung per Klick in der Seite, Fehlerbanner, Reload/Replay), `LinkOpenerTest` |
| JavaScript (jsdom) | `cd web-tooling && npm test` | Markdown-Elemente, Tabellen, Roh-HTML, Link-Schemata, Datei-Links, Bilder, Tasklisten, Fences beim Streaming, Mathe-Regeln, KaTeX-Sicherheit, Protokoll-Handler, Streaming-Stabilität, Fehlerisolation, ABAP-/CDS-Grammatik |
| Browser (Chrome/Edge) | `cd web-tooling && npm run test:browser` | Keine CSP-Verletzungen/Konsolenfehler, alle 5 Diagrammtypen, Mermaid-XSS-Versuche, Token-Streaming, 150-Turn-Verlauf, 1000-Zeilen-Tabelle |
| Visuell | `npm run screenshots -- <ordner>` | Screenshots hell/dunkel |

Hinweis für JDK > 24: Root-POM und Test-Fragment setzen `-Dnet.bytebuddy.experimental=true`, damit Mockito läuft.

## Updates des offiziellen Plugins übernehmen

1. Upstream mergen. Konflikte sind nur in den oben genannten Dateien möglich und bestehen fast immer aus
   einzelnen Zeilen (ein Aufruf in `ChatView`, zwei Konstruktoraufrufe in `ChatContentViewer`, je ein Block in
   `plugin.xml` und `feature.xml`, vier Zeilen im Root-`pom.xml`). Bei einem Versionssprung (z. B. 0.22.0) ist nichts weiter zu tun: Das
   Manifest des Web-Chats verlangt nur „mindestens 0.21.0“.
2. `./mvnw -f custom-ui/pom.xml clean verify` ausführen. Der Compiler meldet geänderte Signaturen der
   überschriebenen Methoden sofort.
3. **API-Abgleich der Turn-Widgets prüfen.** Fügt Microsoft `BaseTurnWidget`, `ThinkingTurnWidget`,
   `CopilotTurnWidget`, `InvokeToolConfirmationDialog` oder `ChatContentViewer` neue öffentliche Darstellungsmethoden
   hinzu, die die `ChatView` aufruft, müssen sie in den `Web*TurnWidget`-Klassen bzw. im `TurnPresenter` ergänzt
   werden. Nicht überschriebene Methoden würden sonst unsichtbar in die versteckte SWT-Struktur rendern. Prüfen lässt
   sich das mit `git diff <alt>..<neu> -- com.microsoft.copilot.eclipse.ui/src/com/microsoft/copilot/eclipse/ui/chat/`.
4. Die gespiegelte Logik ist in Javadoc als „Mirrors … of the classic …“ markiert (Tool-Status-Regeln, Subagent-
   Routing, Thinking-Zustände und Titel-Erzeugung, Warnungs-/Quota-Logik, Link-Öffnen, Code einfügen). Bei Änderungen
   an diesen Stellen im Original den Diff gegenlesen.
5. Optional `npm test` und `npm run test:browser` im Ordner `web-tooling`.
6. Bauen. Alle Entwickler erhalten die neue Version über „Check for Updates“.

## Sicherheit

- **Kein Roh-HTML:** markdown-it rendert HTML aus Antworten als Text; DOMPurify filtert die Ausgabe zusätzlich
  (u. a. `script`, `style`, `iframe`, `form`, `img`, Event-Handler).
- **Content-Security-Policy** in `index.html`: nur lokale Skripte, keine Inline-Skripte, kein Netzwerkzugriff
  (`connect-src 'none'`), keine Frames oder Objekte.
- **Links:** `javascript:`, `vbscript:`, `data:` usw. werden weder verlinkt noch geöffnet. Jeder Klick geht an Java;
  dort wird nur geöffnet, was auch die klassische Ansicht öffnen würde. Remote-Bilder werden nicht geladen
  (Tracking-Schutz), sondern als Link dargestellt.
- **Navigation gesperrt:** Nur die eigene Seite darf geladen werden. Popups, abgelegte Dateien, Reload-Tastenkürzel
  und das Browser-Kontextmenü (mit „Reload“) sind blockiert bzw. durch ein eigenes Menü ersetzt.
- **Bridge:** genau eine Funktion, Whitelist der Nachrichtentypen, Größenlimits, Feldtyp-Prüfung. Aktionen und
  Bestätigungen werden über zufällige, von Java vergebene IDs adressiert. Die Seite kann nichts ausführen, was Java
  nicht vorher angeboten hat.
- **Mermaid:** `securityLevel: 'strict'` (keine Click-Handler, bereinigte Labels), keine HTML-Labels, SVG erneut
  durch DOMPurify. Fehlerhafte Diagramme zeigen nur einen Hinweis.
- **KaTeX:** `trust: false` (kein `\href`, `\htmlId` …), `maxExpand` begrenzt.
- Alle Bibliotheken sind lokal eingebunden; zur Laufzeit gibt es keinen Download.

## Performance

- Java bündelt Streaming-Deltas: ein `execute` pro UI-Zyklus statt einem pro Token.
- Die Seite rendert einen laufenden Textblock höchstens alle 50 ms. Per **Block-Abgleich** werden nur geänderte
  Top-Level-Blöcke ersetzt. Fertige Absätze, Codeblöcke und Diagramme bleiben unangetastet, und eine Textauswahl
  bleibt erhalten.
- Highlighting nur für geänderte Blöcke; sehr große Blöcke werden erst nach Abschluss eingefärbt.
- Mermaid (3,5 MB) wird erst beim ersten Diagramm geladen. Diagramme rendern einzeln, erst in Sichtnähe und mit
  Cache (identische Diagramme, Theme-Wechsel).
- `content-visibility: auto` für ältere Turns: lange Verläufe bleiben flüssig (gemessen: 150 Turns in ~0,2 s).
- Lange Codeblöcke (> 60 Zeilen) werden eingeklappt und lassen sich aufklappen.

## Bekannte Einschränkungen

- **macOS:** SWT verwendet dort WebKit im Eclipse-Prozess, JavaScript läuft also auf dem UI-Thread. Das Rendern
  sehr großer Mermaid-Diagramme kann Eclipse kurz (meist < 200 ms) blockieren. Diagramme rendern deshalb einzeln und
  verzögert. Unter Windows (WebView2) und Linux (WebKitGTK) läuft die Seite in einem eigenen Prozess.
- **Windows** benötigt die Microsoft-Edge-WebView2-Runtime (in Windows 10/11 meist vorinstalliert). Fehlt sie, wird
  automatisch die klassische Ansicht genutzt. **Linux** benötigt WebKitGTK (`libwebkit2gtk-4.1`).
- Getestet wurde automatisiert auf macOS (SWT/WebKit) sowie in Chromium (entspricht der Engine von WebView2).
  **Windows und Linux wurden nicht in einer echten Eclipse-Instanz geprüft.**
- Drag & Drop von Workspace-Dateien *auf den Nachrichtenbereich* hängt davon ab, ob die Browser-Engine ein
  SWT-Drop-Target zulässt. Auf die Eingabeleiste funktioniert es immer.
- Ein Theme-Wechsel (hell/dunkel) wirkt auf offene Konversationen erst nach dem Neuöffnen. Schriftänderungen wirken
  sofort.
- Tool-Aufrufe zeigen, wie im Original, die Fortschrittsmeldung. Ein- und Ausgaben der Tools liefert der Language
  Server dem Client nicht, sie lassen sich daher nicht aufklappbar darstellen.
- Eingabeleiste, Banner und Leisten bleiben vorerst nativ (siehe [Architektur](#architektur)).
- Die Darstellung des Nutzertextes ist (wie im Original) reiner Text ohne Markdown.

## Verifikationsstand

| Funktion | Status | Nachweis |
|---|---|---|
| Build des offiziellen Projekts mit den Hooks | ✅ verifiziert | Tycho-Build Core/UI/Terminal |
| Offizielle UI-Tests (478) mit den Hooks | ✅ verifiziert | `com.microsoft.copilot.eclipse.ui.test` grün |
| Streaming über die Original-Ereignisverarbeitung | ✅ verifiziert | `WebChatContentViewerTest` (echter SWT-Browser, macOS) |
| Markdown, Tabellen, Code, ABAP, KaTeX | ✅ verifiziert | jsdom- und Chrome-Tests, E2E |
| Mermaid (5 Typen), fehlerhafte Diagramme | ✅ verifiziert | Chrome-Tests, E2E (WebKit) |
| XSS-Schutz Markdown/Mermaid/KaTeX | ✅ verifiziert | jsdom-, Chrome- und E2E-Tests |
| Tool-Status, Subagents, Wiederherstellung | ✅ verifiziert (Unit) | `WebTurnWidgetTest` |
| Tool-Bestätigung inkl. Session-Freigabe-Vertrag | ✅ verifiziert | Unit + E2E (Klick in der Seite → Future → `getSelectedAction`) |
| Thinking inkl. Titel und Persistenz, Abbruch | ✅ verifiziert (Unit, LS gemockt) | `WebTurnWidgetTest` |
| Warnungen/Quota-Aktionen, Coding-Agent-Karte | ✅ verifiziert (Unit) | `WebTurnWidgetTest` |
| Fehlerbanner, Reload/Replay der Seite | ✅ verifiziert | E2E |
| Update einer bestehenden Installation (0.21.0.2026… → 0.21.0.custom…) inkl. Chat | ✅ verifiziert | p2-Director in einer Kopie der echten Eclipse-Installation; Versionsvergleich mit OSGi geprüft |
| Fallback auf klassische Ansicht | ✅ per Code-Review | Provider/Factory (kein automatisierter Test ohne Browser-Ausfall) |
| Echte Copilot-Sitzung (LS, MCP, Agent, Verlauf laden) | ⚠️ nicht verifiziert | erfordert Konto → manuelle Testfälle M1–M16 |
| Windows (WebView2), Linux (WebKitGTK) in Eclipse | ⚠️ nicht verifiziert | Chromium-Tests decken die WebView2-Engine ab |
| Drag & Drop auf den Nachrichtenbereich | ⚠️ nicht verifiziert | plattformabhängig |
