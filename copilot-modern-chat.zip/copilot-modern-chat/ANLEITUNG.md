# Moderne Chat-Oberfläche in das Copilot-for-Eclipse-Projekt einbauen

Diese Anleitung baut die neue HTML-Chat-Oberfläche in ein Checkout von
[microsoft/copilot-for-eclipse](https://github.com/microsoft/copilot-for-eclipse) ein und baut das Projekt lokal.
Danach liefert Eclipse die neue Oberfläche über **Help › Check for Updates** aus.

Entwickelt und getestet auf dem Upstream-Stand `632037f6` („Remove unused CopilotUsageBar (#479)“), Version 0.21.0.

## Inhalt dieses Pakets

```
copilot-modern-chat/
├── ANLEITUNG.md                          diese Datei
├── custom-ui/                            der komplette neue Code (wird unverändert ins Projekt kopiert)
│   └── README.md                         ausführliche Doku: Architektur, Sicherheit, Tests, Updates
└── microsoft-aenderungen/
    ├── microsoft-aenderungen.patch       alle Änderungen an Microsoft-Dateien als Git-Patch
    └── neue-dateien/                     dieselben neuen Dateien zum Kopieren (falls der Patch nicht passt)
```

---

## Arbeitsanweisung für den KI-Assistenten in VS Code

Arbeite die Schritte 1 bis 5 der Reihe nach ab. Das Projekt-Wurzelverzeichnis ist der Ordner mit `pom.xml`, `mvnw`
und `com.microsoft.copilot.eclipse.ui/`. Ändere **keine** anderen Microsoft-Dateien als die unten genannten und führe
keine Refactorings durch.

### Schritt 1: Ordner `custom-ui` kopieren

Kopiere den Ordner `custom-ui/` aus diesem Paket **unverändert** in das Projekt-Wurzelverzeichnis, sodass
`<projekt>/custom-ui/pom.xml` existiert. Gibt es dort schon einen Ordner `custom-ui`, ersetze ihn vollständig.

### Schritt 2: Microsoft-Dateien ändern

**Variante A (bevorzugt): Patch anwenden.** Im Projekt-Wurzelverzeichnis:

```bash
git apply --check <paket>/microsoft-aenderungen/microsoft-aenderungen.patch
git apply --whitespace=nowarn <paket>/microsoft-aenderungen/microsoft-aenderungen.patch
```

Meldet `--check` keinen Fehler, ist Schritt 2 damit erledigt; weiter mit Schritt 3. Schlägt der Patch fehl (anderer
Upstream-Stand), alles wieder rückgängig machen und **Variante B** verwenden.

**Variante B: Von Hand.** Es sind genau acht Änderungen.

#### B1. Neue Datei `com.microsoft.copilot.eclipse.ui/src/com/microsoft/copilot/eclipse/ui/chat/IChatContentViewerProvider.java`

Kopieren aus `microsoft-aenderungen/neue-dateien/` (gleicher Pfad).

#### B2. Neue Datei `com.microsoft.copilot.eclipse.ui/src/com/microsoft/copilot/eclipse/ui/chat/ChatContentViewerFactory.java`

Kopieren aus `microsoft-aenderungen/neue-dateien/` (gleicher Pfad).

#### B3. Neue Datei `com.microsoft.copilot.eclipse.ui/schema/chatContentViewerProviders.exsd`

Kopieren aus `microsoft-aenderungen/neue-dateien/` (gleicher Pfad).

#### B4. Neue Datei `.mvn/maven.config`

Kopieren aus `microsoft-aenderungen/neue-dateien/.mvn/maven.config`. Inhalt (eine Zeile, die einfachen
Anführungszeichen gehören dazu):

```
-Dtycho.buildqualifier.format='custom'yyyyMMddHHmm
```

Existiert die Datei bereits, die Zeile anhängen.

#### B5. `com.microsoft.copilot.eclipse.ui/src/com/microsoft/copilot/eclipse/ui/chat/ChatView.java`

In der Methode `createConversationPage()` genau **eine** Zeile ersetzen:

```java
// vorher
this.chatContentViewer = new ChatContentViewer(this.contentWrapper, SWT.NONE, this.chatServiceManager);
// nachher
this.chatContentViewer = ChatContentViewerFactory.create(this.contentWrapper, SWT.NONE, this.chatServiceManager);
```

(Kein Import nötig, die Factory liegt im selben Paket.)

#### B6. `com.microsoft.copilot.eclipse.ui/src/com/microsoft/copilot/eclipse/ui/chat/ChatContentViewer.java`

In `getLatestOrCreateNewTurnWidget(...)` die beiden Konstruktoraufrufe ersetzen:

```java
// vorher
CopilotTurnWidget copilotTurnWidget = new CopilotTurnWidget(cmpContent, SWT.NONE, serviceManager,
    workDoneToken);
// nachher
CopilotTurnWidget copilotTurnWidget = createCopilotTurnWidget(cmpContent, workDoneToken);
```

```java
// vorher
turnWidget = new UserTurnWidget(cmpContent, SWT.NONE, serviceManager, workDoneToken);
// nachher
turnWidget = createUserTurnWidget(cmpContent, workDoneToken);
```

Und direkt vor der Methode `setConversationId(String)` diese zwei Methoden einfügen:

```java
  /** Create the widget for a Copilot turn. Subclasses may provide an alternative presentation. */
  protected CopilotTurnWidget createCopilotTurnWidget(Composite parent, String turnId) {
    return new CopilotTurnWidget(parent, SWT.NONE, serviceManager, turnId);
  }

  /** Create the widget for a user turn. Subclasses may provide an alternative presentation. */
  protected BaseTurnWidget createUserTurnWidget(Composite parent, String turnId) {
    return new UserTurnWidget(parent, SWT.NONE, serviceManager, turnId);
  }
```

Die Signaturen müssen exakt so lauten; die Klassen in `custom-ui` überschreiben genau diese Methoden.

#### B7. `com.microsoft.copilot.eclipse.ui/plugin.xml`

Direkt nach der bestehenden Deklaration `<extension-point id="mcpRegistration" ... />` einfügen:

```xml
	<extension-point
		id="chatContentViewerProviders"
		name="Chat Content Viewer Providers"
		schema="schema/chatContentViewerProviders.exsd" />
```

#### B8. `com.microsoft.copilot.eclipse.feature/feature.xml`

Nach dem `<plugin id="com.microsoft.copilot.eclipse.ui.jobs" .../>`-Eintrag einfügen:

```xml
   <plugin
         id="custom.copilot.webchat"
         version="0.0.0"/>
```

#### B9. `pom.xml` (Projekt-Wurzel), vier Zeilen

1. Im Block `<properties>` nach `<surefire.timeout>…</surefire.timeout>`:

   ```xml
   		<!-- Lets Mockito run on JDKs newer than its Byte Buddy officially supports (no effect on JDK 21). -->
   		<tycho.testArgLine>-Dnet.bytebuddy.experimental=true</tycho.testArgLine>
   ```

2. Im Block `<modules>` direkt nach `<module>com.microsoft.copilot.eclipse.ui.jobs</module>`:

   ```xml
   		<module>custom-ui/custom.copilot.webchat</module>
   ```

3. Im Block `<modules>` direkt nach `<module>com.microsoft.copilot.eclipse.repository</module>` (die Reihenfolge ist
   wichtig: dieses Modul muss nach dem Repository kommen):

   ```xml
   		<module>custom-ui/custom.copilot.updatesite</module>
   ```

4. Im Profil `osx` (Aktivierung `<family>mac</family>`) die vorhandene Zeile erweitern:

   ```xml
   <!-- vorher -->
   <tycho.testArgLine>-XstartOnFirstThread</tycho.testArgLine>
   <!-- nachher -->
   <tycho.testArgLine>-XstartOnFirstThread -Dnet.bytebuddy.experimental=true</tycho.testArgLine>
   ```

**Kontrolle nach Schritt 2:** `git status` zeigt geändert: `pom.xml`, `ChatView.java`, `ChatContentViewer.java`,
`plugin.xml`, `feature.xml`, und neu: `IChatContentViewerProvider.java`, `ChatContentViewerFactory.java`,
`chatContentViewerProviders.exsd`, `.mvn/maven.config`, `custom-ui/`. Sonst nichts.

> Die `.project`-Dateien der Microsoft-Module bitte nicht committen, falls VS Code dort `filteredResources` einträgt.

### Schritt 3: Bauen

Voraussetzungen wie beim offiziellen Projekt (siehe `CONTRIBUTING.md`): JDK 21 oder neuer, Node.js 22.13+ mit npm,
beim ersten Lauf Internetzugang.

Falls im Projekt noch nie gebaut wurde (Ordner `com.microsoft.copilot.eclipse.core/copilot-agent/dist` fehlt),
**einmalig** die Copilot-Agent-Dateien holen, so wie es auch die offizielle CI tut:

```bash
cd com.microsoft.copilot.eclipse.core/copilot-agent
npm i -f
cd ../..
```

Dann bauen:

```bash
# macOS / Linux
./mvnw clean verify
# Windows
mvnw.cmd clean verify
```

Dauer beim ersten Mal 5–15 Minuten, danach etwa 2 Minuten. Erwartet: `BUILD SUCCESS`. Alle offiziellen Tests laufen
dabei mit. Die Tests des neuen Chats laufen zusätzlich mit `./mvnw -f custom-ui/pom.xml clean verify` (optional).

Ergebnis, die Update-Site: `com.microsoft.copilot.eclipse.repository/target/repository/`

**Kontrolle:** In `com.microsoft.copilot.eclipse.repository/target/repository/plugins/` liegen
`custom.copilot.webchat_1.0.0.custom<datum>.jar` und `com.microsoft.copilot.eclipse.ui_0.21.0.custom<datum>.jar`.
Steht im Namen nicht `custom`, wurde `.mvn/maven.config` nicht gelesen (Schritt B4 prüfen).

### Schritt 4: In Eclipse installieren bzw. aktualisieren

**Einmalig** muss Eclipse die lokale Update-Site kennen:

1. *Help › Install New Software… › Add… › Local…* und den Ordner
   `<projekt>/com.microsoft.copilot.eclipse.repository/target/repository` wählen (Name z. B. „Copilot lokal“).
2. *Window › Preferences › Install/Update › Available Software Sites*: Ist dort eine **offizielle Microsoft-Copilot-Site**
   eingetragen, deren Haken entfernen. Sonst würde Eclipse eine spätere neue Microsoft-Version ohne die neue
   Oberfläche einspielen.
3. *Help › Check for Updates*. „GitHub Copilot“ wird als Update angeboten. Installieren und neu starten.
   (Ist Copilot noch gar nicht installiert: bei Schritt 1 „GitHub Copilot“ anhaken und installieren.)

**Ab dann immer:** Projekt bauen → *Help › Check for Updates* → installieren → fertig.

### Schritt 5: Prüfen

- *Window › Preferences › GitHub Copilot › Chat View* existiert, „Use the modern chat view“ ist aktiv.
- Copilot-Chat öffnen, eine Frage stellen, z. B. „Zeige eine Tabelle mit drei Spalten und ein Mermaid-Flowchart“.
  Die Antwort erscheint mit echter Tabelle und gerendertem Diagramm.
- Unter **Windows** benötigt die Oberfläche die Microsoft Edge WebView2 Runtime (in Windows 10/11 normalerweise
  vorhanden). Fehlt sie, zeigt Eclipse automatisch die alte Oberfläche; im Error Log steht dann „The embedded
  browser is not available“.

---

## Später: Build für alle auf einem Netzlaufwerk bereitstellen

1. In `custom-ui/team-update-site.properties` den Zielordner eintragen, z. B.

   ```properties
   copilot.updatesite.dir=//fileserver/team/eclipse/copilot
   ```

   (Windows auch `Z:/eclipse/copilot`; Schrägstriche verwenden.)
2. Normal bauen (`mvnw clean verify`). Der Build kopiert die fertige Update-Site automatisch dorthin, erst die
   Plug-ins und dann die Metadaten.
3. Jeder Kollege einmalig: *Help › Install New Software… › Add…* und dort den Netzlaufwerk-Ordner hinzufügen. Die
   Microsoft-Site deaktivieren (siehe Schritt 4.2), dann *Check for Updates*.
4. Danach bekommen alle jede neue Version über *Help › Check for Updates*.

## Fehlerbehebung

| Problem | Lösung |
|---|---|
| `git apply` schlägt fehl | Variante B (von Hand) verwenden; die Stellen per Suche nach den „vorher“-Zeilen finden |
| Kompilierfehler in `custom.copilot.webchat` „method does not override“ | Signaturen aus B6 prüfen (`protected`, Parameter `Composite parent, String turnId`) |
| `bin.includes value(s) [copilot-agent/dist/] do not match any files` | `npm i -f` in `com.microsoft.copilot.eclipse.core/copilot-agent` ausführen (Schritt 3) |
| `Cannot resolve ... com.microsoft.copilot.eclipse.ui` beim Bauen | Build im Projekt-Wurzelverzeichnis starten, nicht in `custom-ui` |
| Tests scheitern mit „Mockito cannot mock … Java 25“ | Schritt B9 Punkt 1 und 4 prüfen (ByteBuddy-Schalter) |
| Check for Updates findet nichts | Update-Site aus Schritt 4.1 hinzugefügt? Wurde nach der Installation neu gebaut? (Jeder Build hat eine neuere Version.) |
| Eclipse zeigt die alte Chat-Oberfläche | *Preferences › GitHub Copilot › Chat View* prüfen; Error Log auf „embedded browser“ prüfen; neue Konversation öffnen |
| Beim Start „WHATISNEW.html … not found“ | Harmlos: alter Editor-Tab der „What's New“-Seite, einfach schließen |
