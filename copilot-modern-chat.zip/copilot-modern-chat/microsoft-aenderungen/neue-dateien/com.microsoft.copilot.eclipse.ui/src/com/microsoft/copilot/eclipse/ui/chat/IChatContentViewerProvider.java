// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

package com.microsoft.copilot.eclipse.ui.chat;

import org.eclipse.swt.widgets.Composite;

import com.microsoft.copilot.eclipse.ui.chat.services.ChatServiceManager;

/**
 * Provides an alternative {@link ChatContentViewer} implementation for the chat view. Contributed through the
 * {@code com.microsoft.copilot.eclipse.ui.chatContentViewerProviders} extension point.
 */
public interface IChatContentViewerProvider {

  /**
   * Creates the viewer that renders the chat conversation.
   *
   * @param parent the parent composite
   * @param style the SWT style
   * @param serviceManager the chat service manager
   * @return the viewer, or {@code null} to fall back to the default {@link ChatContentViewer}
   */
  ChatContentViewer createChatContentViewer(Composite parent, int style, ChatServiceManager serviceManager);
}
