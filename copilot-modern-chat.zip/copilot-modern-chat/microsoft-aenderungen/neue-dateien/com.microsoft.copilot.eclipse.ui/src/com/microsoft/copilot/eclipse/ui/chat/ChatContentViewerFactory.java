// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

package com.microsoft.copilot.eclipse.ui.chat;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.Platform;
import org.eclipse.swt.widgets.Composite;

import com.microsoft.copilot.eclipse.core.CopilotCore;
import com.microsoft.copilot.eclipse.ui.chat.services.ChatServiceManager;

/**
 * Creates the {@link ChatContentViewer} for the chat view, consulting the providers contributed to the
 * {@code com.microsoft.copilot.eclipse.ui.chatContentViewerProviders} extension point first. Falls back to the
 * default viewer when no provider is contributed, a provider declines, or a provider fails.
 */
public final class ChatContentViewerFactory {

  /** The fully qualified ID of the extension point. */
  public static final String EXTENSION_POINT_ID = "com.microsoft.copilot.eclipse.ui.chatContentViewerProviders";

  private ChatContentViewerFactory() {
  }

  /**
   * Create the chat content viewer.
   *
   * @param parent the parent composite
   * @param style the SWT style
   * @param serviceManager the chat service manager
   * @return the viewer, never {@code null}
   */
  public static ChatContentViewer create(Composite parent, int style, ChatServiceManager serviceManager) {
    IExtensionRegistry registry = Platform.getExtensionRegistry();
    if (registry != null) {
      for (IConfigurationElement element : registry.getConfigurationElementsFor(EXTENSION_POINT_ID)) {
        try {
          if (element.createExecutableExtension("class") instanceof IChatContentViewerProvider provider) {
            ChatContentViewer viewer = provider.createChatContentViewer(parent, style, serviceManager);
            if (viewer != null) {
              return viewer;
            }
          }
        } catch (CoreException | RuntimeException | LinkageError e) {
          CopilotCore.LOGGER.error("Failed to create chat content viewer from " + element.getContributor().getName(),
              e);
        }
      }
    }
    return new ChatContentViewer(parent, style, serviceManager);
  }
}
